<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="theme-clock.css" />
    <title>A2::Centers</title>
    <link rel="icon" href="app-owner-logo.png" type="image/gif">
  </head>
  <body>
      
      <div class="clock-container">
          <img src="app-owner-logo.png"/><br/>
          <div style="text-align: center">
              we are very soon coming up with eCommerce Website to sell the products
              Like  (Ladies Suits, Tops, Designer Dresses, Apparels & Garments) and many more.
              we also design customized dresses as per the customer requirement for any occasion.
              at your doorstep in affordable price with payment options (online payment & cash on delivery). 
              contact us for more detail.   
          </div>
          <div class="phone">
                <a href="https://wa.me/+916364802280?text=<?php echo urlencode('this request made from a2.tictik.org');?>">
                    <i class="bi bi-whatsapp"></i>
                    <button class="contact-us">Contact Us</button>
                </a>
            </div>
      </div>
    
    <div class="body">
        <button class="toggle" hidden="true">Dark mode</button>

        <div class="clock-container">
          <div class="clock">
            <div class="needle hour"></div>
            <div class="needle minute"></div>
            <div class="needle second"></div>
            <div class="center-point"></div>
          </div>

          <div class="time"></div>
          <div class="date"></div>
        </div>
    </div>
    <script src="theme-clock.js"></script>
    
    <!-- ClickDesk Live Chat Service for websites -->
    <script type='text/javascript'>
    var _glc =_glc || []; _glc.push('all_ag9zfmNsaWNrZGVza2NoYXRyEgsSBXVzZXJzGICAyLjMrpYLDA');
    if(document.location.hostname != 'localhost'){
            var glcpath = (('https:' == document.location.protocol) ? 'https://my.clickdesk.com/clickdesk-ui/browser/' : 
            'http://my.clickdesk.com/clickdesk-ui/browser/');
            var glcp = (('https:' == document.location.protocol) ? 'https://' : 'http://');
    }else{
            var glcpath = 'http://localhost:8888/clickdesk-ui/browser/';
            var glcp = 'http://';
    }
    var glcspt = document.createElement('script'); glcspt.type = 'text/javascript'; 
    glcspt.async = true; glcspt.src = glcpath + 'livechat-cloud-new.js';
    var s = document.getElementsByTagName('script')[0];s.parentNode.insertBefore(glcspt, s);
    </script>
    <!-- End of ClickDesk -->
  </body>
</html>