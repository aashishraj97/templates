<?php include_once $_SERVER['DOCUMENT_ROOT'] . "/includes/common.php";

$DBUtilObj = new DBUtil();
$DateTimeUtilObj = new DateTimeUtil();

$action = $_REQUEST['action'];
if ($action == 'load') 
{
    $response = "";
    $search_text = isset($_REQUEST['search_text'])?$_REQUEST['search_text']:'';
    $from_date = isset($_REQUEST['from_date'])?$_REQUEST['from_date']:'';
    $to_date = isset($_REQUEST['to_date'])?$_REQUEST['to_date']:'';
    $vendorname = isset($_REQUEST['vendorname'])?$_REQUEST['vendorname']:'';
    $by_user = isset($_REQUEST['by_user'])?$_REQUEST['by_user']:'';
    $closed = isset($_REQUEST['closed'])?$_REQUEST['closed']:'';

    $where = $and = "";
    if($closed != ''){
        $where .= $and . " closed='" . $closed . "'";
        $and = " AND ";
    }
    if ($search_text != '') {
        $where .= $and . " ( ticket_number LIKE '%" . $search_text . "%' OR client LIKE '%" . $search_text . "%' OR endclient LIKE '%" . $search_text . "%' OR city LIKE '%" . $search_text . "%' OR country LIKE '%" . $search_text . "%' OR ftename LIKE '%" . $search_text . "%'  OR by_user LIKE '%" . $search_text . "%' OR vendorname LIKE '%" . $search_text . "%'  )";
         $and = " AND ";
    }
    if ($from_date != '') {
        $from_date_slice = explode("-", $from_date);
        $fdate = $from_date_slice[2] . '-' . $from_date_slice[1] . '-' . $from_date_slice[0];
        $where = $where . $and . " DATE_FORMAT(tm.checkin,'%Y-%m-%d')>='" . $fdate . "'";
        $and = " AND ";
    }
    if ($to_date != '') {
        $to_date_slice = explode("-", $to_date);
        $tdate = $to_date_slice[2] . '-' . $to_date_slice[1] . '-' . $to_date_slice[0];
        $where = $where . $and . " DATE_FORMAT(tm.checkin,'%Y-%m-%d')<='" . $tdate . "'";
        $and = " AND ";
    }
    if ($by_user != '') {
        $where .= $and . " by_user='" . $by_user . "'";
         $and = " AND ";
    }
    if ($vendorname != '') {
        $where .= $and . " vendorname='" . $vendorname . "'";
         $and = " AND ";
    }
    if($where!=''){
        $where = ' WHERE '.$where;
    }
    
    $query = "SELECT t.id, `ticket_number`, `client`, `endclient`, `city`, `country`, `ftename`, `vendorname`, tm.checkin, tm.checkout, tm.timezone, tm.timezone_code, tm.comment, tm.by_user, `closed` FROM ".DBTable::TBL_TICKETS." t JOIN ".DBTable::TBL_TICKETS_MAPPING." tm ON(t.id = tm.ticket_id) ".$where;
    $DBUtilObj->_run_query($query);
    $num_rows = $DBUtilObj->_num_rows();
    $report_data = $DBUtilObj->_fetch_all();
    if ($num_rows > 0) {
        $response = '<div id="update-msg"><label class="alert-info mt10">Total '.$num_rows.' records found.</label></div>';
        $response .= '<table id="report-table" query="'.$where.'" class="table table-striped table-bordered" cellspacing="0" width="100%">
                    <thead>
                    <tr>
                        <th>TicketNo</th>
                        <th>Client</th>
                        <th>End Client</th>
                        <th>City</th>
                        <th>Country</th>
                        <th>FTEName</th>
                        <th>Vendor</th>
                        <th>CheckIn</th>
                        <th>CheckOut</th>
                        <th>By User</th>
                        <th>WorkHours</th>
                        <th>Status</th>';
                        if(isset($_SESSION['ROLE']) && ($_SESSION['ROLE']=='admin'))
                        {
            $response .= '<th>Comment</th>';
                        }
        $response .= '</tr>
                    </thead>';

        foreach ($report_data as $item) {
            $response .= '<tr id="table-row-' . $item['id'] . '">
                    <td>' . $item['ticket_number'] . '</td>' .
                   '<td>' . $item['client'] . '</td>' .
                   '<td>' . $item['endclient'] . '</td>' . 
                   '<td>' . $item['city'] . '</td>' . 
                   '<td>' . $item['country'] . '</td>' . 
                   '<td>' . $item['ftename'] . '</td>' . 
                   '<td>' . $item['vendorname'] . '</td>' . 
                   '<td>' . $item['checkin'] . " " .$item['timezone_code']. '</td>' . 
                   '<td>' . $item['checkout'] . " " .$item['timezone_code']. '</td>' . 
                   '<td>' . $item['by_user'] . '</td>' . 
                   '<td>';
                    $time_dff = '';
                    if($item['checkin']!=null && $item['checkout']!=null){
                        $object = $DateTimeUtilObj->_datetime_diff($item['checkin'], $item['checkout']);
                        $time_dff = $object->h. ' hours';
                    }
            $response .= $time_dff . '</td><td>';
                    $status = 'Closed';
                    if($item['closed']=='No'){
                        $status = 'Open';
                    }
            $response .= $status . '</td>';
                    if(isset($_SESSION['ROLE']) && ($_SESSION['ROLE']=='admin'))
                        {
            $response .= '<td>' . $item['comment'] . '</td>';
                        }
            $response .= '</tr>';
        }
        $response .= '</table>';
    }
    else {
        $response = '<label class="alert-info mt10">No records available.</label>';
    }
    echo $response;
}
?>