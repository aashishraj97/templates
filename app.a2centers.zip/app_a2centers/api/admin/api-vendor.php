<?php include_once $_SERVER['DOCUMENT_ROOT'] . "/includes/common.php";
$VendorObj = new Vendor();
$action = isset($_REQUEST['action'])?$_REQUEST['action']:'load';

if ($action == 'unique') 
{
    $response = $VendorObj->_is_exist($_REQUEST);
    //echo json_encode($response);
    if($response['RESPONSE'] == 'SUCCESS'){
        echo 'false';
    }
    else {
        echo 'true';
    }
}
else if ($action == 'load') 
{
    $response = "";
    $search_text = isset($_REQUEST['search_text'])?$_REQUEST['search_text']:'';

    $where = $and = "";
    if ($search_text != '') {
        $where .= $and . " ( vendorname LIKE '%" . $search_text . "%' OR email LIKE '%" . $search_text . "%' )";
         $and = " AND ";
    }
    $data['where'] = $where;
    /*name mobile email vendorname vendorname role expire_date*/
    $vendor_data = $VendorObj->_get($data);
    if ($vendor_data['num_rows'] > 0) {
        $response = '<div id="update-msg"><label class="alert-info mt10">Total '.$vendor_data['num_rows'].' records found.</label></div>';
        $response .= '<table id="vendor-table" query="'.$where.'" class="table table-striped table-bordered" cellspacing="0" width="100%">
                    <thead>
                    <tr>
                        <th width="45%">Vendor</th>
                        <th width="45%">Email</th>
                        <th class="text-center" width="10%">Action</th>
                    </tr>
                    </thead>';

        foreach ($vendor_data['data'] as $item) {
            $response .= '<tr id="table-row-' . $item['id'] . '">' .
                   '<td><span class="vendorname-row">' . $item['vendorname'] . '</span></td>' .
                   '<td><span class="email-row">' . $item['email'] . '</span></td>' .
                   '<td>
                       <span> 
                            <span class="edit-btn">
                                <button onclick="javascript:_edit_vendor_modal(\'' . $item['id'] . '\');" title="Edit Vendor" class="btn btn-warning"><i class="fa  fa-edit"></i></button>
                            </span>
                            <span></span>
                            <span class="delete-btn">
                                <button onclick="javascript:_delete_vendor_modal(\'' . $item['id'] . '\');" title="Delete Vendor" class="btn btn-danger"><i class="fa fa-trash"></i></button>
                            </span>
                        </span>
                    </td>' .
                '</tr>';
        }
        $response .= '</table>';
    }
    else {
        $response = '<label class="alert-info mt10">No records available.</label>';
    }
    echo $response;
}
else if ($action == 'add') 
{
    $form_data = isset($_REQUEST)?$_REQUEST:[];
    $response = $VendorObj->_add($form_data);
    if($response['RESPONSE']=='SUCCESS'){
        //_send_activity_updates($form_data);
    }
    echo json_encode($response);;
}
else if ($action == 'edit') 
{
    $form_data = isset($_REQUEST)?$_REQUEST:[];
    $response = $VendorObj->_edit($form_data);
    if($response['RESPONSE']=='SUCCESS'){
        //_send_activity_updates($action,$id);
    }
    echo json_encode($response);;
}
else if ($action == 'delete') 
{
    $id = isset($_REQUEST['id'])?$_REQUEST['id']:0;
    $response = $VendorObj->_remove($id);
    if($response['RESPONSE']=='SUCCESS'){
        //_send_activity_updates($action,$id);
    }
    echo json_encode($response);;
}
?>