<?php include_once $_SERVER['DOCUMENT_ROOT'] . "/includes/common.php";

$DBUtilObj = new DBUtil;
$LogUtilObj = new LogUtil;
$action = $_REQUEST['action'];

if ($action == 'delete') {
    $delete_type = $_REQUEST['delete-type'];
    $count = 0;
    $response = "";
    if (($delete_type=='selected') && !empty($_REQUEST['check-list'])) {
        foreach ($_REQUEST['check-list'] as $log_id) {
            $DBUtilObj->_delete(DBTable::LOGS, "id=".$log_id);
            $count++;
        }
        $response = '<label class="alert-info mt10">'.$count . ' Log(s) have been deleted.</lable>';
    } 
    else {
        $where = $_REQUEST['filter'];
        $DBUtilObj->_delete(DBTable::LOGS, $where);
        $response = '<label class="alert-info mt10">Logs have been deleted.</label>';
    }
    echo $response;
}
else if ($action == 'load') {
    $response = '';
    $search_text = isset($_REQUEST['search'])?$_REQUEST['search']:'';
    $from_date = isset($_REQUEST['from_date'])?$_REQUEST['from_date']:'';
    $to_date = isset($_REQUEST['to_date'])?$_REQUEST['to_date']:'';
    $log_type = isset($_REQUEST['log_type'])?$_REQUEST['log_type']:'';
    $limit = isset($_REQUEST['row_limit'])?$_REQUEST['row_limit']:'';

    if ($limit != '') {
        $limit = ' ' . $limit;
    }
    else {
        $limit = ' 100';
    }

    $where = $and = "";
    if ($log_type != '') {
        $where .= $and . " type='" . $log_type . "'";
        $and = " AND ";
    }
    if ($from_date != '') {
        $from_date_slice = explode("-", $from_date);
        $fdate = $from_date_slice[2] . '-' . $from_date_slice[1] . '-' . $from_date_slice[0];
        $where .= $and . " date_time>='" . $fdate . "'";
        $and = " AND ";
    }
    if ($to_date != '') {
        $to_date_slice = explode("-", $to_date);
        $tdate = $to_date_slice[2] . '-' . $to_date_slice[1] . '-' . $to_date_slice[0];
        $where .= $and . " DATE_FORMAT(date_time,'%Y-%m-%d')<='" . $tdate . "'";
        $and = " AND ";
    }

    if ($search_text != '') {
        $where .= $and . " message LIKE '%" . $search_text . "%' ";
    }
    $data['where'] = $where;
    $data['order_by'] = 'id desc';
    $data['limit'] = $limit;
    
    $log_data = $LogUtilObj->_get($data);
    if ($log_data['num_rows'] > 0) {
        $log_id_ary = array();
        foreach ($log_data['data'] as $log_info) {
            array_push($log_id_ary, $log_info['id']);
        }
        $log_ids = "id IN (" . implode(',', $log_id_ary) . ")";

        $response .= '<form id="delete-log-form">
                <div class="row m0">
                    <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6 mt10">
                        <select class="form-control input-medium" name="delete-type" id="delete-type">
                                <option value="">Select</option>
                                <option value="all">All Logs</option>
                                <option value="selected">Selected Logs</option>
                        </select>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6 mt10">
                        <input type="hidden" id="filter" name="filter" value="' . $log_ids . '"></input>
                        <input type="button" class="btn btn-danger" value="Delete" onclick="return _validate_delete_form();"/>
                    </div>
                </div>';
        $response .= '<div id="update-msg"></div>';
        $response .= '<table id="log-table" query="'.$where.'" class="table table-striped table-bordered" cellspacing="0" width="100%">
                <thead>
                    <tr>
                        <th><input id="checkbox-all" type="checkbox" class="check-group"></th>
                        <th>Date & Time</th>
                        <th>Type</th>
                        <th>Message</th>
                        <th>By User</th>
                    </tr>
                </thead>';

        foreach ($log_data['data'] as $item) {
        $response .= '<tr id="table-row-' . $item['id'] . '">
                    <td><input type="checkbox" name="check-list[]" id="checkbox-' . $item['id'] . '" value="' . $item['id'] . '" class="check-group"></td>
                    <td>' . $item['date_time'] . '</td>' .
                   '<td>' . $item['type'] . '</td>' . 
                   '<td>' . $item['message'] . '</td>' . 
                   '<td>' . $item['by_user'] . '</td>' .
                '</tr>';
        }
    $response .=  '</table>
            </form>';
    }
    else {
        $response = '<label class="alert-info mt10">No logs available.</label>';
    }
    echo $response;
}
?>