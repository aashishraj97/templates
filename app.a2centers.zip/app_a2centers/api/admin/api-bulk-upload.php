<?php include_once $_SERVER['DOCUMENT_ROOT'] . "/includes/common.php";

$DBUtilObj = new DBUtil;
$action = $_REQUEST['action'];

if ($action == 'add') {
    if (isset($_POST["client"])) {
        $connect = new PDO("mysql:host=localhost; dbname=".DB::NAME, DB::USER, DB::PASS);

        //session_start();

        $file_data = $_SESSION['file_data'];

        unset($_SESSION['file_data']);
        include_once $_SERVER['DOCUMENT_ROOT'] . "/class/User.php";
        $UserObj = new User;
        include_once $_SERVER['DOCUMENT_ROOT'] . "/class/Ticket.php";
        $TicketObj = new Ticket;
        $form_data['field'] = 'username';
        $tform_data['field'] = 'ticket_number';
        foreach ($file_data as $key => $row) {
            $tform_data['value'] = trim($row[$_POST["ticket_number"]]);
            $tresponse = $TicketObj->_is_exist($tform_data);
            if($tresponse['RESPONSE']=='SUCCESS'){
                $error_data[] = 'Row : '.($key+1).', Ticket Number ('.$row[$_POST["ticket_number"]].') already existing in system.<br/>';
            }
            else {
                
                $form_data['value'] = trim($row[$_POST["ftename"]]);
                $response = $UserObj->_is_exist($form_data);
                if($response['RESPONSE']=='SUCCESS'){
                    $data[] = '("' . $row[$_POST["ticket_number"]] . '", "' . $row[$_POST["client"]] . '", "' . $row[$_POST["endclient"]] . '", "' . $row[$_POST["city"]] . '", "' . $row[$_POST["country"]] . '", "' . $row[$_POST["ftename"]] . '", "' . $row[$_POST["vendorname"]] . '", NOW())';
                }
                else {
                    $error_data[] = 'Row : '.($key+1).', Username ('.$row[$_POST["ftename"]].') not existing in system.<br/>';
                }

            }
        }
        if (isset($error_data)) {
            echo implode(" ", $error_data);
        }
        if (isset($data)) {
            $query = "  INSERT INTO tbl_tickets 
                        (ticket_number, client, endclient, city, country, ftename, vendorname, created_at) 
                        VALUES " . implode(",", $data) . "
                        ";

            $statement = $connect->prepare($query);

            if ($statement->execute()) {
                echo '('.count($data).') Rows of Data Imported Successfully';
            }
        }
    }    
}
else if ($action == 'load') {
    $error = '';

    $html = '';

    if ($_FILES['file']['name'] != '') {
        $file_array = explode(".", $_FILES['file']['name']);

        $extension = end($file_array);

        if ($extension == 'csv') {
            $file_data = fopen($_FILES['file']['tmp_name'], 'r');

            $file_header = fgetcsv($file_data);

            $html .= '<table class="table table-bordered"><tr>';

            for ($count = 0; $count < count($file_header); $count++) {
                $count0 = $count1 = $count2 = $count3 = $count4 = $count5 = $count6 = '';
//                if($count==0){
//                    $count1 = 'selected';
//                } else if($count==1){
//                    $count1 = 'selected';
//                } else if($count==2){
//                    $count2 = 'selected';
//                } else if($count==3){
//                    $count3 = 'selected';
//                } else if($count==4){
//                    $count4 = 'selected';
//                } else if($count==5){
//                    $count5 = 'selected';
//                } else if($count==6){
//                    $count6 = 'selected';
//                }
                $html .= '
       <th>
        <select name="set_column_data" class="form-control set_column_data" data-column_number="' . $count . '">
            <option value="">Select</option>
            <option value="client" '.$count0.'>Client</option>
            <option value="endclient" '.$count1.'>End Client</option>
            <option value="city" '.$count2.'>City</option>
            <option value="country" '.$count3.'>Country</option>
            <option value="ftename" '.$count4.'>FTE Name</option>
            <option value="vendorname" '.$count5.'>Vendor Name</option>
            <option value="ticket_number" '.$count6.'>Ticket Number</option>
        </select>
       </th>';
            }

            $html .= '</tr>';

            $limit = 0;

            while (($row = fgetcsv($file_data)) !== FALSE) {
                $limit++;

                if ($limit < 7) {
                    $html .= '<tr>';

                    for ($count = 0; $count < count($row); $count++) {
                        $html .= '<td>' . $row[$count] . '</td>';
                    }

                    $html .= '</tr>';
                }

                $temp_data[] = $row;
            }

            $_SESSION['file_data'] = $temp_data;

            $html .= '
      </table>
      <br />
      <div align="right">
       <button type="button" name="import" id="import" class="btn btn-success" disabled>Import</button>
      </div>
      <br />
      ';
        } else {
            $error = 'Only <b>.csv</b> file allowed';
        }
    } else {
        $error = 'Please Select CSV File';
    }

    $output = array(
        'error' => $error,
        'output' => $html
    );

    echo json_encode($output);
    
}
?>