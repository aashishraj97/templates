<?php include_once $_SERVER['DOCUMENT_ROOT'] . "/includes/common.php";

$DBUtilObj = new DBUtil();
$TicketObj = new Ticket();

$action = $_REQUEST['action'];
if ($action == 'load') 
{
    $response = "";
    $search_text = isset($_REQUEST['search_text'])?$_REQUEST['search_text']:'';
    $from_date = isset($_REQUEST['from_date'])?$_REQUEST['from_date']:'';
    $to_date = isset($_REQUEST['to_date'])?$_REQUEST['to_date']:'';
    $vendorname = isset($_REQUEST['vendorname'])?$_REQUEST['vendorname']:'';
    $closed = isset($_REQUEST['closed'])?$_REQUEST['closed']:'';

    $where = $and = "";
    if($closed != ''){
        $where .= $and . " closed='" . $closed . "'";
        $and = " AND ";
    }
    if ($search_text != '') {
        $where .= $and . " ( ticket_number LIKE '%" . $search_text . "%' OR client LIKE '%" . $search_text . "%' OR endclient LIKE '%" . $search_text . "%' OR city LIKE '%" . $search_text . "%' OR country LIKE '%" . $search_text . "%' OR ftename LIKE '%" . $search_text . "%'  OR vendorname LIKE '%" . $search_text . "%'  )";
         $and = " AND ";
    }
    if ($from_date != '') {
        $from_date_slice = explode("-", $from_date);
        $fdate = $from_date_slice[2] . '-' . $from_date_slice[1] . '-' . $from_date_slice[0];
        $where = $where . $and . " DATE_FORMAT(created_at,'%Y-%m-%d')>='" . $fdate . "'";
        $and = " AND ";
    }
    if ($to_date != '') {
        $to_date_slice = explode("-", $to_date);
        $tdate = $to_date_slice[2] . '-' . $to_date_slice[1] . '-' . $to_date_slice[0];
        $where = $where . $and . " DATE_FORMAT(created_at,'%Y-%m-%d')<='" . $tdate . "'";
        $and = " AND ";
    }
    if ($vendorname != '') {
        $where .= $and . " vendorname='" . $vendorname . "'";
         $and = " AND ";
    }
    
    $ticket = $TicketObj->_get(['where'=>$where]);
    
    if($where!=''){
        $where = ' WHERE '.$where;
    }
    
//    $query = "SELECT * FROM ".DBTable::TBL_TICKETS." ".$where;
//    $DBUtilObj->_run_query($query);
//    $num_rows = $DBUtilObj->_num_rows();
//    $report_data = $DBUtilObj->_fetch_all();
    
    $num_rows = $ticket['num_rows'];
    $report_data = $ticket['data'];
    if ($num_rows > 0) {
        $response = '<div id="update-msg"><label class="alert-info mt10">Total '.$num_rows.' records found.</label></div>';
        $response .= '<table id="ticket-table" query="'.$where.'" class="table table-striped table-bordered" cellspacing="0" width="100%">
                    <thead>
                    <tr>
                        <th>TicketNo</th>
                        <th>FTEName</th>
                        <th>Vendor</th>
                        <th>Client</th>
                        <th>End Client</th>
                        <th>City</th>
                        <th>Country</th>
                        <th>Status</th><th>Created Date & Time</th><th>Action</th>';
//                        if(empty($closed)){
//                            $response .= '<th>Action</th>';
//                        }
            $response .= '</tr>
                    </thead>';

        foreach ($report_data as $item) {
            $response .= '<tr id="table-row-' . $item['id'] . '">
                    <td><span class="ticket_number-row">' . $item['ticket_number'] . '</span></td>' .
                   '<td><span class="ftename-row">' . $item['ftename'] . '</span></td>' . 
                   '<td><span class="vendorname-row">' . $item['vendorname'] . '</span></td>' . 
                   '<td><span class="client-row">' . $item['client'] . '</span></td>' .
                   '<td><span class="endclient-row">' . $item['endclient'] . '</span></td>' . 
                   '<td><span class="city-row">' . $item['city'] . '</span></td>' . 
                   '<td><span class="country-row">' . $item['country'] . '</span></td>';
                    $status = 'Open';
                    $disabled = '';
                    if($item['closed']=='Yes'){
                        $status = 'Closed';
                        //$disabled = 'disabled';
                    }
            $response .= '<td><span class="closed-row">' . $status . '</span></td><td>' . $item['created_at'] . '</td>';
                    //if(empty($closed)){
            $response .= '
                    <td>    
                       <span> 
                            <span class="edit-btn">
                                <button '.$disabled.' onclick="javascript:_edit_ticket_modal(\'' . $item['id'] . '\');" title="Edit Ticket" class="btn btn-warning"><i class="fa  fa-edit"></i></button>
                            </span>
                            <span></span>
                            <span class="delete-btn">
                                <button onclick="javascript:_delete_ticket_modal(\'' . $item['id'] . '\');" title="Delete Ticket" class="btn btn-danger"><i class="fa fa-trash"></i></button>
                            </span>
                        </span>
                    </td>';
                    //}
            $response .= '</tr>';
        }
        $response .= '</table>';
    }
    else {
        $response = '<label class="alert-info mt10">No records available.</label>';
    }
    echo $response;
}
else if ($action == 'unique') 
{
    $response = $TicketObj->_is_exist($_REQUEST);
    //echo json_encode($response);
    if($response['RESPONSE'] == 'SUCCESS'){
        echo 'false';
    }
    else {
        echo 'true';
    }
}
else if ($action == 'add') 
{
    $form_data = isset($_REQUEST)?$_REQUEST:[];
    $response = $TicketObj->_add($form_data);
    if($response['RESPONSE']=='SUCCESS'){
        //_send_activity_updates($form_data);
    }
    echo json_encode($response);;
}
else if ($action == 'edit') 
{
    $form_data = isset($_REQUEST)?$_REQUEST:[];
    $data['where']='id='.$form_data['id'];
    $pre_data = $TicketObj->_get($data)['data'][0];
    $response = $TicketObj->_edit($form_data);
    if($response['RESPONSE']=='SUCCESS'){
        _send_activity_updates($form_data, $pre_data);
    }
    echo json_encode($response);;
}
else if ($action == 'delete') 
{
    $id = isset($_REQUEST['id'])?$_REQUEST['id']:0;
    $response = $TicketObj->_remove($id);
    if($response['RESPONSE']=='SUCCESS'){
        //_send_activity_updates($action,$id);
    }
    echo json_encode($response);;
}

function _send_activity_updates($form_data = [], $pre_data = []) {
        $AppUtilObj = new AppUtil();
        $MailUtilObj = new MailUtil();
        $UserObj = new User($form_data['ftename']);
        $user = $UserObj->config;
        
        $action = isset($form_data['action'])?$form_data['action']:'';
        $ticket_number = isset($pre_data['ticket_number'])?$pre_data['ticket_number']:'';
        
        $message = $activity_details = $comma = ""; 
        if($action == 'edit'){
        
            if($form_data['client'] != $pre_data['client']){
                $message .= "<tr><td><strong>Client</strong></td><td>".$pre_data['client']." </td><td> ".$form_data['client']."</td></tr>";
            }
            if($form_data['ftename'] != $pre_data['ftename']){
                $message .= "<tr><td><strong>FTE Name</strong></td><td>".$pre_data['ftename']." </td><td> ".$form_data['ftename']."</td></tr>";
            }
            if($form_data['endclient'] != $pre_data['endclient']){
                $message .= "<tr><td><strong>EndClient</strong></td><td>".$pre_data['endclient']." </td><td> ".$form_data['endclient']."</td></tr>";
            }
            if($form_data['city'] != $pre_data['city']){
                $message .= "<tr><td><strong>City</strong></td><td>".$pre_data['city']." </td><td> ".$form_data['city']."</td></tr>";
            }
            if($form_data['country'] != $pre_data['country']){
                $message .= "<tr><td><strong>Country</strong></td><td>".$pre_data['country']." </td><td> ".$form_data['country']."</td></tr>";
            }
            if($form_data['closed'] != $pre_data['closed']){
                $prev_data = $new_data = 'Open';
                if($pre_data['closed']=='Yes'){
                    $prev_data = 'Close';
                }
                if($form_data['closed']=='Yes'){
                    $new_data = 'Close';
                }
                $message .= "<tr><td><strong>Status</strong></td><td>".$prev_data." </td><td> ".$new_data."</td></tr>";
            }
        }
        
        $activity_details .= "Ticket number <strong>$ticket_number - $user->username</strong> from <strong>$user->vendorname</strong>  ticket has been updated with ";
        $activity_details .= '<table border="1">
                                <tr>
                                    <th>  </th>
                                    <th>Previous</th>
                                    <th>New</th>
                                </tr>
                                '.$message.'
                            </table>';
        
        $data = $UserObj->_get_template('activity-updates');
        $content = $data['data']['content'];
        /* REPLACE THE MICROS DEFINED IN TEMPLATE */
        $app_url = APP::URL;
        $app_logo_src = $app_url.APP::LOGO_SRC;
        $search_array = ['::ACTIVITY_DETAILS::','::APP_URL::','::APP_LOGO_SRC::'];
        $replace_array= [$activity_details,    $app_url,   $app_logo_src];
        $final_message = $AppUtilObj->_str_replace($search_array, $replace_array, $content);
        
        $params = [ 'to'=>[$user->email=>$user->name],
                    'cc'=>['check.in.out@decisionone.com'=>'Check-In/Out'],
                    'subject'=>$ticket_number.' - Got Updated by '.APP::NAME.' user ('.$_SESSION['USERNAME'].').',
                    'message'=>$final_message,
                    'attachments'=>[]];
        
        $res = $MailUtilObj->_send_mail($params);
        return $res;    
}
?>