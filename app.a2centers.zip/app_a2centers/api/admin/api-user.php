<?php include_once $_SERVER['DOCUMENT_ROOT'] . "/includes/common.php";
$UserObj = new User();
$action = isset($_REQUEST['action'])?$_REQUEST['action']:'load';

if ($action == 'unique') 
{
    $response = $UserObj->_is_exist($_REQUEST);
    //echo json_encode($response);
    if($response['RESPONSE'] == 'SUCCESS'){
        echo 'false';
    }
    else {
        echo 'true';
    }
}
else if ($action == 'load') 
{
    $response = "";
    $search_text = isset($_REQUEST['search_text'])?$_REQUEST['search_text']:'';
    $vendorname = isset($_REQUEST['vendorname'])?$_REQUEST['vendorname']:'';
    $username = isset($_REQUEST['username'])?$_REQUEST['username']:'';

    $where = $and = "";
    if ($search_text != '') {
        $where .= $and . " ( username LIKE '%" . $search_text . "%' OR vendorname LIKE '%" . $search_text . "%' OR name LIKE '%" . $search_text . "%' OR mobile LIKE '%" . $search_text . "%' OR email LIKE '%" . $search_text . "%' OR role LIKE '%" . $search_text . "%' OR expire_date LIKE '%" . $search_text . "%' )";
         $and = " AND ";
    }
    
    if ($username != '') {
        $where .= $and . " username='" . $username . "'";
         $and = " AND ";
    }
    if ($vendorname != '') {
        $where .= $and . " vendorname='" . $vendorname . "'";
         $and = " AND ";
    }
    $data['where'] = $where;
    /*name mobile email vendorname username role expire_date*/
    $user_data = $UserObj->_get($data);
    if ($user_data['num_rows'] > 0) {
        $response = '<div id="update-msg"><label class="alert-info mt10">Total '.$user_data['num_rows'].' records found.</label></div>';
        $response .= '<table id="user-table" query="'.$where.'" class="table table-striped table-bordered" cellspacing="0" width="100%">
                    <thead>
                    <tr>
                        <th>Name</th>
                        <th>Mobile</th>
                        <th>Email</th>
                        <th>Vendor Name</th>
                        <th>User Name</th>
                        <th>Role</th>
                        <th>Account</th>
                        <th class="text-center">Action</th>
                    </tr>
                    </thead>';

        foreach ($user_data['data'] as $item) {
            $response .= '<tr id="table-row-' . $item['id'] . '">' .
                   '<td width="15%"><span class="name-row">' . $item['name'] . '</span></td>' .
                   '<td width="10%"><span class="mobile-row">' . $item['mobile'] . '</span></td>' .
                   '<td width="15%"><span class="email-row">' . $item['email'] . '</span></td>' .
                   '<td width="15%"><span class="vendorname-row">' . $item['vendorname'] . '</span></td>' .
                   '<td width="10%"><span class="username-row"><a role="button" onclick="_admin_content_loaders(\'check-in-out\',\'' . $item['username'] . '\');">' . $item['username'] . '</a></span></td>' .
                   '<td width="10%"><span class="role-row">' . $item['role'] . '</span></td>' . 
                   '<td width="10%"><span class="is_active-row">'; 
                   $is_active = 'Active'; if($item['is_active'] == '0'){ $is_active = "InActive";  }
            $response .= $is_active . '</span></td>' .
                   '<td width="10%">
                       <span> 
                            <span class="edit-btn">
                                <button onclick="javascript:_edit_user_modal(\'' . $item['id'] . '\');" title="Edit User" class="btn btn-warning"><i class="fa  fa-edit"></i></button>
                            </span>
                            <span></span>
                            <span class="delete-btn">
                                <button onclick="javascript:_delete_user_modal(\'' . $item['id'] . '\');" title="Delete User" class="btn btn-danger"><i class="fa fa-trash"></i></button>
                            </span>
                        </span>
                    </td>' .
                '</tr>';
        }
        $response .= '</table>';
    }
    else {
        $response = '<label class="alert-info mt10">No records available.</label>';
    }
    echo $response;
}
else if ($action == 'add') 
{
    $form_data = isset($_REQUEST)?$_REQUEST:[];
    $response = $UserObj->_add($form_data);
    if($response['RESPONSE']=='SUCCESS'){
        _send_activity_updates($form_data);
    }
    echo json_encode($response);;
}

else if ($action == 'edit') 
{
    $form_data = isset($_REQUEST)?$_REQUEST:[];
    $response = $UserObj->_edit($form_data);
    if($response['RESPONSE']=='SUCCESS'){
        //_send_activity_updates($action,$id);
    }
    echo json_encode($response);;
}
else if ($action == 'delete') 
{
    $id = isset($_REQUEST['id'])?$_REQUEST['id']:0;
    $response = $UserObj->_remove($id);
    if($response['RESPONSE']=='SUCCESS'){
        //_send_activity_updates($action,$id);
    }
    echo json_encode($response);;
}
else if ($action == 'get_vendorwise_user_list') 
{
    $vendor = isset($_REQUEST['vendor'])?$_REQUEST['vendor']:'';
    $data['where'] = 'vendorname="'.$vendor.'"';
    $data['fields'] = ['name','username'];
    $response = $UserObj->_get($data);
    
    echo json_encode($response['data']);;
}

function _send_activity_updates($form_data = []) {
        $AppUtilObj = new AppUtil();
        $MailUtilObj = new MailUtil();
        $username = isset($form_data['username'])?$form_data['username']:'';
        $password = isset($form_data['password'])?$form_data['password']:'';

        $UserObj = new User($username);
        $user = $UserObj->config;
                
        $data = $UserObj->_get_template('temporary-password');
        $content = $data['data']['content'];
        /* REPLACE THE MICROS DEFINED IN TEMPLATE */
        $app_url = APP::URL;
        $app_logo_src = $app_url.APP::LOGO_SRC;
        $search_array = ['::NAME::','::USERNAME::','::PASSWORD::','::APP_NAME::','::APP_URL::','::APP_LOGO_SRC::'];
        $replace_array= [$user->name,$user->username,$password, APP::NAME,    $app_url,   $app_logo_src];
        $final_message = $AppUtilObj->_str_replace($search_array, $replace_array, $content);
        
        $params_user = ['to'=>[$user->email=>$user->name],
                        'subject'=>'Welcome To '.APP::NAME.', Please find your account Credentials.',
                        'message'=>$final_message];
        
        $MailUtilObj->_send_mail($params_user);
        
        $replace_vendor_array= [$user->name,$user->username,'*******', APP::NAME, $app_url, $app_logo_src];
        $final_message_vendor = $AppUtilObj->_str_replace($search_array, $replace_vendor_array, $content);
        $VendorObj = new Vendor($user->vendorname);
        $vendor = $VendorObj->config; 
        $params_vendor=['to'=>[$vendor->email=>$vendor->vendorname],
                        'bcc'=>['CTAS.ISteam@csscorp.com'=>'CTAS.ISteam'],
                        'subject'=>'New User ('.$user->username.') Got Created for '.APP::NAME.' account.',
                        'message'=>$final_message_vendor];
        
        $res = $MailUtilObj->_send_mail($params_vendor);
        
        return $res;    
}
?>