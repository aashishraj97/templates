<?php include_once $_SERVER['DOCUMENT_ROOT'] . "/includes/common.php";
$TicketObj = new Ticket();
$form_data = $_REQUEST;
$action = $form_data['action'];
$response['RESPONSE'] = '';

if ($action == 'load') 
{
    $response = "";
    $search_text = isset($form_data['search_text'])?$form_data['search_text']:'';
    $vendorname = isset($_SESSION['VENDORNAME'])?$_SESSION['VENDORNAME']:'';
    
    $where = $and = "";
    if ($search_text != '') {
        $where .= $and . " ( ticket_number LIKE '%" . $search_text . "%' OR client LIKE '%" . $search_text . "%' OR endclient LIKE '%" . $search_text . "%' OR city LIKE '%" . $search_text . "%' OR country LIKE '%" . $search_text . "%' OR ftename LIKE '%" . $search_text . "%' )";
         $and = " AND ";
    }
    
    if ($vendorname != '') {
        $where .= $and . " vendorname='" . $vendorname . "'";
         $and = " AND ";
    } 
    $where .= $and . "closed='No' AND ftename='" . $_SESSION['USERNAME'] . "'";
    $data['where'] = $where; 
    $repor_data = $TicketObj->_get($data);
    if ($repor_data['num_rows'] > 0) {
        $response = '<div id="update-msg"><label class="alert-info mt10">Total '.$repor_data['num_rows'].' records found.</label></div>';
        $response .= '<table id="check-in-out-table" query="'.$where.'" class="table table-striped table-bordered" cellspacing="0" width="100%">
                    <thead>
                    <tr>
                        <th>TicketNo</th>
                        <th>Client</th>
                        <th>End Client</th>
                        <th>City</th>
                        <th>Country</th>
                        <th>CheckIn</th>
                        <th>CheckOut</th>
                        <th>Next Visit ETA</th>
                        <th class="text-center" width="120px">Action</th>
                    </tr>
                    </thead>';

        foreach ($repor_data['data'] as $item) {
            $response .= '<tr id="table-row-' . $item['id'] . '">
                    <td>' . $item['ticket_number'] . '</td>' .
                   '<td>' . $item['client'] . '</td>' .
                   '<td>' . $item['endclient'] . '</td>' . 
                   '<td>' . $item['city'] . '</td>' . 
                   '<td>' . $item['country'] . '</td>' . 
                   '<td><span class="check-in-row">' . $item['checkin'] . ' ';
                        if($item['checkin']!=null){
                            $response .= $item['timezone_code'];
                        }
            $response .= '</span></td>' . 
                   '<td><span class="check-out-row"> ';
                        if($item['checkout']==null || $item['checkout']=='0000-00-00 00:00:00'){
                            
                        }
                        else {
                            $response .= $item['checkout'].' '.$item['timezone_code'];
                        }
            $response .= '</span></td>' .  
                   '<td><span class="schedule-row">';
                        if($item['schedule']!='0000-00-00 00:00:00'){
                            $response .= $item['schedule'];
                        }
            $response .=  '</span></td>' .
                   '<td width="120px">';
                    $checkin_btn_hide = '';
                    $checkout_btn_hide = 'hide';
                    $close_btn_disabled = 'disabled';
                    if(($item['checkin']!=null) && ($item['checkout']==null || $item['checkout']=='0000-00-00 00:00:00')){
                        $checkin_btn_hide = 'hide';
                        $checkout_btn_hide = '';
                    }
                    else if(($item['checkin']!=null) && ($item['checkout']!=null)){
                        $close_btn_disabled = '';
                    }
                    
                $response .= '<span> 
                                    <span class="check-in-btn '.$checkin_btn_hide.'">
                                        <button onclick="javascript:_check_in_modal(\'' . $item['id'] . '\');" title="Check In" class="btn btn-info tip"><i class="icomoon-icon-enter"></i></button>
                                    </span>
                                    <span class="check-out-btn '.$checkout_btn_hide.'">
                                        <button onclick="javascript:_check_out_modal(\'' . $item['id'] . '\');" title="Check Out" class="btn btn-warning tip"><i class="icomoon-icon-exit"></i></button>
                                    </span>
                                    <span class=""></span>
                                    <span class="close-btn">
                                        <button '.$close_btn_disabled.' onclick="javascript:_close_ticket_modal(\'' . $item['id'] . '\');" title="Close" class="btn btn-success tip"><i class="fa fa-close s16"></i></button>
                                    </span>
                            </span>';
            $response .= '</td>' . 
                '</tr>';
        }
        $response .= '</table>';
    }
    else {
        $response = '<label class="alert-info mt10">No records available.</label>';
    }
    echo $response;
}
else if ($action == 'check-in') 
{
    $form_data['checkout']=NULL;
    $response = $TicketObj->_edit($form_data);
    if($response['RESPONSE']=='SUCCESS'){
        _send_activity_updates($form_data);
    }
    echo json_encode($response);
}
else if ($action == 'check-out') 
{
    $res = $TicketObj->_edit($form_data);
    if($res['RESPONSE']=='SUCCESS'){
        /* here we are adding new entry in mapping talbe */
        $response = $TicketObj->_mapping_entry($form_data);
        if($response['RESPONSE']=='SUCCESS'){
            _send_activity_updates($form_data);
        }
    }
    
    echo json_encode($res);
}
else if ($action == 'close-ticket') 
{
    $res = $TicketObj->_edit($form_data);
    if($res['RESPONSE']=='SUCCESS'){
        /* here we are adding new entry in mapping talbe */
        $response = $TicketObj->_mapping_entry($form_data);
        if($response['RESPONSE']=='SUCCESS'){
            _send_activity_updates($form_data);
        }
    }
    echo json_encode($response);
}

function _send_activity_updates($form_data = []) {
        $AppUtilObj = new AppUtil();
        $MailUtilObj = new MailUtil();
        $DateTimeUtilObj = new DateTimeUtil();
        $UserObj = new User($_SESSION['USERNAME']);
        $user = $UserObj->config;
        
        $action = isset($form_data['action'])?$form_data['action']:'';
        $ticket_number = isset($form_data['ticket_number'])?$form_data['ticket_number']:'';
        $checkin = isset($form_data['checkin'])?$form_data['checkin']:'';
        $checkout = isset($form_data['checkout'])?$form_data['checkout']:'';
        $timezone_info = $DateTimeUtilObj->_get_timezone_info_by_offset($_SESSION['OFFSET']);
        $code = isset($timezone_info['code'])?$timezone_info['code']:'';
        $comment = isset($form_data['comment'])?" <br/><strong>Comment</strong> - ".$form_data['comment']:'';
        
//        $activity_details = '<table border="1">
//                <tr>
//                    <th>Ticket</th>
//                    <th>User</th>
//                    <th>Date & Time</th>
//                    <th>Action</th>
//                </tr>
//                <tr>';
        $message = $activity_details = $subject = "";
        if($action == 'check-in'){
            $subject = "Check-In";
            $message = "has been checked in at <strong>$checkin $code</strong>";
        }
        else if($action == 'check-out'){
            $subject = "Check-Out";
            //$message = "got check out at <strong>$checkout $code </strong> $comment";
            $schedule = isset($form_data['schedule'])?$form_data['schedule']:'';
            $message = "check out <strong>$checkout $code </strong> and  the next visit is scheduled at <strong>$schedule $code </strong> $comment";     
        }
        else if($action == 'close-ticket'){
            $subject = "Close";
            $message = "got closed at <strong>$checkout $code </strong> $comment";  
        }
        
        $activity_details .= "Ticket number <strong>$ticket_number - $user->username</strong> from <strong>$user->vendorname</strong>  ".$message;
        
        //$activity_details .= "<td align='center'>$ticket_number</td><td>$user->username</td><td>$check_in_out ".$code."</td><td>$action_str</td></tr></table>";
        
        $data = $UserObj->_get_template('activity-updates');
        $content = $data['data']['content'];
        /* REPLACE THE MICROS DEFINED IN TEMPLATE */
        $app_url = APP::URL;
        $app_logo_src = $app_url.APP::LOGO_SRC;
        $search_array = ['::ACTIVITY_DETAILS::','::APP_URL::','::APP_LOGO_SRC::'];
        $replace_array= [$activity_details,    $app_url,   $app_logo_src];
        $final_message = $AppUtilObj->_str_replace($search_array, $replace_array, $content);
        
        $params = [ 'to'=>[$user->email=>$user->name],
                    'cc'=>['check.in.out@decisionone.com'=>'Check-In/Out'],
                    'subject'=>$ticket_number.' - '.$subject.' Activity Updates for '.APP::NAME.' user.',
                    'message'=>$final_message,
                    'attachments'=>[]];
        
        $res = $MailUtilObj->_send_mail($params);
        return $res;    
}
?>