<?php

//ameo_include_css($tpath."css/jquery.dataTables.css");
//cameo_include_js($tpath."js/jquery.dataTables.min.js");
//cameo_include_js($mpath.'js/datatable.js');
chdir("../../../../../");
include_once("includes/cameocore.inc");
cameo_bootsystem();
global $user, $acl,$base_root;
/*$_POST['sSearch'] = 'arc';
$_POST['bSearchable_0']=true;
$_POST['bSearchable_1']=true;
$_POST['bSearchable_2']=true;
$_POST['bSearchable_3']=true;*/
//print_r($_REQUEST);
$aColumns = array("frm.form_id","frm.form_name","frm.form_description","ft.form_type_name","frm.status");
$sTable = "tm_forms_mas frm";
$sJoin  = " JOIN tm_form_type_mas ft ON frm.form_type = ft.form_type_id";
$sIndexColumn = "frm.form_id";
		/* 
		 * Paging
		 */
		$sLimit = "";
		if ( isset( $_POST['iDisplayStart'] ) && $_POST['iDisplayLength'] != '-1' )
		{
			$sLimit = "LIMIT ".mysql_real_escape_string($_POST['iDisplayStart']).", ".
			mysql_real_escape_string( $_POST['iDisplayLength'] );
		}
		/*
		 * Ordering
		 */
		$sOrder = "";
		if ( isset( $_POST['iSortCol_0'] ) && !empty($aColumns) )
		{
			$sOrder = "ORDER BY  ";
			for ( $i=0 ; $i<intval( $_POST['iSortingCols'] ) ; $i++ )
			{
				if ( $_POST[ 'bSortable_'.intval($_POST['iSortCol_'.$i]) ] == "true" )
				{
					$sOrder .= " ".$aColumns[ intval( ($_POST['iSortCol_'.$i]) ) ]." ".
						mysql_real_escape_string( $_POST['sSortDir_'.$i] ) .", ";
				}
			}
			
			$sOrder = substr_replace( $sOrder, "", -2 );
			if ( $sOrder == "ORDER BY" )
			{
				$sOrder = "";
			}
		}
		
		/* 
		 * Filtering
		 * NOTE this does not match the built-in DataTables filtering which does it
		 * word by word on any field. It's possible to do here, but concerned about efficiency
		 * on very large tables, and MySQL's regex functionality is very limited
		 */		
		//$sWhere = "WHERE deleted='0'";
		$sWhere = " WHERE frm.form_deleted=0 AND ft.form_type_id IN(".$_SESSION['master_sheets_id'].") ";
		/*if ( isset($_POST['sSearch']) && $_POST['sSearch'] != "" && !empty($aColumns))
		{
			if ( $sWhere == "" )
			{
				$sWhere = "WHERE ";
			}
			else
			{
				$sWhere .= " AND ";
			}
			for ( $i=0 ; $i<count($aColumns) ; $i++ )
			{
				
				$sWhere .= " ".$aColumns[$i]." LIKE '%s%' OR ";
			}
			$sWhere = substr_replace( $sWhere, "", -3 );
			$sWhere .= ')';
		}*/
		
		/* Individual column filtering */
		$col_counter = 0;
		if(!empty($aColumns) && trim($_POST['sSearch']) != '') {
			if ( $sWhere == "" )
			{
				$sSWhere = "WHERE ";
			}
			else
			{
				$sSWhere .= " AND (";
			}
			for ( $i=0 ; $i<count($aColumns) ; $i++ )
			{
				//$_POST['sSearch_'.$i] != ''
				if ( isset($_POST['bSearchable_'.$i]) && $_POST['bSearchable_'.$i] == "true" &&  $_POST['sSearch'] != '')
				{
					
					$sSWhere .= "".$aColumns[$i]." LIKE '%%%s%%' OR ";					
					$col_counter++;
				}
				
			}			
			if(trim(substr($sSWhere,-3)) == 'OR') {
					$sSWhere = substr( $sSWhere, 0, -3 );
			}
			if ( $sWhere != "" )
			{
				$sWhere .= $sSWhere .")";
			} else {
				$sWhere .= $sSWhere;
			}
		}
		/*
		 * SQL queries
		 * Get data to display
		 */
		if(!empty($aColumns)) {
			$sQuery = "
				SELECT SQL_CALC_FOUND_ROWS ".str_replace(" , ", " ", implode(", ", $aColumns))."
				FROM  $sTable 
				$sJoin  
				$sWhere
				$sOrder
				$sLimit
				";
				//$_t = mysql_query($sQuery);
			
			if(trim($_POST['sSearch']) != '') {
				//echo sprintf($sQuery, $_POST['sSearch']);
				$rResult = cameo_query($sQuery, $_POST['sSearch']);//cameo_query_alt($sQuery);
			} else {
				//echo sprintf($sQuery);
				$rResult = cameo_query($sQuery);
			}
			
			//print_r(mysql_fetch_array($rResult));
			//print_r(mysql_fetch_array($_t));
			/* Data set length after filtering */
			$sQueryCnt = "
				SELECT FOUND_ROWS() as cnt
			";
			$aResultFilter = cameo_query($sQueryCnt);
			$aResultFilterTotal = cameo_fetch_object( $aResultFilter );			
			$iFilteredTotal = $aResultFilterTotal->cnt;//$aResultFilterTotal[0];
			//print_r(cameo_fetch_object($rResult));
			/* Total data set length */
			$sQueryTot = "
				SELECT COUNT(".$sIndexColumn.") as cnt
				FROM   $sTable
			";
			$aResultRs = cameo_query($sQueryTot);
			$aResultTotal = cameo_fetch_object( $aResultRs );			
			$iTotal = $aResultTotal->cnt;			
			 /*
			 * Output
			 */
			$output = array();
			$output = array(
				"sEcho" => intval($_POST['sEcho']),
				"iTotalRecords" => $iTotal,
				"iTotalDisplayRecords" => $iFilteredTotal,
				"aaData" => array()
			);
			//echo '<pre>';
			if ( isset( $_POST['iDisplayStart'] ) && $_POST['iDisplayStart'] != '0' ) {
				$s_no = $_POST['iDisplayStart'] +  1;//($_POST['sEcho'] * $_POST['iDisplayLength']) + 1;
			} else {
				$s_no = 1;
			}
			$i=0;
			while ( $aRow = cameo_fetch_object($rResult) )
			{					
				//$block_content['results'][$aRow->emp_id]["details"] = array($aRow->user_id,$aRow->emp_id, $aRow->name, $aRow->email_id, $aRow->designation);
                //$block_content['results'][$aRow->emp_id]["role"][] = $aRow->role_id;
				$row = array();
				$row[] = $s_no;				
				$row[] = $aRow->form_name;
				$row[] = $aRow->form_description;
				$row[] = $aRow->form_type_name;
				$row[] = ($aRow->status == 1)?'Active':'Inactive';
				$action = '';
				$action = '<a href="configure/'.$aRow->form_id.'">Configure</a> | <a href="edit/'.$aRow->form_id.'">Edit</a> | <a href="history/'.$aRow->form_id.'">History</a> | <a href="javascript:void(0);" onclick="deletefrom('.$aRow->form_id.');">Delete</a>';// | <a href="#" id="delete_'.$i.'_'.$aRow->form_id.'" class="delete">Delete</a>'; 				
				$row[] = $action; 
				$output['aaData'][] = $row;
				$s_no++;
				$i++;
			}		
		} else {
			$iTotal = 0;
			$iFilteredTotal = 0;
			$output = array (
				"sEcho" => intval($_POST['sEcho']),
				"iTotalRecords" => $iTotal,
				"iTotalDisplayRecords" => $iFilteredTotal,
				"aaData" => array()
			);
		}		
   echo json_encode($output);
?>

