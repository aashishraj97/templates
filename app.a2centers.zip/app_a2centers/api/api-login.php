<?php 
include_once $_SERVER['DOCUMENT_ROOT']."/includes/session-start.php";
include_once  $_SERVER['DOCUMENT_ROOT'].'/includes/config.php'; 
include_once  $_SERVER['DOCUMENT_ROOT'].'/class/util/DBUtil.php';
include_once  $_SERVER['DOCUMENT_ROOT'].'/class/User.php';
$DBUtilObj = new DBUtil();

$action = $_REQUEST['action'];
if ($action == 'login') {
        $response['RESPONSE'] = '';
        $username = isset($_REQUEST['username'])?trim($_REQUEST['username']):'';
        $password = isset($_REQUEST['password'])?$_REQUEST['password']:'';     
        $_SESSION['ROLE'] = 'admin';
        session_regenerate_id(true);     
        /*preg_match('/^[A-Za-z][A-Za-z0-9_-]{3,31}$/', $username)*/
        $UserObj = new User($username);
        if ($UserObj->_is_valid_user()) {
            if ($UserObj->_is_valid_password($password)) {
                $user = $UserObj->config;
                if($user->is_active){
                    /* SET SESSION */
                    $UserObj->_set_session();
                    $_SESSION['OFFSET'] = isset($_REQUEST['local_time_offset'])?$_REQUEST['local_time_offset']:''; 
                    /* UPDATE LAST LOGIN */
                    $UserObj->_update_on_login($_SESSION['USERNAME']);

                    /* ADD LOGIN RECORD */
                    $UserObj->_add_login_record();

                    /* SET COOKIE */
                    include_once  $_SERVER['DOCUMENT_ROOT'].'/class/util/AppUtil.php';
                    $AppUtilObj = new AppUtil;
                    if (isset($_REQUEST['remember']) && $_REQUEST['remember'] == 'on') {
                        $AppUtilObj->_set_cookie('user', $_SESSION['USERNAME'], 5);
                    } else {
                        $AppUtilObj->_remove_cookie('user');
                    }
                    $response['RESPONSE'] = 'SUCCESS';
                }
                else {
                    $response['RESPONSE'] = 'Your account ('.$user->username.') is inactive. Contact your '.APP::NAME.' administrator to activate it.';                    
                }
            } else {
                $response['RESPONSE'] = 'Wrong password. Try again or click Forgot password to reset it.';
            }
        } else {
            $response['RESPONSE'] = 'Couldn\'t find your account';
        }
        
      echo json_encode($response);
}

else if ($action == 'logout') {
    $UserObj = new User();
    $UserObj->_add_logout_record();
    $response['RESPONSE'] = 'SUCCESS';
    unset($_SESSION['USERNAME']);
    session_unset();
    session_destroy();
    
    echo json_encode($response);
}
else if ($action == 'change-password') {                   
    $UserObj = new User();
    $response = $UserObj->_change_password($_POST);
    echo json_encode($response);
}
else if ($action == 'get-password') {

    $UserObj = new User();
    $username = isset($_REQUEST['username'])?$UserObj->_escape_string(trim($_REQUEST['username'])):'';
    $stmt = $UserObj->_get_db_connection()->prepare("SELECT * FROM ".DBTable::USERS." WHERE username = ?;");
    $stmt->bind_param('s', $username); // 's' specifies the variable type => 'string'
    $stmt->execute();
    $result = $stmt->get_result();
    $user = [];
    while ($row = $result->fetch_assoc()) {
        $user = $row;
    }
    
    if (count($user)>0) {
    
        include_once  $_SERVER['DOCUMENT_ROOT'].'/class/util/AppUtil.php';
        $AppUtilObj = new AppUtil();
        $new_password = $UserObj->_generate_random_password();
        
        $data = $UserObj->_get_template('temporary-password');
        $content = $data['data']['content'];
        /* REPLACE THE MICROS DEFINED IN TEMPLATE */
        $app_url = APP::URL;
        $app_logo_src = $app_url.APP::LOGO_SRC;
        $search_array = ['::NAME::','::USERNAME::','::PASSWORD::','::APP_NAME::','::APP_URL::','::APP_LOGO_SRC::'];
        $replace_array= [$user['name'],$user['username'],$new_password, APP::NAME,    $app_url,   $app_logo_src];
        $final_message = $AppUtilObj->_str_replace($search_array, $replace_array, $content);
        
        $params = [ 'to'=>[$user['email']=>$user['name']],
                    'cc'=>[],
                    'bcc'=>[],
                    'subject'=>'Temporary Password for your '.APP::NAME.' account.',
                    'message'=>$final_message,
                    'attachments'=>[]];
        
        include_once  $_SERVER['DOCUMENT_ROOT'].'/class/util/MailUtil.php';   
        $MailUtilObj = new MailUtil();
        $res = $MailUtilObj->_send_mail($params);
        if($res['RESPONSE']=='SUCCESS'){
            $response['MESSAGE'] = '<div class="alert alert-info fade in">
                                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                        <br/>
                                        Your new password has been sent 
                                        to your registered email address '.$AppUtilObj->_partially_hide_email_address($user['email']).'. check your email to login.
                                    </div>';
            $response['RESPONSE'] = 'SUCCESS';   
            /** here you can change the password */
            $data['id'] = $user['id'];
            $data['check_login'] = '0';
            $data['confirm_password'] = $new_password;
            $UserObj->_change_password($data);
        }
    } else {
        $response['MESSAGE'] = '<div class="alert alert-info fade in">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                    <strong>Sorry!</strong><br/>
                                        Couldn\'t find your account<br/>Please! try again with a valid username.
                                </div>';
        $response['RESPONSE'] = 'ERROR';
    }
    
    echo json_encode($response);
}
else if ($action == 'fetch-password') {
    
}
?>
