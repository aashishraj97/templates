<?php include_once $_SERVER['DOCUMENT_ROOT'] . "/includes/config.php"; ?>
<!DOCTYPE html>
<html>
    <head>
        <title><?=APP::NAME?> | 500 Internal Server Error</title>
        <meta http-equiv="content-type" content="text/html; charset=windows-1252">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!--<link rel="stylesheet" href="./error.css" type="text/css"/>-->
        <style>
            html {
                height:100%; 
            }

            body {
                color: #444; 
                margin:0;
                font: normal 14px/20px Arial, Helvetica, sans-serif; 
                height:100%; 
                background-color: #fff;
            }

            #main-div {
                height:auto; min-height:100%;
            }

            .sub-div {
                text-align: center; 
                width:800px; 
                margin-left: -400px; 
                position:absolute; 
                top: 10%; 
                left:50%;
            } 

            h1 {
                margin:0; font-size:150px; line-height:150px; font-weight:bold;
            }

            h2 {
                margin-top:20px;font-size: 30px;
            }
            a {
                text-decoration: none;
            }
        </style>
    </head>
    <body>
        <div id="main-div">     
            <div class="sub-div">
                <!-- always give a preloaded image src -->
                <img src="<?=APP::AVATAR_SRC?>" alt="Avatar" />
            
                <h1>500</h1>
                <h2>Internal Server Error</h2>
                <p>The server encountered an internal error or misconfiguration and was unable to complete your request.</p>
                
                <h3>
                    <a href="<?=APP::HOME_URL?>" class="btn btn-info btn-md">Back to Home</a>
                </h3>
            </div>
        </div>
    </body>
</html>