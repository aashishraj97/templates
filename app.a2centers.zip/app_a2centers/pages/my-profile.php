<?php 
include_once $_SERVER['DOCUMENT_ROOT'] . "/includes/common.php"; 
$DBUtilObj = new DBUtil();
$data['where'] = "username='".$_SESSION['USERNAME']."'";
$user = $DBUtilObj->_select(DBTable::USERS,$data)->_fetch_object();

?>

<div id="my-profile-div">
    
    <div class="row mt20">
        <div class="col-lg-12">
            <div class="panel panel-default toggle panelMove panelClose panelRefresh">
                <div class="panel-heading">
                    <h4 class="panel-title"><i class="s16 icomoon-icon-user m0 pr5"></i> Profile Details</h4>
                </div>
                <div class="panel-body">
                    <div class="row profile">
                        <!-- Start .row -->
                        <div class="col-md-4">
                            <div class="profile-avatar">
                                <img src="<?=APP::AVATAR_SRC?>" alt="Avatar" width="100px">
                                <p class="mt10">
                                    Online
                                    <span class="device">
                                        <i class="fa fa-mobile s16"></i>
                                    </span>
                                </p>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="profile-name">
                                <h3><?=$user->name?></h3>
                                <p class="job-title mb0"><i class="fa fa-user"></i> 
                                    Role: <?=$user->role?></p><br/><br/>
                                
                                <a href="javascript:_change_password_modal();" class="btn btn-primary btn-large mr10"> <i class="icomoon-icon-lock"></i>Change Password</a>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="contact-info bt">
                                <div class="row">
                                    <!-- Start .row -->
                                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                                        <dl class="mt20">
                                            <dt class="text-muted">Username</dt>
                                            <dd><?=$user->username?></dd>
                                        </dl>
                                    </div>
                                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                                        <dl class="mt20">
                                            <dt class="text-muted">Vendorname</dt>
                                            <dd><?=$user->vendorname?></dd>
                                        </dl>
                                    </div>
                                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                                        <dl class="mt20">
                                            <dt class="text-muted">Email</dt>
                                            <dd><?=$user->email?></dd>
                                        </dl>
                                    </div>
                                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                                        <dl class="mt20">
                                            <dt class="text-muted">Mobile</dt>
                                            <dd><?=$user->mobile?> <?php if($user->alternative_mobile != ''){echo ', ' . $user->alternative_mobile;} ?></dd>
                                        </dl>
                                    </div>
                                    
                                </div>
                                <!-- End .row -->
                            </div>
                        </div>
                        <div class="col-md-12 hide">
                            <div class="profile-info bt">
                                <h5 class="text-muted">Profile info</h5>
                                <p class="color-red">Not Available</p>
                            </div>  
                            <div class="social bt">
                                <h5 class="text-muted">Social</h5>
                                    <span class="text-muted">
                                        <i class="fa fa-facebook-square"></i>
                                        Facebook 
                                    </span>
                                    <span class="text-muted">
                                        <i class="fa fa-twitter"></i>
                                        Twitter 
                                    </span>
                                    <span class="text-muted">
                                        <i class="fa fa-youtube-play"></i>
                                        YouTube 
                                    </span>
                                    <span class="text-muted">
                                        <i class="fa fa-google-plus"></i>
                                        Google+ 
                                    </span>
                                    <span class="text-muted">
                                        <i class="fa fa-linkedin"></i>
                                        LinkedIn 
                                    </span>
                                    <span class="text-muted">
                                        <i class="fa fa-pinterest"></i>
                                        Pinterest 
                                    </span>
                            </div>
                        </div>
                    </div>

                    <!-- col-lg-6 end here -->
                </div>
                <!-- End .row -->
            </div>
        </div>
        <!-- End .panel -->
    </div>
    <!-- col-lg-4 end here -->
</div>