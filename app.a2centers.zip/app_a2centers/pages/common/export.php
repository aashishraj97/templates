<?php 
include_once $_SERVER['DOCUMENT_ROOT'] . "/includes/common.php"; 
$DBUtilObj = new DBUtil();
$DateTimeUtilObj = new DateTimeUtil();

header("Content-Type: application/vnd.ms-excel; name='excel'");
header("Content-disposition:  attachment; filename=reports.xls");

$where = $_GET['query'];
$context = $_GET['context'];
$num_rows = 0;
if($context == 'DASHBOARD'){
    $TicketObj = new Ticket();
    $report_data = $TicketObj->_get(['where'=>$where]);
    $num_rows = $report_data['num_rows'];
    $report_data = $report_data['data'];
}
else if($context == 'REPORT'){
    $query = "SELECT t.id, `ticket_number`, `client`, `endclient`, `city`, `country`, `ftename`, `vendorname`, tm.checkin, tm.checkout, tm.timezone, tm.timezone_code, tm.comment, tm.by_user, `closed` FROM ".DBTable::TBL_TICKETS." t JOIN ".DBTable::TBL_TICKETS_MAPPING." tm ON(t.id = tm.ticket_id) ".$where;
    
    $DBUtilObj->_run_query($query);
    $num_rows = $DBUtilObj->_num_rows();
    $report_data = $DBUtilObj->_fetch_all();
}
else if($context == 'LOGS'){
    $LogUtilObj = new LogUtil();
    $logs_data = $LogUtilObj->_get(['where'=>$where]);
    $num_rows = $logs_data['num_rows'];
    $logs_data = $logs_data['data'];
}


if ($num_rows > 0) {
    $table = '<table>';
    
    if($context == 'LOGS'){
        $table .= ' <thead>
                    <tr><th>Date & Time</th>
                        <th>Type</th>
                        <th>Message</th>
                        <th>By User</th>
                    </tr>
                    </thead>';

        foreach ($logs_data as $item) {
         $table .= '<tr id="' . $item['id'] . '">
                        <td>' . $item['date_time'] . '</td>' .
                       '<td>' . $item['type'] . '</td>' . 
                       '<td>' . $item['message'] . '</td>' . 
                       '<td>' . $item['by_user'] . '</td>
                    </tr>';
        }
    }
    else {
        $table .= ' <thead>
                    <tr>
                        <th>TicketNo</th>
                        <th>Client</th>
                        <th>End Client</th>
                        <th>City</th>
                        <th>Country</th>
                        <th>FTEName</th>
                        <th>Vendor</th>
                        <th>CheckIn</th>
                        <th>CheckOut</th>';
                        if($context == 'REPORT'){
                            $table .= '<th>By User</th>';
                        }
                        $table .= '<th>WorkHours</th>
                        <th>Status</th>';
                        if($context == 'REPORT'){$table .= '<th>Comment</th>';}
         $table .= '</tr>
                    </thead>';

        foreach ($report_data as $item) {
            $table .= '<tr id="' . $item['id'] . '">
                    <td>' . $item['ticket_number'] . '</td>' .
                   '<td>' . $item['client'] . '</td>' .
                   '<td>' . $item['endclient'] . '</td>' . 
                   '<td>' . $item['city'] . '</td>' . 
                   '<td>' . $item['country'] . '</td>' . 
                   '<td>' . $item['ftename'] . '</td>' . 
                   '<td>' . $item['vendorname'] . '</td>' . 
                   '<td>' . $item['checkin'] . " " .$item['timezone_code']. '</td>' . 
                   '<td>' . $item['checkout'] . " " .$item['timezone_code']. '</td>';
                    if($context == 'REPORT'){
                        $table .= '<td>' . $item['by_user'] . '</td>';
                    } 
                   $table .= '<td>';
                    $time_dff = '';
                    if($item['checkin']!=null && $item['checkout']!=null){
                        $since_start = $DateTimeUtilObj->_datetime_diff($item['checkin'],$item['checkout']);
                        $time_dff = $since_start->h. ' hours';
                    }
            $table .= $time_dff . '</td><td>';
                    $status = 'Closed';
                    if($item['closed']=='No'){
                        $status = 'Open';
                    }
            $table .= $status . '</td>';
                    if($context == 'REPORT'){$table .= '<td>' . $item['comment'] . '</td>';}
        $table .= '</tr>';
        }
    }
        $table .= '</table>';
    echo $table;
}
?>