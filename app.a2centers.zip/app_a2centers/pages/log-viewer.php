<?php include_once $_SERVER['DOCUMENT_ROOT'] . "/includes/common.php"; ?>
<div id="log-viewer-main-div">
    <div class="row mt20">
        <div class="col-lg-12">
             <div class="panel panel-default toggle panelMove panelClose panelRefresh">
                 <div class="panel-heading">
                    <h4 class="panel-title">Log Viewer</h4>
                </div>
                <div class="panel-body">
                    <form id="filter-log-form" action="#">    
                        <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                            <input type="hidden"  name="type" id="type" value="<?php echo $type; ?>"/>
                                Log Type: 
                                <select class="form-control input-medium" name="log_type" id="log-type">
                                    <option value="">All Logs</option>
                                    <option value="error">Error</option>
                                    <option value="info">Info</option>
                                    <option value="debug">Debug</option>
                                    <option value="alert">Alert</option>
                                    <option value="login">Login</option>
                                    <option value="admin">Admin</option>
                                </select>
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                            From Date: 
                            <input class="form-control input-medium datepicker" type="text" name="from_date" id="from-date" placeholder="dd-mm-yyyy"/>
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                            To Date: 
                            <input class="form-control input-medium datepicker" type="text" name="to_date" id="to-date" placeholder="dd-mm-yyyy"/>
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                            Search Text: 
                            <input class="form-control input-medium" type="text" name="search" id="search" placeholder="Search Text" />
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                            Limit: 
                            <input class="form-control input-medium" type="text" name="row_limit" id="row-limit" placeholder="No of rows"/>
                        </div>								
                    </form>
                    
                    <div class="form-group">
                        <div class="col-lg-1 col-md-1 col-sm-6 col-xs-6 mt20">
                            <button onclick="javascript:_search_logs_submit();" id="log-filter-btn" class="btn btn-info"><i class="fa fa-search"></i></button>
                        </div>	

                        <div class="col-lg-1 col-md-1 col-sm-6 col-xs-6 mt20">
                            <button onclick="javascript:_export_to_excel('log-table','LOGS');" id="export-excel-btn" class="btn btn-warning"><i class="fa fa-download"></i></button>
                        </div>
                    </div>
                    <div id="log-listing-div" class="table-responsive col-lg-12 col-md-12 col-sm-12 col-sm-12"></div>
            <!--     Start .row 
                <div class="row">
                    <div class="col-lg-12">
                         col-lg-12 start here 
                        <div class="panel panel-default toggle panelMove panelClose panelRefresh">
                             Start .panel 
                            <div class="panel-heading">
                                <h4 class="panel-title">Log Listing</h4>
                            </div>
                            <div class="panel-body">

                            </div>
                             End .panel 
                        </div>
                         col-lg-12 end here 
                    </div>
                </div>-->
                </div>
            </div>
        </div>
    </div>
</div>
<script src="scripts/log-viewer.js" type="text/javascript"></script>