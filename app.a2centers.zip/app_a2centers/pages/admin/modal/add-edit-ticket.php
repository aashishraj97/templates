<?php include_once $_SERVER['DOCUMENT_ROOT']."/includes/common.php";
$VendorObj = new Vendor();
$vendors = $VendorObj->_get();
$country = $VendorObj->_select(DBTable::COUNTRY, ['fields'=>['nicename']])->_fetch_all();
$action = 'add';
$default_checked = 'checked';
if(isset($_REQUEST['id'])){
    $action  = 'edit';
    $default_checked = '';
    $TicketObj = new Ticket();
    $id      = $_REQUEST['id'];
    $where   = 'id='.$_REQUEST['id'];
    $data    = $TicketObj->_get(['where'=>$where]);
    $ticket    = $data['data'][0];
    
    $UserObj = new User();
    $user_att['where'] = 'vendorname="'.$ticket['vendorname'].'"';
    $user_att['fields'] = ['name','username'];
    $users = $UserObj->_get($user_att);
}
?>
<div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">
        <span aria-hidden="true">&times;</span><span class="sr-only">Close</span>
    </button>
    <h4 class="modal-title" id="myModalLabel2"><?=ucfirst($action)?> Ticket</h4>
</div>
<div class="modal-body">
	<div id="response-msg" class="row text-center"></div>
	<!-- Start Form -->	
	<form id="<?=$action?>-ticket-form" name="<?=$action?>-ticket-form" class="form-horizontal" role="form">
                <?php if($action == 'edit'){echo '<input type="hidden" id="id" name="id" value="'.$id.'"/>';}?>
		<div class="bs-callout bs-callout-info fade in m0">
                        <div class="row">
                                <div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12 m0 mb10">
                                    <label>Ticket No.<span class="color-red">*</span></label>
                                    <div class="input-group input-icon">
                                        <span class="input-group-addon"><i class="icomoon-icon-tag s16"></i></span>
                                        <?php if($action == 'edit')
                                                {echo '<input type="text" value="'.$ticket['ticket_number'].'" disabled class="form-control"/>';}
                                           else { ?>
                                        <input type="text" id="ticket_number" name="ticket_number" class="form-control"  placeholder="enter ticket number">
                                          <?php } ?>
                                    </div>
                                </div>
                                <div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12 m0 mb10">
                                    <label>Client<span class="color-red">*</span></label>
                                    <div class="input-group input-icon">
                                        <span class="input-group-addon"><i class="icomoon-icon-user s16"></i></span>
                                        <input type="text" id="client" name="client" class="form-control tip" value="<?=isset($ticket['client'])?$ticket['client']:''?>" title="<?=isset($ticket['client'])?$ticket['client']:''?>" placeholder="enter client name">
                                    </div>
                                </div>
                        </div>
                    
                        <div class="row">
                                <div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12 m0 mb10">
                                    <label>Vendor<span class="color-red">*</span></label>
                                    <?php if($action == 'edit')
                                        {echo '<div class="input-group input-icon">
                                        <span class="input-group-addon"><i class="icomoon-icon-user-2 s16"></i></span>
                                        <input type="text" value="'.$ticket['vendorname'].'" disabled class="form-control"/></div>';}
                                   else { ?>
                                    <select class="form-control select2" name="vendorname" id="vendorname" onchange="javascript:_on_change_vendor(this.value);">
                                        <option value="">Select</option>
                                        <?php foreach ($vendors['data'] as $key => $value):
                                            $selected = '';
                                            if(($action=='edit') && ($ticket['vendorname']==$value['vendorname'])){
                                                $selected = 'selected';
                                            }
                                            echo '<option value="'.$value['vendorname'].'" '.$selected.'>'.$value['vendorname'].'</option>';
                                         endforeach; ?>
                                    </select>
                                    <?php } ?>
                                </div>
                                <div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12 m0 mb10">
                                    <label>FTE Name<span class="color-red">*</span></label>
                                    <select class="form-control select2" name="ftename" id="ftename">
                                        <option value="">Select</option>
                                        <?php foreach ($users['data'] as $key => $value):
                                            $selected = '';
                                            if(($action=='edit') && ($ticket['ftename']==$value['username'])){
                                                $selected = 'selected';
                                            }
                                            echo '<option value="'.$value['username'].'" '.$selected.'>'.$value['username'].'</option>';
                                         endforeach; ?>
                                    </select>
                                </div>
                        </div>
                    
                        <div class="row">
                                <div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12 m0 mb10">
                                    <label>End Client<span class="color-red">*</span></label>
                                    <div class="input-group input-icon">
                                        <span class="input-group-addon"><i class="fa fa-user s16"></i></span>
                                        <input type="text" id="endclient" name="endclient" class="form-control tip" value="<?=isset($ticket['endclient'])?$ticket['endclient']:''?>" title="<?=isset($ticket['endclient'])?$ticket['endclient']:''?>" placeholder="enter end client name">
                                    </div>
                                </div>
                                <div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12 m0 mb10">
                                    <label>City<span class="color-red">*</span></label>
                                    <div class="input-group input-icon">
                                        <span class="input-group-addon"><i class="iconic-icon-home s16"></i></span>
                                        <input type="text" id="city" name="city" class="form-control tip" value="<?=isset($ticket['city'])?$ticket['city']:''?>" title="<?=isset($ticket['city'])?$ticket['city']:''?>" placeholder="enter city name">
                                    </div>
                                </div>
                        </div>
                        <div class="row">
                                <div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12 m0 mb10">
                                    <label>Country<span class="color-red">*</span></label>
                                    <select class="form-control select2" name="country" id="country">
                                        <option value="">Select</option>
                                        <?php foreach ($country as $key => $value):
                                            $selected = '';
                                            if(($action=='edit') && ($ticket['country']==$value['nicename'])){
                                                $selected = 'selected';
                                            }
                                            echo '<option value="'.$value['nicename'].'" '.$selected.'>'.$value['nicename'].'</option>';
                                         endforeach; ?>
                                    </select>
                                </div>
                                <?php if($action=='edit') { ?>
                                <div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12 m0 mb10">
                                    <label>Status<span class="color-red">*</span></label>
                                    <select class="form-control select2 required" name="closed" id="closed">
                                        <option value="">Select</option>
                                        <?php 
                                        $status = ['Yes'=>'Close','No'=>'Open'];
                                        
                                        foreach ($status as $key => $value):
                                            $selected = '';
                                            if($ticket['closed']==$key){
                                                $selected = 'selected';
                                            }
                                            echo '<option value="'.$key.'" '.$selected.'>'.$value.'</option>';
                                        endforeach; ?>
                                    </select>
                                </div>
                                <?php } ?>
                        </div>
                </div>
	</form>
	<!-- End Form -->
</div>
<div class="modal-footer" id="the-controls">
    <button type="button" class="btn btn-danger" data-dismiss="modal"><i class=" icomoon-icon-cancel-circle-2"></i>Close</button>
    <button type="button" class="btn btn-success" onclick="javascript:_<?=$action?>_ticket();" id="<?=$action?>-ticket-btn"><i class="icomoon-icon-checkmark-circle-2 "></i><?=ucfirst($action)?></button>
</div>
<script src="/scripts/admin/modal/add-edit-ticket.js"></script>