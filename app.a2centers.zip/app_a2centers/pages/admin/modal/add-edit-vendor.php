<?php include_once $_SERVER['DOCUMENT_ROOT']."/includes/common.php";
$action = 'add';
if(isset($_REQUEST['id'])){
    $action = 'edit';
    $VendorObj  = new Vendor();
    $id         = $_REQUEST['id'];
    $where      = 'id='.$_REQUEST['id'];
    $data       = $VendorObj->_get(['where'=>$where]);
    $vendor    = $data['data'][0];
}
?>
<div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">
        <span aria-hidden="true">&times;</span><span class="sr-only">Close</span>
    </button>
    <h4 class="modal-title" id="myModalLabel2"><?=ucfirst($action)?> Vendor</h4>
</div>
<div class="modal-body">
        <div class="row">
            <img src="<?=APP::AVATAR_SRC?>" class="center-block img-responsive w-50" width="100px" alt="Avatar" >    
        </div>
	<div id="response-msg" class="row text-center"></div>
	<!-- Start Form -->	
	<form id="<?=$action?>-vendor-form" name="<?=$action?>-vendor-form" class="form-horizontal" role="form">
                <?php if($action == 'edit'){echo '<input type="hidden" id="id" name="id" value="'.$id.'"/>';}?>
		<div class="bs-callout bs-callout-info fade in m0">                    
                        <div class="row">
                                <div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12 m0 mb10">
                                    <label>Vendor Name<span class="color-red">*</span></label>
                                    <div class="input-group input-icon">
                                        <span class="input-group-addon"><i class="icomoon-icon-user-2 s16"></i></span>
                                        <?php if($action == 'edit')
                                                {echo '<input type="text" value="'.$vendor['vendorname'].'" disabled class="form-control" />';}
                                           else { ?>
                                        <input type="text" id="vendorname" name="vendorname"  class="form-control" placeholder="Enter Vendor Name..."/>
                                          <?php } ?>
                                    </div>
                                </div>
                            
                                <div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12 m0 mb10">
                                    <label>Email<span class="color-red">*</span></label>
                                    <div class="input-group input-icon">
                                        <span class="input-group-addon"><i class="iconic-icon-mail s16"></i></span>
                                        <input type="text" id="email" name="email" value="<?=isset($vendor['email'])?$vendor['email']:''?>" class="form-control" placeholder="Enter Email Address..."/>
                                    </div>
                                </div>
                            
                        </div>
                </div>
	</form>
	<!-- End Form -->
</div>
<div class="modal-footer" id="the-controls">
    <button type="button" class="btn btn-danger" data-dismiss="modal"><i class=" icomoon-icon-cancel-circle-2"></i>Close</button>
    <button type="button" class="btn btn-success" onclick="javascript:_<?=$action?>_vendor();" id="<?=$action?>-vendor-btn"><i class="icomoon-icon-checkmark-circle-2 "></i><?=ucfirst($action)?></button>
</div>
<script src="/scripts/admin/modal/add-edit-vendor.js"></script>