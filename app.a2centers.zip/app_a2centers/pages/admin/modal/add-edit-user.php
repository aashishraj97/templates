<?php include_once $_SERVER['DOCUMENT_ROOT']."/includes/common.php";
$VendorObj = new Vendor();
$vendors = $VendorObj->_get();

$action = 'add';
$default_checked = 'checked';
if(isset($_REQUEST['id'])){
    $action  = 'edit';
    $default_checked = '';
    $UserObj = new User();
    $id      = $_REQUEST['id'];
    $where   = 'id='.$_REQUEST['id'];
    $data    = $UserObj->_get(['where'=>$where]);
    $user    = $data['data'][0];
}
?>
<div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">
        <span aria-hidden="true">&times;</span><span class="sr-only">Close</span>
    </button>
    <h4 class="modal-title" id="myModalLabel2"><?=ucfirst($action)?> User</h4>
</div>
<div class="modal-body">
        <div class="row">
            <img src="<?=APP::AVATAR_SRC?>" class="center-block img-responsive w-50" width="100px" alt="Avatar" >    
        </div>
	<div id="response-msg" class="row text-center"></div>
	<!-- Start Form -->	
	<form id="<?=$action?>-user-form" name="<?=$action?>-user-form" class="form-horizontal" role="form">
                <?php if($action == 'edit'){echo '<input type="hidden" id="id" name="id" value="'.$id.'"/>';}?>
		<div class="bs-callout bs-callout-info fade in m0">

                        <div class="row">
                                <div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12 m0 mb10">
                                    <label>Name<span class="color-red">*</span></label>
                                    <div class="input-group input-icon">
                                        <span class="input-group-addon"><i class="icomoon-icon-user-4 s16"></i></span>
                                        <input type="text" id="name" name="name" value="<?=isset($user['name'])?$user['name']:''?>" class="form-control" placeholder="enter name..."/>
                                    </div>
                                </div>
                                <div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12 m0 mb10">
                                    <label>Mobile<span class="color-red">*</span></label>
                                    <div class="input-group input-icon">
                                        <span class="input-group-addon"><i class="fa fa-phone s16"></i></span>
                                        <input type="text" id="mobile" name="mobile" value="<?=isset($user['mobile'])?$user['mobile']:''?>" class="form-control" placeholder="enter mobile number..."/>
                                    </div>
                                </div>
                        </div>
                    
                        <div class="row">
                                <div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12 m0 mb10">
                                    <label>Email<span class="color-red">*</span></label>
                                    <div class="input-group input-icon">
                                        <span class="input-group-addon"><i class="iconic-icon-mail s16"></i></span>
                                        <input type="text" id="email" name="email" value="<?=isset($user['email'])?$user['email']:''?>" class="form-control" placeholder="enter email address..."/>
                                    </div>
                                </div>
                                <div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12 m0 mb10">
                                    <label>Alternative Mobile</label>
                                    <div class="input-group input-icon">
                                        <span class="input-group-addon"><i class="fa fa-phone s16"></i></span>
                                        <input type="text" id="alternative_mobile" name="alternative_mobile" value="<?=isset($user['alternative_mobile'])?$user['alternative_mobile']:''?>" class="form-control" placeholder="enter alternative mobile number..."/>
                                    </div>
                                </div>
                                
                        </div>
                        <div class="row">
                                <div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12 m0 mb10">
                                    <label>Username<span class="color-red">*</span></label>
                                    <div class="input-group input-icon">
                                        <span class="input-group-addon"><i class="icomoon-icon-user s16"></i></span>
                                        <?php if($action == 'edit')
                                                {echo '<input type="text" value="'.$user['username'].'" disabled class="form-control"/>';}
                                           else { ?>
                                        <input type="text" id="username" name="username" class="form-control" placeholder="enter username..."/>
                                          <?php } ?>
                                    </div>
                                </div>
                                <div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12 m0 mb10">
                                    <?php if($action == 'edit'){ ?>
                                    <label class="">Account</label><br/>
                                    <div class="pr0 m0 mt5 mb10 toggle-custom toggle-inline">
                                        <label class="toggle" data-on="ON" data-off="OFF">
                                            <input type="radio" id="active" name="is_active" value="1" <?=(isset($user['is_active'])&&($user['is_active']=='1'))?'checked':''?>>
                                            <span class="button-radio"></span>
                                        </label>
                                        <label for="radio-toggle4">Active</label>
                                    </div>
                                    <div class="ml20 pl0 m0 mt5 mb10 toggle-custom toggle-inline">
                                        <label class="toggle" data-on="ON" data-off="OFF">
                                            <input type="radio" id="in_active" name="is_active" value="0" <?=(isset($user['is_active'])&&($user['is_active']=='0'))?'checked':''?>>
                                            <span class="button-radio"></span>
                                        </label>
                                        <label for="radio-toggle5">InActive</label>
                                    </div>
                                    
                                    <?php } else {  ?>
                                    <label>Password<span class="color-red">*</span></label>
                                    <div class="input-group input-icon">
                                        <span class="input-group-addon"><i class="icomoon-icon-lock s16"></i></span>
                                        <?php if($action == 'edit')
                                                {echo '<input type="password" value="'.$user['password'].'" disabled class="form-control"/>';}
                                           else { ?>
                                        <input type="password" id="password" name="password" class="form-control" placeholder="enter password..."/>
                                          <?php } ?>
                                    </div>
                                    <?php }  ?>
                                </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12 m0 mb10">
                                <label>Vendor<span class="color-red">*</span></label>
                            <?php if($action == 'edit') {

                                echo '<div class="input-group input-icon">
                                        <span class="input-group-addon"><i class="icomoon-icon-user-2 s16"></i></span>
                                        <input type="text" value="'.$user['vendorname'].'" disabled class="form-control"/>
                                      </div>';}
                                else { ?>

                                <select class="form-control select2" name="vendorname" id="vendorname">
                                    <option value="">Select</option>
                                    <?php foreach ($vendors['data'] as $key => $value):
                                        $selected = '';
                                        if(($action=='edit') && ($user['vendorname']==$value['vendorname'])){
                                            $selected = 'selected';
                                        }
                                        echo '<option value="'.$value['vendorname'].'" '.$selected.'>'.$value['vendorname'].'</option>';
                                     endforeach; ?>
                                </select>
                                <?php } ?>
                            </div>
                            
                            <label class="ml15 mb5">Role</label><br/>
                                <div class="form-group col-lg-3 col-md-3 col-sm-6 col-xs-6 pr0 m0 mt5 mb10 toggle-custom toggle-inline">
                                    <label class="toggle" data-on="ON" data-off="OFF">
                                        <input type="radio" id="user" name="role" value="user" <?=(isset($user['role'])&&($user['role']=='user'))?'checked':''?> <?=$default_checked?>>
                                        <span class="button-radio"></span>
                                    </label>
                                    <label for="radio-toggle4">User</label>
                                </div>
                                <div class="form-group pull-right col-lg-3 col-md-3 col-sm-6 col-xs-6 pl0 m0 mt5 mb10 toggle-custom toggle-inline">
                                    <label class="toggle" data-on="ON" data-off="OFF">
                                        <input type="radio" id="admin" name="role" value="admin" <?=(isset($user['role'])&&($user['role']=='admin'))?'checked':''?>>
                                        <span class="button-radio"></span>
                                    </label>
                                    <label for="radio-toggle5">Admin</label>
                                </div>
                        </div>
                </div>
	</form>
	<!-- End Form -->
</div>
<div class="modal-footer" id="the-controls">
    <button type="button" class="btn btn-danger" data-dismiss="modal"><i class=" icomoon-icon-cancel-circle-2"></i>Close</button>
    <button type="button" class="btn btn-success" onclick="javascript:_<?=$action?>_user();" id="<?=$action?>-user-btn"><i class="icomoon-icon-checkmark-circle-2 "></i><?=ucfirst($action)?></button>
</div>
<script src="/scripts/admin/modal/add-edit-user.js"></script>