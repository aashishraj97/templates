<?php include_once $_SERVER['DOCUMENT_ROOT']."/includes/common.php";
$TicketObj = new Ticket();
$id = $_REQUEST['id'];
$where = 'id = '.$id;
$data = $TicketObj->_get(['where'=>$where]);
$ticket = $data['data'][0];
?>

<div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">
        <span aria-hidden="true">&times;</span><span class="sr-only">Close</span>
    </button>
    <h4 class="modal-title" id="myModalLabel2">Close Ticket</h4>
</div>
<div class="modal-body">

	<div class="row text-center" id="response-msg"></div>
        <label class="control-label color-blue p0"><strong>Ticket No. <?=$ticket['ticket_number']; ?></strong></label>
	<!-- Start Form -->	
	<form id="close-ticket-form" name="close-ticket-form" class="form-horizontal" role="form">
		<input type="hidden" id="id" name="id" value="<?=$id?>">
                <input type="hidden" id="ticket-number" name="ticket_number" value="<?=$ticket['ticket_number']; ?>"/>
		<input type="hidden" id="closed" name="closed" value="Yes">
                <input type="hidden" id="checkin" name="checkin" value="<?= $ticket['checkin'];?>"/>
                <input type="hidden" id="checkout" name="checkout" value=""/>
                <div class="bs-callout bs-callout-info fade in m0">
                        <div class="form-group mb5">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <label>Closing Details:</label>
                                    <textarea class="form-control elastic" id="comment" name="comment" rows="3" placeholder="Leave a comment here..."></textarea>
                                </div>
                        </div>
                </div>
	</form>
	<!-- End Form -->
	<div class="row text-center" id="response-msg-bottom"></div>
</div>
<div class="modal-footer" id="the-controls">
    <button type="button" class="btn btn-danger hide" data-dismiss="modal"><i class=" icomoon-icon-cancel-circle-2"></i>Close</button>
    <button type="button" id="close-ticket-btn" class="btn btn-success" onclick="javascript:_close_ticket_submit();"><i class="icomoon-icon-checkmark-circle-2"></i>Close Ticket</button>
</div>
<script src="/scripts/admin/modal/close-ticket.js"></script>