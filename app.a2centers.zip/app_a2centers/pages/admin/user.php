<?php include_once $_SERVER['DOCUMENT_ROOT'] . "/includes/common.php"; 
$UserObj = new User();
$VendorObj = new Vendor();
?>
<div id="user-main-div">
    
    <div class="row mt20">
        <div class="col-lg-12">
            <div class="panel panel-default toggle panelMove panelClose panelRefresh">
                <div class="panel-heading">
                    <h4 class="panel-title"><i class="s16 icomoon-icon-user m0 pr5"></i> User</h4>
                    <span class="ml10">
                        <button onclick="javascript:_add_user_modal('add-edit-user');" id="add-edit-user-modal-btn" class="btn btn-warning mb5 mt5"><i class="fa fa-plus"></i></button>
                    </span>
                </div>
                <div class="panel-body">
                    <div class="row">
                        <form id="user-form" action="#">
                            <?php   $vendors = $VendorObj->_get();
                                    if($vendors['num_rows']>0): ?>
                            <div class="col-lg-2 col-md-3 col-sm-6 col-xs-6">
                                <label>Vendor: </label> <br>
                                <select class="form-control input-medium select2" name="vendorname" id="vendorname">
                                    <option value="">All Vendors</option>
                                <?php foreach ($vendors['data'] as $key => $value):
                                    echo '<option value="'.$value['vendorname'].'">'.$value['vendorname'].'</option>';
                                     endforeach; ?>
                                </select>
                            </div>
                            <?php endif;?>
                            
                            <div class="col-lg-2 col-md-3 col-sm-6 col-xs-6">
                                <label>Search Text: </label>
                                    <div class="input-group input-icon">
                                        <span class="input-group-addon"><i class="fa fa-search s16"></i></span>
                                        <input class="form-control input-medium" type="text" name="search_text" id="search-text" placeholder="Search Text"/>
                                    </div>
                            </div>
                        </form>
                        
                            <div class="col-lg-1 col-md-offset-1 col-md-1 col-sm-3 col-xs-3 mt20">
                                <button onclick="javascript:_search_user_submit();" id="search-btn" class="btn btn-info"><i class="fa fa-search"></i></button>
                            </div>
                            <div class="hide col-lg-1 col-md-offset-1 col-md-1 col-sm-3 col-xs-3 mt20">
                                <button onclick="javascript:_export_to_excel('user-table','DASHBOARD');" id="export-excel-btn" class="btn btn-warning"><i class="fa fa-download"></i></button>
                            </div>
                    </div>
                    <div class="row">
                        <div id="user-listing-div" class="table-responsive col-lg-12 col-md-12 col-sm-12 col-sm-12"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="scripts/admin/user.js" type="text/javascript"></script>
<script>
/*below function declared in above js file*/
_search_user_submit();
</script>