<?php include_once $_SERVER['DOCUMENT_ROOT'] . "/includes/common.php"; 
$UserObj = new User(trim($_REQUEST['username']));
$user = $UserObj->config;
$_SESSION['USER_VENDORNAME'] = $user->vendorname;
$_SESSION['USER_USERNAME'] = $user->username;
$_SESSION['USER_NAME'] = $user->name;
?>
<div id="check-in-out-main-div">
    
    <div class="row mt20">
        <div class="col-lg-12">
            <div class="panel panel-default toggle panelMove panelClose panelRefresh">
                <div class="panel-heading">
                    <h4 class="panel-title"><i class="icomoon-icon-enter s16 m0 pr5"></i>Check In  <i class="icomoon-icon-exit s16 m0 pr5"></i>Check Out</h4>
                </div>
                <div class="panel-body">
                    <div class="row">
                        <form id="check-in-out-form" action="#">
                            <div class="col-lg-2 col-md-3 col-sm-6 col-xs-6">
                                <label>User: </label>
                                <input class="form-control input-medium" type="text" name="username" id="username" disabled="" value="<?=isset($_SESSION['USER_USERNAME'])?$_SESSION['USER_USERNAME']:''; ?>" />
                            </div>
                            <div class="col-lg-2 col-md-3 col-sm-6 col-xs-6">
                                <label>Vendor: </label>
                                <input class="form-control input-medium" type="text" name="vendorname" id="vendorname" disabled="" value="<?=isset($_SESSION['USER_VENDORNAME'])?$_SESSION['USER_VENDORNAME']:''; ?>" />
                            </div>
                            
                            <div class="col-lg-2 col-md-3 col-sm-6 col-xs-6">
                                <label>Search Text: </label>
                                <input class="form-control input-medium" type="text" name="search_text" id="search-text" placeholder="Search Text"/>
                            </div>

                        </form>
                        
                            <div class="col-lg-1 col-md-1 col-sm-3 col-xs-3 mt20">
                                <button onclick="javascript:_search_check_in_out_submit();" id="search-btn" class="btn btn-info"><i class="fa fa-search"></i></button>
                            </div>
                            <div class="col-lg-1 col-md-1 col-sm-3 col-xs-3 mt20 hide">
                                <button onclick="javascript:_export_to_excel('check-in-out-table','DASHBOARD');" id="export-excel-btn" class="btn btn-warning"><i class="fa fa-download"></i></button>
                            </div>
                    </div>
                    <div class="row">
                        <div id="check-in-out-listing-div" class="table-responsive col-lg-12 col-md-12 col-sm-12 col-sm-12"></div>
                    </div>
                </div>
            </div>
            <!-- End .panel -->
        </div>
    </div>
</div>
<script src="scripts/admin/check-in-out.js" type="text/javascript"></script>
<script>
/*below function declared in report.js*/
_search_check_in_out_submit();
if($(".check-out-btn :visible").length<=0){
    $('#check-in-out-table .check-in-btn button').removeAttr('disabled');
}
</script>