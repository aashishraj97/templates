<?php include_once $_SERVER['DOCUMENT_ROOT'] . "/includes/common.php"; 
$UserObj = new User();
$VendorObj = new Vendor();
?>
<div id="report-main-div">    
    <div class="row mt20">
        <div class="col-lg-12">
            <div class="panel panel-default toggle panelMove panelClose panelRefresh">
                <div class="panel-heading">
                    <h4 class="panel-title"><i class="s16 icomoon-icon-pie-2 m0 pr5"></i> Report</h4>
                </div>
                <div class="panel-body">
                    <div class="row">
                        <form id="report-form" action="#">
                            <div class="form-group">
                                    <?php 
                                    $users = $UserObj->_get();
                                    $vendors = $VendorObj->_get();
                                    if($vendors['num_rows']>0): ?>
                                <div class="col-lg-2 col-md-3 col-sm-12 col-xs-12">
                                    <label>Vendor: </label> <br/> 
                                    <select class="form-control input-medium select2" name="vendorname" id="vendorname">
                                        <option value="">All Vendors</option>
                                    <?php foreach ($vendors['data'] as $key => $value):
                                        echo '<option value="'.$value['vendorname'].'">'.$value['vendorname'].'</option>';
                                         endforeach; ?>
                                    </select>
                                </div>
                                <?php endif; ?>

                                <?php if($users['num_rows']>0): ?>
                                <div class="col-lg-2 col-md-3 col-sm-12 col-xs-12">
                                    <label>User: </label> <br/>
                                    <select class="form-control input-medium select2" name="by_user" id="by-user">
                                        <option value="">All Users</option>
                                    <?php foreach ($users['data'] as $key => $value):
                                        echo '<option value="'.$value['username'].'">'.$value['username'].'</option>';
                                         endforeach; ?>
                                    </select>
                                </div>
                                <?php endif; ?>
                       
                                <div class="col-lg-2 col-md-3 col-sm-12 col-xs-12">
                                    <label>From Date: </label>
                                    <div class="input-group input-icon">
                                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                        <input class="form-control input-small datepicker" type="text" name="from_date" id="from-date" placeholder="  dd-mm-yyyy"/>
                                    </div>
                                </div>
                                
                                <div class="col-lg-2 col-md-3 col-sm-12 col-xs-12">
                                    <label>To Date: </label>
                                    <div class="input-group input-icon">
                                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                        <input class="form-control input-small datepicker" type="text" name="to_date" id="to-date" placeholder="  dd-mm-yyyy"/>
                                    </div>
                                </div>
                                
                                <div class="col-lg-2 col-md-3 col-sm-12 col-xs-12">
                                    <label>Search Text: </label>
                                    <div class="input-group input-icon">
                                        <span class="input-group-addon"><i class="fa fa-search s16"></i></span>
                                        <input class="form-control input-small" type="text" name="search_text" id="search-text" placeholder="Search..."/>
                                    </div>
                                </div>
                                
                            </div>
                        </form>
                        <div class="form-group">
                            <div class="col-lg-1 col-md-1 col-sm-6 col-xs-6 mt20">
                                <button onclick="javascript:_search_report_submit();" id="search-btn" class="btn btn-info"><i class="fa fa-search"></i></button>
                            </div>
                            <div class="col-lg-1 col-md-1 col-sm-6 col-xs-6 mt20">
                                <button onclick="javascript:_export_to_excel('report-table','REPORT');" id="export-excel-btn" class="btn btn-warning"><i class="fa fa-download"></i></button>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div id="report-listing-div" class="table-responsive col-lg-12 col-md-12 col-sm-12 col-sm-12"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="scripts/admin/report.js" type="text/javascript"></script>
