<?php include_once $_SERVER['DOCUMENT_ROOT'] . "/includes/common.php"; ?>
<div id="open-ticket-main-div">    
    <div class="row mt20">
        <div class="col-lg-12">
            <div class="panel panel-default toggle panelMove panelClose panelRefresh">
                <div class="panel-heading">
                    <h4 class="panel-title"><i class="s16 icomoon-icon-upload m0 pr5"></i> Bulk Upload</h4>
                </div>
                <div class="panel-body">
                    <div class="bs-callout bs-callout-info fade in">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <h4>Download CSV Format <a href="data:text/csv;charset=utf-8,Client,End Client,City,Country,FTE Name,Vendor Name,Calls" download="Check In-Check Out FTE Calls.csv"><i class="icomoon-icon-download-2"></i></a></h4>
                    </div>
                    <div id="message"></div>
                    <div id="upload_area" class="row">
                        <form method="post" id="upload_form" enctype="multipart/form-data">
                            
                            <div class="form-group">
                                <div class="col-xl-2 col-lg-2 col-md-2 col-sm-4 col-xs-4">
                                    <select class="form-control select2" name="context" id="context">
<!--                                        <option value="">Select</option>
                                        <option value="vendor">Vendor</option>
                                        <option value="user">User</option>-->
                                        <option value="ticket">Ticket</option>
                                    </select>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-xs-4">
                                    <input name="file" id="csv_file" type="file" class="filestyle" data-buttonText="Find file" data-buttonName="btn-default" data-iconName="fa fa-plus"/>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-xs-4">
                                    <input type="submit" name="upload_file" id="upload_file" class="btn btn-primary" value="Upload" />
                                </div>
                            </div>
                        </form>
                    </div>
                    
                    <div class="row">
                        <div id="process_area" class="table-responsive col-lg-12 col-md-12 col-sm-12 col-sm-12"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="scripts/admin/bulk-upload.js" type="text/javascript"></script>