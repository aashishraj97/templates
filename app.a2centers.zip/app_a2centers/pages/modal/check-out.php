<?php include_once $_SERVER['DOCUMENT_ROOT']."/includes/common.php";
$TicketObj = new Ticket();
$id = $_REQUEST['id'];
$where = 'id = '.$id;
$data = $TicketObj->_get(['where'=>$where]);
$ticket = $data['data'][0];
?>

<div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">
        <span aria-hidden="true">&times;</span><span class="sr-only">Close</span>
    </button>
    <h4 class="modal-title" id="myModalLabel2">Ticket Details For Check Out</h4>
</div>
<div class="modal-body">
	<div class="row text-center" id="response-msg"></div>
        <label class="control-label color-blue p0 hide"><strong>Hey! <?=$_SESSION['NAME']; ?></strong></label>
        <!-- Start Form -->	
	<form id="check-out-form" name="check-out-form" class="form-horizontal" role="form">
		<input type="hidden" id="id" name="id" value="<?=$id?>">
                <input type="hidden" id="checkin" name="checkin" value="<?= $ticket['checkin'];?>"/>
		
		<div class="bs-callout bs-callout-info fade in m0">
                        <div class="form-group mb5">
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <label>Ticket Number</label>
                                    <div class="input-group input-icon">
                                        <span class="input-group-addon"><i class="icomoon-icon-tag s16"></i></span>
                                        <input type="text" id="ticket-number" name="ticket_number" class="form-control tip" readonly value="<?=$ticket['ticket_number']; ?>" title="<?=$ticket['ticket_number'];?>"/>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <label>Vendor</label>
                                    <div class="input-group input-icon">
                                        <span class="input-group-addon"><i class="icomoon-icon-user-2 s16"></i></span>
                                        <input type="text" id="vendorname" name="vendorname" class="form-control tip" disabled="" value="<?=$ticket['vendorname']; ?>" title="<?=$ticket['vendorname'];?>"/>
                                    </div>
                                </div>
                        </div>
                        <div class="form-group mb5">
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <label>Client</label>
                                    <div class="input-group input-icon">
                                        <span class="input-group-addon"><i class="icomoon-icon-users s16"></i></span>
                                        <input type="text" id="client" name="client" class="form-control tip" disabled="" value="<?=$ticket['client']; ?>" title="<?=$ticket['client'];?>"/>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <label>End Client</label>
                                    <div class="input-group input-icon">
                                        <span class="input-group-addon"><i class="icomoon-icon-users s16"></i></span>
                                        <input type="text" id="endclient" name="endclient" class="form-control tip" disabled="" value="<?=$ticket['endclient']; ?>" title="<?=$ticket['endclient'];?>"/>
                                    </div>
                                </div>
                        </div>
                        <div class="form-group mb5">
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <label>City</label>
                                    <div class="input-group input-icon">
                                        <span class="input-group-addon"><i class="iconic-icon-home s16"></i></span>
                                        <input type="text" id="city" name="city" class="form-control tip" disabled="" value="<?=$ticket['city'];?>" title="<?=$ticket['city'];?>"/>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <label>Country</label>
                                    <div class="input-group input-icon">
                                        <span class="input-group-addon"><i class="fa fa-globe s16"></i></span>
                                        <input type="text" id="country" name="country" class="form-control tip" disabled="" value="<?=$ticket['country'];?>" title="<?=$ticket['country']; ?>"/>
                                    </div>
                                </div>
                        </div>
                        <div class="form-group mb5">
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <label>FTE Name</label>
                                    <div class="input-group input-icon">
                                        <span class="input-group-addon"><i class="fa fa-user s16"></i></span>
                                        <input type="text" id="ftename" name="ftename" class="form-control tip" disabled="" value="<?=$ticket['ftename'];?>" title="<?=$ticket['ftename'];?>"/>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <label>Check Out</label>
                                    <div class="input-group input-icon">
                                        <span class="input-group-addon"><i class="icomoon-icon-exit s16"></i></span>
                                        <input type="text" id="checkout" name="checkout" class="form-control" readonly value=""/>
                                    </div>
                                </div>
                        </div>
                        <div class="form-group mb5">
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <label>Comments:</label>
                                    <textarea class="form-control" id="comment" name="comment" rows="2" placeholder="Leave a comment here..."></textarea>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <label>Next Visit ETA</label>
                                    <div class="input-group input-icon">
                                        <span class="input-group-addon"><i class="fa fa-calendar s16"></i></span>
                                        <input type="text" id="schedule" name="schedule" class="form-control" value="" placeholder="yyyy-mm-dd hh:mm:ss"/>
                                    </div>
                                </div>
                        </div>
                </div>
	</form>
	<!-- End Form -->
        
	<div class="row text-center" id="response-msg-bottom"></div>
</div>
<div class="modal-footer" id="the-controls">
    <button type="button" class="btn btn-danger hide" data-dismiss="modal"><i class=" icomoon-icon-cancel-circle-2"></i>Close</button>
    <button id="check-out-btn" onclick="javascript:_check_out_submit();" type="button" class="btn btn-success"><i class="icomoon-icon-checkmark-circle-2 "></i>Check Out</button>
</div>
<script src="/scripts/modal/check-out.js"></script>