<?php include_once $_SERVER['DOCUMENT_ROOT']."/includes/common.php";?>

<div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">
        <span aria-hidden="true">&times;</span><span class="sr-only">Close</span>
    </button>
    <h4 class="modal-title" id="myModalLabel2">Change Password</h4>
</div>
<div class="modal-body">

        <div class="row">
            <img src="<?=APP::AVATAR_SRC?>" class="center-block img-responsive w-50" width="100px" alt="Avatar" >    
        </div>
	<div class="row text-center" id="response-msg"></div>
        <div class="bs-callout bs-callout-info fade in m0">  
	<!-- Start Form -->	
	<form id="change-password-form" name="change-password-form" class="form-horizontal" role="form">
                <input type="hidden" id="id" name="id" value="<?=isset($_SESSION['ID'])?$_SESSION['ID']:'';?>">
                <input type="hidden" id="username" name="username" value="<?=isset($_SESSION['USERNAME'])?$_SESSION['USERNAME']:'';?>">
                <div class="form-group">
                    <div class=" col-lg-6  col-md-6 col-sm-12 col-xs-12 mb10">
                        <label for="">New Password:</label>
                        <div class="input-group input-icon">
                            <span class="input-group-addon"><i class="icomoon-icon-lock s16"></i></span>
                            <input type="password" name="new_password" id="new_password"  onkeyup="_validate_password(this.value);" class="form-control" placeholder="Enter new password">
                            
                        </div>
                    </div>
                    
                    <div class=" col-lg-6  col-md-6 col-sm-12 col-xs-12">
                        <label for="">Confirm Password:</label>
                        <div class="input-group input-icon">
                            <span class="input-group-addon"><i class="icomoon-icon-lock s16"></i></span>
                            <input type="password" name="confirm_password" class="form-control" placeholder="Enter confirm password">
                        </div>
                    </div>
                </div>
	</form>
	<!-- End Form -->
        </div>
        <br/>
	<div id="msg"></div>
</div>
<div class="modal-footer" id="the-controls">
    <button type="button" class="btn btn-danger hide" data-dismiss="modal"><i class=" icomoon-icon-cancel-circle-2"></i>Close</button>
    <button type="button" class="btn btn-success" onclick="javascript:_change_password_submit();"><i class="icomoon-icon-checkmark-circle-2 "></i>Change</button>
</div>
<script src="/scripts/modal/change-password.js"></script>