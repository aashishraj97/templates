<?php include_once $_SERVER['DOCUMENT_ROOT'] . "/includes/common.php"; ?>
<BR><BR>
<div class="row">
    <div class="col-md-2"></div>
    <div class="col-md-10">
        <h3> Welcome, <?php echo $_SESSION['NAME']; ?>!</h3>

        <h4>How do you want to start with <?=APP::NAME?> today..</h4>
        <div>
            <?php if(isset($_SESSION['ROLE']) && ($_SESSION['ROLE']=='user')): ?>
            <ul id="email-nav" class="nav nav-pills nav-stacked">
                <li>
                    <a href="javascript:_content_loader('check-in-out');">
                        <span class="circle s16">[1]</span> 
                        Take me to the Check In / Check Out.
                    </a>
                </li>

                <li>
                    <a href="javascript:_change_password_modal('change-password');">
                        <span class="circle s16 color-green">[2]</span> 
                        <!--need to work on the sales and reports.-->
                        I think I should change my password.
                    </a>
                </li>
                
                <li>
                    <a href="javascript:_content_loader('my-profile');">
                        <span class="circle s16 color-blue">[3]</span>
                        Show My Profile first & then the rest.
                    </a>
                </li>
            </ul>
            <?php endif; ?>
            <?php if(isset($_SESSION['ROLE']) && ($_SESSION['ROLE']=='admin')): 
                $TicketObj = new Ticket();
                ?>
            <ul id="email-nav" class="col-md-6 nav nav-pills nav-stacked">
                <li>
                    <a href="javascript:_admin_content_loader('total-ticket');">
                        <span class="circle s16 color-red">[1]</span> 
                        Total tickets <?=$TicketObj->_get_count();?>.
                    </a>
                </li>
                
                <li>
                    <a href="javascript:_admin_content_loader('open-ticket');">
                        <span class="circle s16 color-green">[2]</span> 
                        Open tickets <?=$TicketObj->_get_count('closed="No"');?>.
                    </a>
                </li>
                
                <li>
                    <a href="javascript:_admin_content_loader('closed-ticket');">
                        <span class="circle s16 color-blue">[3]</span>
                        Closed tickets <?=$TicketObj->_get_count('closed="Yes"');?>.
                    </a>
                </li>
                
                <li>
                    <a href="javascript:_admin_content_loader('report');">
                        <span class="circle s16 color-yellow">[4]</span>
                        Need to generate a reports.
                    </a>
                </li>
                <li>
                    <a href="javascript:_change_password_modal('change-password');">
                        <span class="circle s16 color-blue">[5]</span> 
                        <!--need to work on the sales and reports.-->
                        I think I should change my password.
                    </a>
                </li>
                
                <li>
                    <a href="javascript:_content_loader('my-profile');">
                        <span class="circle s16">[6]</span>
                        Show My Profile first & then the rest.
                    </a>
                </li>
            </ul>
            <ul id="email-nav" class="col-md-6 nav nav-pills nav-stacked">
                <li>
                    <a href="javascript:_admin_content_loader('vendor');">
                        <span class="circle s16 color-red">[7]</span> 
                        <i class="s16 icomoon-icon-user-2 pr5"></i><span class="txt">Vendor</span>
                    </a>
                </li>
                
                <li>
                    <a href="javascript:_admin_content_loader('user');">
                        <span class="circle s16 color-green">[8]</span> 
                        <i class="s16 icomoon-icon-user pr5"></i><span class="txt">User</span>
                    </a>
                </li>
                
                <li>
                    <a href="javascript:_admin_content_loader('report');">
                        <span class="circle s16 color-blue">[9]</span>
                        <i class="s16 icomoon-icon-pie-2 pr5"></i><span class="txt">Report</span>
                    </a>
                </li>
                
                <li>
                    <a href="javascript:_admin_content_loader('bulk-upload');">
                        <span class="circle s16 color-yellow">[10]</span>
                        <i class="s16 icomoon-icon-upload pr5"></i><span class="txt">Bulk Upload</span>
                    </a>
                </li>
            </ul>
            <?php endif; ?>       
        </div>
    </div>
</div> <!-- row -->