<?php include_once $_SERVER['DOCUMENT_ROOT'] . "/includes/config.php";?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title><?=APP::TITLE?></title>
    <!-- Mobile specific metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    
    <!-- meta tags for seo -->
    <meta name="author" content="" />
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="application-name" content="" />
    <meta name="copyrights" content="all the rights recerved @tictik.org" />
    <meta name="robot" content="index,follow" />
    
    <!-- Fav and touch icons -->
    <link rel="apple-touch-icon" sizes="180x180" href="./img/logo/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="./img/logo/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="./img/logo/favicon-16x16.png">
    <link rel="manifest" href="./img/logo/site.webmanifest">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="./img/logo/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
    
    <!-- Bootstrap CSS -->
    <link href="./plugins/bootstrap/css/bootstrap.min.css" type="text/css" rel="stylesheet">    
    <!-- Css files -->
    <link href="css/icons.css" rel="stylesheet" />
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/plugins.css" rel="stylesheet" />
    <!-- Main stylesheets (template main css file) -->
    <link href="css/main.css" rel="stylesheet" />
    <!-- Custom stylesheets ( Put your own changes here ) -->
    <link href="css/custom.css" rel="stylesheet" />
</head>

<body class="login-page">
    <div id="header" class="animated fadeInDown">
        <div class="row">
            <div class="navbar">
                <div class="container text-center">
                    <a href="#"><img src="<?=APP::LOGO_SRC?>" class="center-block img-responsive" alt="App Logo" ></a>
                </div>
            </div>
            <!-- End .navbar -->
        </div>
        <!-- End .row -->
    </div><!-- End #header -->
    
    <!-- Start login container -->
    <div class="container login-container">
        
        <!-- Log In start -->
        <div id="login-panel" class="login-panel panel panel-default plain animated bounceIn ">
            <!-- Start .panel -->
            <div class="panel-body">
                <form class="form-horizontal mt0" id="login-form" role="form" autocomplete="off">
                <input type="hidden" id="local_time_offset" name="local_time_offset" value="">
                    <div class="row">
                        <img src="<?=APP::AVATAR_SRC?>" class="center-block img-responsive w-50" width="100px" alt="Avatar" >    
                    </div>
                    <!--Start message box-->
                    <div id="login-msg" class="text-center"></div>
                    <!--End message box-->
                    
                    <div class="form-group">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 hide">
                            <label for="">Username:</label>
                        </div>
                        <div class="col-lg-12 col-md-12 col-sm-12 mb10 mt10">
                            <div class="input-group input-icon">
                                <span class="input-group-addon"><i class="icomoon-icon-user s16"></i></span>
                                <input type="text" name="username" id="username" class="form-control required" placeholder="Enter username">
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="col-lg-12 col-md-12 col-sm-12 hide">
                            <label for="">Password:</label>
                        </div>
                        <div class="col-lg-12 col-md-12 col-sm-12 mb10">
                            <div class="input-group input-icon">
                                <span class="input-group-addon"><i class="icomoon-icon-lock s16"></i></span>
                                <input type="password" name="password" id="password" class="form-control required"  placeholder="Enter password">

                            </div>
                            <span class="fp-text-block pull-right"><a onclick="javascript:_forgot_password();" role="button">Forgot password ?</a></span>
                        </div>
                    </div>
                    
                    <div class="form-group mb0">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-8 pr0">
                            <div class="checkbox-custom">
                                <input type="checkbox" name="remember" id="remember">
                                <label for="remember">Remember me ?</label>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-4 mb25">
                            <button id="login-btn" class="btn btn-primary pull-right">Log In</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- Log In end -->
        
        <!-- Forgot Password start -->
        <div id="get-password-panel" class="login-panel panel panel-default plain animated bounceIn hide">
            <!-- Start .panel -->
            <div class="panel-body">
                <div class="user-avatar row p0">
                    <h6 class="text-center"><strong>Oops... This happens with most of us.</strong></h6>
                </div>
                <form id="get-password-form" name="get-password-form" role="form" class="form-horizontal mt0" action="#">
                    
                    <div class="row">
                        <img src="<?=APP::AVATAR_SRC?>" class="center-block img-responsive w-50" width="100px" alt="Avatar" >    
                    </div>
                    <!--Start message box-->
                    <div id="get-password-msg" class="text-center"></div>
                    <!--End message box-->
                    
                    <div class="form-group">
                        <div class="col-md-12 hide">
                            <label for="">Username:</label>
                        </div>
                        <div class="col-lg-12 col-md-12 col-sm-12 mt10">
                            <div class="input-group input-icon">
                                <span class="input-group-addon"><i class="icomoon-icon-user s16"></i></span>
                                <input type="text" name="username" id="username" class="form-control" placeholder="Enter username">
                            </div>
                        </div>
                    </div>
                </form>
                
                <div class="row">
                    <button class="col-6 ml-3 btn btn-primary" onclick="javascript:_back_to_login();"><i class="icomoon-icon-arrow-left-10"></i>Back to Login</button>
                    <button class="col-5 ml-1 offset-1 btn btn-primary" id="get-password-btn" onclick="javascript:_get_password();">Get Password</button>
                </div>
            </div>
            <div class="panel-footer gray-lighter-bg">
                <p class="text-center">Please enter your <?=APP::NAME?> username and we will send the password to your registered email address.</p>
            </div>
        </div>
        <!-- End .panel -->
    </div>
    
    <!-- End login container -->
    <div class="container">
        <div class="footer mt20">
            <p class="text-center">&copy;2020 Copyright <a href="<?=APP::OWNER_URL?>" target="_blank"><?=APP::OWNER_NAME?></a>. All right reserved.</p>
        </div>
    </div>
    <!-- Init plugins olny for this page -->
    <!-- Important javascript libs(put in all pages) -->
    <script src="js/libs/jquery.min.js"></script>
    <script src="js/libs/jquery-ui-1.10.4.min.js"></script>
    <!-- Bootstrap plugins -->
    <script src="js/bootstrap/bootstrap.js"></script>
    <!-- Form plugins -->
    <script src="plugins/forms/validation/jquery.validate.js"></script>
    <script src="plugins/forms/validation/additional-methods.min.js"></script>
    <script src="scripts/login.js"></script>
</body>
</html>