<?php include_once $_SERVER['DOCUMENT_ROOT'] . "/includes/common.php"; ?>

<!DOCTYPE html>
<html class="no-js">
    <head>
        <meta charset="utf-8">
        <!-- DateTime -->
        <link href="plugins/forms/bootstrap-datetimepicker/bootstrap-datetimepicker.min.css" rel="stylesheet" />
        <!-- Icons -->
        <link href="css/icons.css" rel="stylesheet" />
        <!-- Bootstrap stylesheets (included template modifications) -->
        <link href="css/bootstrap.css" rel="stylesheet" />
        <!-- Plugins stylesheets (all plugin custom css) -->
        <link href="css/plugins.css" rel="stylesheet" />
        <!-- Main stylesheets (template main css file) -->
        <link href="css/main.css" rel="stylesheet" />
        <!-- Custom stylesheets ( Put your own changes here ) -->
        <link href="css/custom.css" rel="stylesheet" />
        <!-- CRUD stylesheets ( Put your own changes here ) -->

        <!-- App Custom stylesheets (template main css file) -->
        <link href="css/app.css " rel="stylesheet" />
    </head>
    <body>
        <!--.#header -->
        <?php 
        if(empty($_SESSION['USERNAME']) && ($_SESSION['USERNAME']=='')){
            header('Location: login-expire.php'); exit();
        }
        include "includes/header.php"; ?>
        <!-- / #header -->
        
        <div id="wrapper">
            <!-- #wrapper -->
            
            <!--Sidebar background-->
            <div id="sidebarbg" class="hidden-lg hidden-md hidden-sm hidden-xs"></div>
            
            <!--menu content-->
            <?php include "includes/menu/work_" . $_SESSION['ROLE'] . ".php"; ?>
            <!-- End menu -->
            
            <!--Sidebar background-->
            
            <!-- Start #right-sidebar -->
            <div id="right-sidebarbg" class="hidden-lg hidden-md hidden-sm hidden-xs"></div>
            <?php include "includes/right-sidebar/work_" . $_SESSION['ROLE'] . ".php"; ?>
            <!-- End #right-sidebar -->
            
            <!-- Modal Middle -->
            <div class="modal fade" id="modal-middle" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                    </div><!-- modal-content -->
                </div><!-- modal-dialog -->
            </div><!-- modal -->
            
            <!-- Modal Right-Side -->
            <div class="modal modal-sidebar right fade" id="modal-sidebar" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2">
                <div class="modal-dialog" role="document">
                    <div class="modal-content brad0">
                    </div><!-- modal-content -->
                </div><!-- modal-dialog -->
            </div><!-- modal -->
            
            <!-- Modal Full -->
            <div class="modal modal-sidebar right fade" id="modal-sidebar-full" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2" >
                <div class="modal-dialog1" role="document">
                    <div class="modal-content brad0">


                    </div><!-- modal-content -->
                </div><!-- modal-dialog -->
            </div><!-- modal -->
            
            <!--Body content-->
            <div id="content" class="page-content clearfix">
                <?php include 'pages/dashboard.php'; ?>
            </div>
            
            <!-- End #content -->
            <?php include "includes/footer.php"; ?>
            <!-- End #footer  -->    
        </div>
        <!-- / #wrapper -->
        
        <!-- Back to top -->
        <div id="back-to-top"><a href="#">Back to Top</a></div>
        
        <!-- Javascripts -->
        <!-- Load pace first -->
        <script src="plugins/core/pace/pace.min.js"></script>
        <!-- Important javascript libs(put in all pages) -->
        <script src="js/libs/jquery.min.js"></script>
        <script src="js/libs/jquery-ui-1.10.4.min.js"></script>
        <script src="js/libs/jquery-migrate-1.2.1.min.js"></script>
        <!-- Bootstrap plugins -->
        <script src="js/bootstrap/bootstrap.js"></script>
        <!-- Core plugins ( not remove ) -->
        <script src="js/libs/modernizr.custom.js"></script>
        <!-- Handle responsive view functions -->
        <script src="js/jRespond.min.js"></script>
        <!-- Custom scroll for sidebars,tables and etc. -->
        <script src="plugins/core/slimscroll/jquery.slimscroll.min.js"></script>
        <script src="plugins/core/slimscroll/jquery.slimscroll.horizontal.min.js"></script>
        <!-- Remove click delay in touch -->
        <script src="plugins/core/fastclick/fastclick.js"></script>
        <!-- Increase jquery animation speed -->
        <script src="plugins/core/velocity/jquery.velocity.min.js"></script>
        <!-- Quick search plugin (fast search for many widgets) -->
        <script src="plugins/core/quicksearch/jquery.quicksearch.js"></script>
        <!-- Bootbox fast bootstrap modals -->
        <script src="plugins/ui/bootbox/bootbox.js"></script>
        <script src="plugins/ui/notify/jquery.gritter.js"></script>
        <script src="js/libs/moment.js"></script>
        <script src="plugins/ui/waypoint/waypoints.js"></script>
        <script src="plugins/ui/calendar/fullcalendar.js"></script>

        <!-- FROM DASHBOARD -->
        <!-- Other plugins ( load only nessesary plugins for every page) -->
        <script src="plugins/charts/sparklines/jquery.sparkline.js"></script>
        <script src="plugins/charts/chartjs/Chart.js"></script>
        <script src="js/libs/raphael.js"></script>
        <script src="plugins/charts/morris/morris.js"></script>
        <script src="plugins/charts/knob/jquery.knob.js"></script>
        <script src="plugins/charts/flot/jquery.flot.custom.js"></script>
        <script src="plugins/charts/flot/jquery.flot.pie.js"></script>
        <script src="plugins/charts/flot/jquery.flot.resize.js"></script>
        <script src="plugins/charts/flot/jquery.flot.time.js"></script>
        <script src="plugins/charts/flot/jquery.flot.growraf.js"></script>
        <script src="plugins/charts/flot/jquery.flot.categories.js"></script>
        <script src="plugins/charts/flot/jquery.flot.stack.js"></script>
        <script src="plugins/charts/flot/jquery.flot.orderBars.js"></script>
        <script src="plugins/charts/flot/jquery.flot.tooltip.min.js"></script>
        <script src="js/jquery.supr.js"></script>
        <!--<script src="js/pages/dashboard.js"></script>-->

        <!-- FROM FORM BASIC -->
        <!-- Other plugins ( load only nessesary plugins for every page) -->
        <script src="plugins/forms/bootstrap-filestyle/bootstrap-filestyle.js"></script>
        <script src="plugins/forms/autosize/jquery.autosize.js"></script>
        <script src="plugins/forms/checkall/jquery.checkAll.js"></script>
        <script src="js/main.js"></script>

        <!-- FROM FORM ADVANCED -->
        <!-- Other plugins ( load only nessesary plugins for every page) -->
        <script src="plugins/forms/bootstrap-datepicker/bootstrap-datepicker.js"></script>
        <script src="plugins/forms/bootstrap-datetimepicker/bootstrap-datetimepicker.min.js"></script>
        <script src="plugins/forms/bootstrap-tagsinput/bootstrap-tagsinput.js"></script>
        <script src="js/libs/typeahead.bundle.js"></script>
        <script src="plugins/forms/summernote/summernote.js"></script>
        <script src="plugins/forms/select2/select2.js"></script>
        <script src="plugins/forms/fancyselect/fancySelect.js"></script>
        <script src="plugins/forms/dropzone/dropzone.js"></script>
        <script src="plugins/forms/validation/jquery.validate.js"></script>
        <script src="plugins/forms/validation/additional-methods.min.js"></script>


        <!-- FROM CHART RICKSHAW -->
        <script src="plugins/charts/rickshaw/d3.min.js"></script>
        <script src="plugins/charts/rickshaw/d3.layout.min.js"></script>
        <script src="plugins/charts/rickshaw/rickshaw.min.js"></script>
        
        <!-- database -->
        <script src="plugins/tables/datatables/datatables.min.js"></script>
        <script src="plugins/tables/datatables/dataTables.tableTools.js"></script>
        <script src="plugins/tables/datatables/dataTables.bootstrap.js"></script>
        <script src="plugins/tables/datatables/dataTables.responsive.js"></script>
        
        <!-- FROM CRUD -->
        <script src="/scripts/app-content-loader.js"></script>
        
        <!-- OPEN PASSWORD CHANGE MODAL, FOR FIST TIME LOGIN USERS -->
        <?php if(!$_SESSION['CHECKLOGIN']): ?>
        <script>_change_password_modal();</script>
        <?php endif; ?>
        
    </body>
</html>
