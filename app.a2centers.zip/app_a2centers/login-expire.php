<?php include_once $_SERVER['DOCUMENT_ROOT'] . "/includes/config.php"; ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title><?=APP::NAME?> | LogOut</title>
        <!-- Mobile specific metas -->
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <meta name="author" content="" />
        <meta name="description" content="" />
        <meta name="keywords" content="" />
        <meta name="application-name" content="" />
        <!-- Icons -->
        <link href="css/icons.css" rel="stylesheet" />
        <!-- Bootstrap stylesheets (included template modifications) -->
        <link href="css/bootstrap.css" rel="stylesheet" />
        <!-- Plugins stylesheets (all plugin custom css) -->
        <link href="css/plugins.css" rel="stylesheet" />
        <!-- Main stylesheets (template main css file) -->
        <link href="css/main.css" rel="stylesheet" />
        <!-- Custom stylesheets ( Put your own changes here ) -->
        <!--<link href="css/custom.css" rel="stylesheet" />-->
        <!-- Fav and touch icons -->
        <link rel="apple-touch-icon" sizes="57x57" href="./img/img/logo/apple-icon-57x57.png">
        <link rel="apple-touch-icon" sizes="60x60" href="./img/logo/apple-icon-60x60.png">
        <link rel="apple-touch-icon" sizes="72x72" href="./img/logo/apple-icon-72x72.png">
        <link rel="apple-touch-icon" sizes="76x76" href="./img/logo/apple-icon-76x76.png">
        <link rel="apple-touch-icon" sizes="114x114" href="./img/logo/apple-icon-114x114.png">
        <link rel="apple-touch-icon" sizes="120x120" href="./img/logo/apple-icon-120x120.png">
        <link rel="apple-touch-icon" sizes="144x144" href="./img/logo/apple-icon-144x144.png">
        <link rel="apple-touch-icon" sizes="152x152" href="./img/logo/apple-icon-152x152.png">
        <link rel="apple-touch-icon" sizes="180x180" href="./img/logo/apple-icon-180x180.png">
        <link rel="icon" type="image/png" sizes="192x192"  href="./img/logo/android-icon-192x192.png">
        <link rel="icon" type="image/png" sizes="32x32" href="./img/logo/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="96x96" href="./img/logo/favicon-96x96.png">
        <link rel="icon" type="image/png" sizes="16x16" href="./img/logo/favicon-16x16.png">
        <link rel="manifest" href="./img/logo/manifest.json">
    </head>

    <body class="error-page">
        <div id="header" class="animated fadeInDown">
            <div class="row">
                <div class="navbar">
                    <div class="container text-center">
                        <a href="#"><img src="<?=APP::LOGO_SRC?>" class="center-block img-responsive" alt="App Logo" ></a>
                    </div>
                </div>
                <!-- End .navbar -->
            </div>
        </div>
        <!-- End #header -->

        <div class="container error-container">
            <div class="error-panel panel panel-default plain animated bounceIn">
                <!-- Start .panel -->
                <div class="panel-body">
                    <div class="page-header">
                        <div class="row">
                            <img src="<?=APP::AVATAR_SRC?>" class="center-block img-responsive w-50" width="100px" alt="Avatar" >    
                        </div>
                    </div>
                    <div class="page-header">
                        <p class="text-center mt30 mb30 s16">
                            You need to be logged in to perform any action. <br/>
                            If you were logged in already then your session  <br/>
                            might have expired.
                        </p>
                    </div>
                    <div class="text-center">
                        <a href="index.php" class="btn btn-primary"><i class="icomoon-icon-arrow-left-10"></i>Back to Login</a>
                    </div>
                </div>
            </div>
            <div class="footer mt20">
                <p class="text-center">&copy;2020 Copyright <a href="<?=APP::OWNER_URL?>" target="_blank"><?=APP::OWNER_NAME?></a>. All right reserved.</p>
            </div>
        </div>
    </body>
</html>