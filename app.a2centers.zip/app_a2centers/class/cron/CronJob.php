<?php

/**
 * Description of Database
 * in order to user tables use static DBTable::TABLE_NAME
 * @author Aashish Raj
 * @email aashishraj97@gmail.com
 * @website tictik.org
 */
include_once dirname(dirname(__DIR__)) . "/includes/config.php";
include_once dirname(__DIR__) . "/util/MailUtil.php";
include_once dirname(__DIR__) . "/util/DBTable.php";
class CronJob {

    public function __construct() {
        $mysqli_obj = new mysqli(DB::HOST, DB::USER, DB::PASS, DB::NAME);
        if ($mysqli_obj->connect_error) {
            exit($mysqli_obj->connect_error);
        }
        $mysqli_obj->set_charset(DB::CHAR);


        //$query = "INSERT INTO ".DBTable::LOGS." (type, by_user, message) VALUES ('debug', 'ashish', 'Cron Job')";
        //$query = "UPDATE ".DBTable::TBL_TICKETS." SET checkin=NULL, checkout=NULL WHERE checkout <= (NOW() - INTERVAL 10 DAY_HOUR)";
        $query = "SELECT * FROM " . DBTable::USERS . " WHERE is_active=1 AND role='user'";
        $mysqli = $mysqli_obj->query($query);
        if ($mysqli) {
            $data = $mysqli->fetch_all(MYSQLI_ASSOC);
            $MailUtilObj = new MailUtil();
            foreach ($data as $key => $row) {
                //if($row['username']!='ashish'){continue;}
                $date = date('Y-m-d',strtotime($row['expire_date']));
                $subject = $activity_details = '';
                $can_proceed = $is_final = false;
                //echo date('Y-m-d',strtotime('+15 days'))." - ".$date. " = -15 days \n";
                //echo strtotime(date('Y-m-d',strtotime('+15 days')))." - ".strtotime($date). " = -15 days \n";
                    
                /* send 1nd notification before 15 days of expire date */
                if(strtotime($date) == strtotime(date('Y-m-d',strtotime('+15 days')))) {
                    echo "user : ".$row['username']." <br/>expire_date : ".$date." - today_date : ".date('Y-m-d'). " = 15 days \n";
                    $can_proceed = true;
                    $subject = 'Your password will expire in 15 days.';
                    $activity_details = 'Your password will expire in 15 days. <br/>If you are not going to change it you will not be able to connect to '.App::NAME.' portal.';
                    
                    $update_query = "UPDATE ".DBTable::USERS." SET check_login=0 WHERE id=".$row['id'];
                    $mysqli_obj->query($update_query);
                }
                /* send 2nd notification before 10 days of expire date  */
                else if(strtotime($date) == strtotime(date('Y-m-d',strtotime('+10 days')))) {
                    echo "user : ".$row['username']." <br/>expire_date : ".$date." - today_date : ".date('Y-m-d'). " = 10 days \n";
                    $can_proceed = true;
                    $subject = 'Your password will expire in 10 days.';
                    $activity_details = 'Your password will expire in 10 days. <br/>If you are not going to change it you will not be able to connect to '.App::NAME.' portal.';
                }
                /* send final notification before 5 days of expire date */
                else if(strtotime($date) == strtotime(date('Y-m-d',strtotime('+5 days')))) {
                    echo "user : ".$row['username']." <br/>expire_date : ".$date." - today_date : ".date('Y-m-d'). " = 5 days \n";
                    $can_proceed = true;
                    $is_final = true;
                    $subject = 'Your password will expire in 5 days.';
                    $activity_details = 'Your password will expire in 5 days. <br/>If you are not going to change it you will not be able to connect to '.App::NAME.' portal.';
                }
                /* make the account inactive */
                else if(strtotime($date) == strtotime(date('Y-m-d'))) {
                    echo "user : ".$row['username']." <br/>expire_date : ".$date." - today_date : ".date('Y-m-d'). " = 0 days \n";
                    $update_query = "UPDATE ".DBTable::USERS." SET is_active=0 WHERE id=".$row['id'];
                    $mysqli_obj->query($update_query);
                    $can_proceed = true;
                    $is_final = true;
                    $subject = 'Your  '.App::NAME.' account got expired.';
                    $activity_details = 'Your '.App::NAME.' account ('.$row['username'].') got expired. <br/>Contact your '.App::NAME.' administrator to activate it.';
                }
                
                $is_vendor_alert = false;
                /* Alert to vendors regarding the users who did not login for a week */
                if(strtotime(date('Y-m-d',strtotime($row['last_modified']))) == strtotime(date('Y-m-d',strtotime('-7 days')))){
                    echo "user : ".$row['username']." <br/>today_date : ".date('Y-m-d')." - last_modified : ".date('Y-m-d',strtotime($row['last_modified'])). " = 7 days \n";
                    //$can_proceed = true;
                    $is_vendor_alert = true;
                    $subject1 = App::NAME.' account ('.$row['username'].') have not logged in for a week.';
                    $activity_details1 = App::NAME.' account ('.$row['username'].') have not logged in for a week.';
                }
                
                if($can_proceed || $is_vendor_alert) {
                    $template_query = "SELECT * FROM " . DBTable::EMAIL_TEMPLATES . " WHERE type='activity-updates' ";
                    $mysqli1 = $mysqli_obj->query($template_query);
                    $template_data = $mysqli1->fetch_object();

        //            $content = file_get_contents(dirname( dirname(__DIR__) ).'/pages/mail-templates/temporary-password.php');
                    
                    /* REPLACE THE MICROS DEFINED IN TEMPLATE */
                    $app_url = 'https://tictik.org';
                    $app_logo_src = $app_url.'/img/logo/app-logo.png';;
                    $search_array = ['::ACTIVITY_DETAILS::','::APP_URL::','::APP_LOGO_SRC::'];
                    $replace_array= [$activity_details,    $app_url,   $app_logo_src];
                    $final_message = str_replace($search_array, $replace_array, $template_data->content);
                    $params = [ 'to'=>[$row['email']=>$row['name']],
                                'subject'=>$subject,
                                'message'=>$final_message];
                    
                    if($is_final || $is_vendor_alert){
                        $vendor_query = "SELECT * FROM " . DBTable::TBL_VENDORS . " WHERE vendorname='".$row['vendorname']."'";
                        $mysqli2 = $mysqli_obj->query($vendor_query);
                        $vendor = $mysqli2->fetch_object();
                        if($is_final){
                            $params['cc']=[$vendor->email=>$vendor->vendorname];
                            $params['bcc']=['a2centers@gmail.com'=>'A2 Centers'];
                        }
                        
                        if($is_vendor_alert){
                            $search_array = ['::ACTIVITY_DETAILS::','::APP_URL::','::APP_LOGO_SRC::'];
                            $replace_array= [$activity_details1,    $app_url,   $app_logo_src];
                            $final_message = str_replace($search_array, $replace_array, $template_data->content);
                            $params1 = [ 'to'=>[$vendor->email=>$vendor->vendorname],
                                        'bcc'=>['a2centers@gmail.com'=>'A2 Centers'],
                                        'subject'=>$subject1,
                                        'message'=>$final_message];
                            $res1 = $MailUtilObj->_send_mail($params1);
                        }
                        
                    }
                    
                    if($can_proceed){
                        $res = $MailUtilObj->_send_mail($params);
                    }
                    //var_dump($res);
                }
                
            }

            //echo "New record created successfully";
            // Free result set
            $mysqli->free_result();
        } else {
            echo "Error: " . $query . "<br>" . $mysqli_obj->error;
        }

        /* clear the logs 30 days older */

        $mysqli_obj->close();
    }

}

new CronJob();
/*check why this keyword not working in php-cli*/
//class CronJob extends mysqli {
//    public function __construct() {
//        parent::__construct(DB::HOST, DB::USER, DB::PASS, DB::NAME);
//        if ($this->connect_error) {
//            exit($this->connect_error);
//        }
//        $this->set_charset(DB::CHAR);
//    }
//
//    public static function _run_every_minute() {
//        echo 'klshfkahfkls';
//        $sql = "INSERT INTO logs (type, username, message) VALUES ('debug', 'kavya@123', 'from class')";
//        if ($this->query($sql) === TRUE) {
//            echo "New record created successfully";
//          } else {
//            echo "Error: " . $sql . "<br>" . $this->error;
//          }
//          $this->close();
//    }
//}
//
//CronJob::_run_every_minute();