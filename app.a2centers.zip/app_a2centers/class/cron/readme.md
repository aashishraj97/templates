from Ubuntu Software
Crontab Installation on Ubuntu
https://www.rosehosting.com/blog/ubuntu-crontab/
You can use cron on Ubuntu to automatically run scripts within a specified period of time, create a backup of your databases or other important files, monitor the services running on your server and many other things. Follow the steps below to set up the Ubuntu crontab.
Sudo apt-get update && sudo apt-get upgrade
2. Check if the cron package is installed
dpkg -l cron
3. Install the cron package on Ubuntu
sudo apt-get install cron
4.Verify if the cron service is running
sudo service cron status
5. Configure cron jobs on Ubuntu
sudo crontab -e	OR	sudo nano /etc/crontab
6. Ubuntu crontab examples
Before adding below php command, make sure that php-cli is installed
# Example of job definition:
# .---------------- minute (0 - 59)
# | .------------- hour (0 - 23)
# | | .---------- day of month (1 - 31)
# | | | .------- month (1 - 12) OR jan,feb,mar,apr ...
# | | | | .---- day of week (0 - 6) (Sunday=0 or 7) OR sun,mon,tue,wed,thu ..
# | | | | |
# * * * * * user-name command to be executed
* * * * * php /var/www/html/cron/every-minutus.php
* 1 * * * sudo php /var/www/html/cron/every-day-at-1-am.php
Let’s say we want to schedule a backup script to run every day at 4:30 AM.
30 4 * * * /path/to/script/backup-script.sh
Or if we want to schedule the backup on the first day of each month at 8 PM,
0 18 1 * * /path/to/script/backup-script.sh
7. Restart the cron service
sudo service cron restart

crontab -e should not have the root part, which specifies the username (crontab -e already edits a specific user's crontab).
If you want to run as root, do 
sudo crontab -e, and use:
* */2 * * * php /var/www/html/script.php
or create a file in /etc/cron.d containing:
* */2 * * * root php /var/www/html/script.php
