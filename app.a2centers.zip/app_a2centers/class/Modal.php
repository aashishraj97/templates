<?php include_once $_SERVER['DOCUMENT_ROOT'] . "/includes/common.php";
/**
 * Description of Database
 * in order to user tables use static DBTable::TABLE_NAME
 * @author Aashish Raj
 * @email aashishraj97@gmail.com
 * @website tictik.org
 */
class Modal extends DBUtil {
    private $db_fields = [];
    

    /* calling parent constructor to make database */
    public function __construct() {
        parent::__construct();
        $this->db_fields = $this->_get_db_fields(DBTable::USERS); 
        if(isset($this->db_fields['id'])){ unset($this->db_fields['id']); }
    }
    
    public function _is_exist($data = []) {
        $response['RESPONSE'] = '';
        if(count($data)>0) {
            $where = $data['field'] . "='" . trim($data['value']) . "'" ;
            $data['fields'] = ['id'];
            $data['where'] = $where;
            if($this->_select(DBTable::USERS, $data)->_num_rows()>0) {
                $response['RESPONSE'] = 'SUCCESS';
                $this->_add_info_log('User::_is_exist() - value already exist!.. condition ('.$where.')');
            }
        }
        return $response;
    }
    
    /**
     * 
     * @param type $where string
     * @return type integer
     */
    public function _get_count($where = null) {
        $data['fields'] = ['count(id) as count'];
        $data['where'] = $where;
        $object = $this->_select(DBTable::USERS,$data)->_fetch_object();
        return $object->count;
    }
    
    public function _get($data = []) {
        $object = $this->_select(DBTable::USERS,$data);
        $response['num_rows'] = $object->_num_rows();
        $response['data'] = $object->_fetch_all();
        $response['object'] = $object;
        return $response;
    }
    
    public function _add($form_data = []) {
        $response['RESPONSE'] = '';
        if(count($form_data)>0){
            /*to convert original value into some encrypted format*/
            $form_data['password'] = sha1($form_data['password']);
            /*unset those fields which in not existing on table*/
            $insert_fields_values = [];
            foreach ($form_data as $key => $value) {
                if(in_array($key, $this->db_fields)){
                    $insert_fields_values[$key] = trim($value);
                }
            }
            
            /*add required fields which in existing on table*/
            $DateTimeUtilObj = new DateTimeUtil();
            $insert_fields_values['chng_pwd_date'] = $DateTimeUtilObj->_date('Y-m-d H:i:s');
            $insert_fields_values['expire_date'] = $DateTimeUtilObj->_date("Y-m-d H:i:s", strtotime("+3 month"));
            
            $fields = array_keys($insert_fields_values);
            $values = array_values($insert_fields_values);
            $response = $this->_insert(DBTable::USERS, $fields, $values);
            if($response['RESPONSE']=='SUCCESS') {
                $response['INSERT_ID'] = $this->_insert_id();
                $this->_add_info_log('User::_add() - Successfully Inserted... id ('.$this->_insert_id().')');
            }
        }
        return $response;
    }
    
    public function _edit($form_data = []) {
        $response['RESPONSE'] = '';
        if(count($form_data)>0){
            $id = isset($form_data['id'])?$form_data['id']:0;
            $where = "id=".$id;
            /*unset those fields which in not existing on insert table*/
            $update_fields = [];
            foreach ($form_data as $key => $value) {
                if(in_array($key, $this->db_fields)){
                    $update_fields[$key] = trim($value);
                }
            }
            
            $response = $this->_update(DBTable::USERS,$update_fields,$where);
            if($response['RESPONSE']=='SUCCESS') {
                $this->_add_info_log('User::_edit() - Successfully Updated... condition ('.$where.')');
            }
        }
        return $response;
    }
    
    public function _remove($id = null) {  
        $response['RESPONSE'] = '';
        if(!empty($id)){
            $where = "id=" . $id; 
            $response = $this->_delete(DBTable::USERS,$where);
            if($response['RESPONSE']=='SUCCESS') {
                $this->_add_info_log('User::_remove() - Successfully Deleted... condition ('.$where.')');
            }
        }
        return $response;
    }
        
    public function _touch($where = null) {
        if(empty($where)) {
            $data['fields'] = ['name'=>'last_modified','value'=>'NOW()','type'=>'string'];
            $data['where'] = $where;
            $object = $this->_update(DBTable::USERS,$data);
        }
    }
}
