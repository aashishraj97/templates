<?php include_once $_SERVER['DOCUMENT_ROOT'] . "/includes/config.php";
/**
 * Description of Database
 * connection const values coming from includes/config.php
 * @author Aashish Raj
 * @email aashishraj97@gmail.com
 * @website tictik.org
 */
include 'DBTable.php';
class DBUtil {
    /* private varialbe decleration */
    private $connection;
    private $query;

    /* auto db connection with magic construct fun */
    public function __construct() {
        $this->connection = new mysqli(DB::HOST, DB::USER, DB::PASS, DB::NAME);
        if ($this->connection->connect_error) {
            exit($this->connection->connect_error);
        }
        $this->connection->set_charset(DB::CHAR);
    }
    
    /**
     * @param type $table string
     * @param type $data associative array ['fields'=>[],'where'=>'id=1','order_by'=>'id desc','limit'=>'0,10']
     * @return $this object
     */
    public function _select($table = null, $data = []) 
    {
        
        $fields = isset($data['fields'])?$data['fields']:[];
        $where = isset($data['where'])?$data['where']:null;
        $order_by = isset($data['order_by'])?$data['order_by']:null;
        $limit = isset($data['limit'])?$data['limit']:null;
        
        if(count($fields)>0) {
            $query = 'SELECT ' . implode(',', $fields) . ' FROM ' . $table;
        } else {
            $query = 'SELECT * FROM ' . $table;
        }
        
        if ($where != null) {   $query .= ' WHERE ' . $where; }
        if ($order_by != null) {$query .= ' ORDER BY ' . $order_by;}
        if ($limit != null) {   $query .= ' LIMIT ' . $limit;}
        //$this->_add_debug_log($query);
        return $this->_run_query($query);
    }
    
    /**
     * always user after _select()->_fetch_array()
     * @return type associative array
     */
    public function _fetch_array() 
    {
        /* MYSQLI_NUM MYSQLI_ASSOC MYSQLI_BOTH */
        return $this->query->fetch_array(MYSQLI_ASSOC);
    }
    
    /**
     * always user after _select()->_fetch_object()
     * @return type object
     */
    public function _fetch_object() 
    {
        /* fetch objects */
        return $this->query->fetch_object();
    }
    /**
     * always user after _select()->_fetch_object()
     * @return type object
     */
    public function _fetch_all() 
    {
        /* fetch objects 
        MYSQLI_ASSOC
        MYSQLI_NUM (this is default)
        MYSQLI_BOTH
        */
        return $this->query->fetch_all(MYSQLI_ASSOC);
    }
    
    /**
     * 
     * @return type integer
     */
    public function _num_rows() {
        /*$this->query->store_result(); */
        return $this->query->num_rows;
    }
    
    /**
     * to insert one or multiple rows in one shot 
     * @param type $table string
     * @param type $insert_fields array
     * @param type $insert_values array or multi-array
     * @return associative array
     */
    public function _insert($table, $insert_fields = [], $insert_values = []) 
    {   
        $response = ['RESPONSE'=>'','MESSAGE'=>''];
        if((count($insert_fields)>0) && (count($insert_values)>0))
        {
            $query = " INSERT INTO " . $table . " (" . implode(',', $insert_fields) . ") VALUES ";
            if (count($insert_values) == count($insert_values, COUNT_RECURSIVE)) 
            {
                foreach ($insert_values as $key => $value) 
                {
                    if (is_string($insert_values[$key])) 
                    {
                        $insert_values[$key] = '"' . $insert_values[$key] . '"';
                    }
                }
                $query .= " (" . implode(',', $insert_values) . ") ";
            }
            else 
            {
                $comma_sep = "";
                foreach ($insert_values as $each_row_value) 
                {
                    foreach ($each_row_value as $key => $value) 
                    {
                        if (is_string($each_row_value[$key])) 
                        {
                            $each_row_value[$key] = '"' . $each_row_value[$key] . '"';
                        }
                    }
                    
                    $query .= $comma_sep . " (" . implode(',', $each_row_value) . ") ";
                    $comma_sep = ",";
                }              
            }
            if ($this->_run_query($query)) 
            {
                $response['RESPONSE'] = 'SUCCESS';
                $response['MESSAGE'] = 'Successfully Inserted...';
                /* do not add type log here, it become a infinite loop, 
                 * because _add_type_log() calling _insert() function */
            } 
            else 
            {
                /* add error log */
                $response['RESPONSE'] = 'ERROR';
                $response['MESSAGE'] = 'Opps! You got an error : '.$this->_error();
                $this->_add_error_log('DBUtil::_insert() - Error : ' .$this->_error()." Query : ".$query);
            }
        }
        else 
        {
            /* add warning log */
            $response['RESPONSE'] = 'WARNING';
            $response['MESSAGE'] = 'Opps! we didn\'t found any fields & values. Please provide and try again.';
            $this->_add_error_log('DBUtil::_insert() - Please provide values in correct format.');
        }
        
        return $response;
    }

    public function _insert_id() {
        return $this->connection->insert_id;
    }
    
    /**
     * to update table rows use _update()
     * @param type $table string
     * @param type $update_fields array
     * @param type $where_clause string 'username="aashishraj97" AND email LIKE "aashishraj97%"';
     * @return boolean
     */
    public function _update($table = null, $update_fields = [], $where_clause = null) 
    {    

        $response = ['RESPONSE'=>'','MESSAGE'=>''];
        $query = 'UPDATE ' . $table . ' SET ';    
        $comma_sep = '';
        foreach ($update_fields as $field => $value) {
            if (is_string($value)) {
                $query .= $comma_sep.$field . '="' . $value . '"';
            } else {
                if($value==''){
                    $query .= $comma_sep.$field . '=NULL';                      
                }
                else {
                    $query .= $comma_sep.$field . '=' . $value;                    
                }
            }
            $comma_sep = ",";
        }
        
        if(!empty($where_clause))
        {
            $query .= " WHERE " . $where_clause;
        }
        
        if ($this->_run_query($query))
        {
            /* add info log */
            $response['RESPONSE'] = 'SUCCESS';
            $response['MESSAGE'] = 'Successfully Updated...';
            $this->_add_info_log('DBUtil::_update() - Successfully Updated...' . $query);
        } 
        else 
        {
            /* add error log */
            $response['RESPONSE'] = 'ERROR';
            $response['MESSAGE'] = 'Opps! You got an error : '.$this->_error();
            $this->_add_error_log('DBUtil::_update() - Error : ' .$this->_error()." Query : ".$query);
        }
        return $response;
    }
    
    public function _affected_rows() {
        return $this->query->affected_rows;
    }
    /**
     * 
     * @param type $table
     * @param type $where_clause
     * @return associative array
     */
    public function _delete($table = null, $where_clause = null) 
    {
        $response = ['RESPONSE'=>'','MESSAGE'=>''];
        
        $query = "DELETE FROM " . $table;
        if (!empty($where_clause)) 
        {
            $query .= " WHERE " . $where_clause;
        }
        
        if ($this->_run_query($query))
        {
            /* add info log */
            $response['RESPONSE'] = 'SUCCESS';
            $response['MESSAGE'] = 'Successfully Deleted...';
            $this->_add_info_log('DBUtil::_delete() - Successfully Deleted...');
        } 
        else 
        {
            /* add error log */
            $response['RESPONSE'] = 'ERROR';
            $response['MESSAGE'] = 'Opps! You got an error : '.$this->_error();
            $this->_add_error_log('DBUtil::_delete() - Error : ' .$this->_error()." Query : ".$query);
        }
        
        return $response;
    }
    
    /**
     * to run the query
     * @param type $query string
     * @return boolean
     */
    public function _run_query($query = null) 
    {   
        $this->query = $this->connection->query($query);
        
        return $this;
    }
    
    /**
     * to remove all unwanted char 
     * @param type $string
     */
    public function _escape_string($string = null) 
    {
        return $this->connection->real_escape_string($string);
    }
    
    /**
     * to remove all unwanted char 
     * @param type $string
     */
    public function _html_special_chars($string = null) 
    {
        return htmlspecialchars($string);
    }
    
    public function _error() {
        return "Opps! you got an error : " . $this->connection->errno . " " . $this->connection->error;
    }
    
    public function _close() {
        return $this->connection->close();
    }

    /**
     * to trace info occurrence
     * @param type $message string
     * @return boolen
     */
    public function _add_info_log($message = null) 
    {   
        $this->_build_and_run_log_query('info', $message);
    }
    
    /**
     * to trace alert occurrence
     * @param type $message string
     * @return boolen
     */
    public function _add_alert_log($message = null) 
    {   
        $this->_build_and_run_log_query('alert', $message);
    }
    
    /**
     * to trace error occurrence
     * @param type $message string
     * @return boolen
     */
    public function _add_error_log($message = null) 
    {   
        $this->_build_and_run_log_query('error', $message);
    }
    
    /**
     * to trace debug occurrence
     * @param type $message string
     * @return boolen
     */
    public function _add_debug_log($message = null) 
    {   
        $this->_build_and_run_log_query('debug', $message);
    }
    
    /**
     * to trace login occurrence
     * @param type $message string
     * @return boolen
     */
    public function _add_login_log($message = null) 
    {   
        $this->_build_and_run_log_query('login', $message);
    }
    
    /**
     * to trace admin changes
     * @param type $message string
     * @return boolen
     */
    public function _add_admin_log($message = null) 
    {   
        $this->_build_and_run_log_query('admin', $message);
    }
    
    /**
     * 
     * @param type $type string
     * @param type $message string
     * @return boolen
     */
    public function _build_and_run_log_query($type = 'info', $message = null) 
    {
        $by_user = (isset($_SESSION['USERNAME']))?$_SESSION['USERNAME']:'system';
        $insert_fields = ['type','message','by_user'];
        $insert_values = [$type, $this->_escape_string($message), $by_user];

        foreach ($insert_values as $key => $value) 
        {
            if (is_string($insert_values[$key])) 
            {
                $insert_values[$key] = '"' . $insert_values[$key] . '"';
            }
        }
        
        $query = " INSERT INTO ".DBTable::LOGS." (" . implode(',', $insert_fields) . ") ";
        $query .= " VALUES (" . implode(',', $insert_values) . ") ";
        $this->_run_query($query);
    }
    
    public function _get_db_fields($table = null) 
    {
        $columns = [];
        if(!empty($table)){
            $query = "  SELECT  `COLUMN_NAME` 
                        FROM    `INFORMATION_SCHEMA`.`COLUMNS` 
                        WHERE   `TABLE_SCHEMA`= '".DB::NAME."' AND `TABLE_NAME`='".$table."';";
            $response = $this->_run_query($query)->_fetch_all();
            if(count($response)>0){
                foreach ($response as $key => $value) {
                    array_push($columns,$value['COLUMN_NAME']);
                }
            }
        }
        return $columns;
    }
    
    public function _get_db_connection($table = null) 
    {
        return $this->connection;
    }
};

//$DBUtilObj = new DBUtil();

#$_SESSION['USERNAME'] = 'aashishraj97';
/* Update Multiple Rows in DB */
//$update_fields  = array('username'  => 'ashishraj97',
//                        'password'  => 'admin@123',
//                        'email'     => 'ashishraj97@gmail.com');
//$where_clause   = 'username="aashishraj97" AND email LIKE "aashishraj97%"';
//$DBUtilObj->_update('users', $update_fields, $where_clause);

//
///* Delete a Row from DB */
//$DBUtilObj->_delete('users','id = 1');

/* Insert a Row in DB */
//$insert_fields = array('type','username','date_time','message');
//$insert_values = array('info','admin@123sss','2020-04-04','message');//array(array('aashishraj97s','admin@123sss','aasshishraj97@gmail.com'),array('aashishraj97s','admin@123sss','aasshishraj97@gmail.com'),array('aashishraj97s','admin@123sss','aasshishraj97@gmail.com'));
//$DBUtilObj->_insert('logs', $insert_fields, $insert_values);

///* Fetch Data from DB */
//$user_list = $DBUtilObj->_select('users')->_fetch_object();
//var_dump($user_list);
//while($each_row = $user_list->fetch_array()){
//    echo $each_row[0]."<br />";
//}
/*
    public function _where($condition) 
    {
        return $this = " WHERE " . $condition;
    }
    public function _order_by($condition='', $order='ASC') 
    {
        return $this = " ORDER BY " . $fields . " ASC";
    }
    public function _having($condition) 
    {
        return $this = " HAVING " . $condition;
    }
    public function _limit($condition) 
    {
        return $this = " HAVING " . $condition;
    }
    $DBUtilObj->_update('users', $update_fields)
                ->_where('username="aashishraj97" AND email LIKE "aashishraj97%"')
                ->_order_by()
                ->_having()
                ->_limit();
 * /
 */