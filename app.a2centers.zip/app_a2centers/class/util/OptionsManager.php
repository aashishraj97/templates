<?php
namespace SUPR\Component\Manager;

use SUPR\Component\Helper\BoolHelper;
use SUPR\Component\Helper\SerializeHelper;
use SUPR\Component\QueryBuilder\SQLQuery;

/**
 * Class OptionsManager
 *
 * @package SUPR\Component\Manager
 */
class OptionsManager
{
    const DATA_AUTO = 'AUTO';
    const DATA_TYPE_SERIALIZED = 'serialized';
    const DATA_TYPE_BOOLEAN = 'bool';

    /**
     * @var \PDO
     */
    protected $pdo;

    /**
     * @var string
     */
    protected $tableName;

    /**
     * @var string
     */
    protected $columnKey;

    /**
     * @var string
     */
    protected $columnValue;

    /**
     * @var array
     */
    protected $options;

    /**
     * OptionsManager constructor.
     *
     * @param \PDO   $pdo
     * @param string $tableName
     * @param string $columnKey
     * @param string $columnValue
     */
    public function __construct($pdo, $tableName = 'kvs', $columnKey = 'key', $columnValue = 'value')
    {
        $this->pdo = $pdo;
        $this->tableName = $tableName;
        $this->columnKey = $columnKey;
        $this->columnValue = $columnValue;
    }

    // -- CRUD ---------------------------------------------------------------------------------------------------------

    /**
     * Create meta data.
     *
     * @param string $key
     * @param mixed  $value
     * @return mixed
     */
    public function create($key, $value)
    {
        return $this->setByKey($key, $value);
    }

    /**
     * @param string $key
     * @param mixed  $default
     * @param string $type
     * @return mixed
     */
    public function read($key = null, $default = null, $type = null)
    {
        $readOptionsQueryString = SQLQuery::create()
            //->setEscapeFunction([$this->getDbProvider(), 'escapeString'])
            ->select([$this->columnKey, $this->columnValue])
            ->from($this->tableName)
            ->limit(0, 1000);

        if (null !== $key) {
            $readOptionsQueryString->where([$this->columnKey => $key]);
        }

        $resultsData = $this->pdo->query($readOptionsQueryString)->fetchAll();

        // If no options where found the default value will be returned...
        if (count($resultsData) <= 0) {
            return $default;
        }

        foreach ($resultsData as $resultRow => $resultData) {
            switch ($type) {
                case self::DATA_TYPE_SERIALIZED:
                    break;
                case self::DATA_TYPE_BOOLEAN:
                    break;
                default:
            }

            if (SerializeHelper::serialized($resultData)) {
                $data = SerializeHelper::unserialize($resultData);
            } else {
                // Store the option value to the local storage...
                $data = $resultData[$this->columnValue];
            }

            $this->options[$resultData[$this->columnKey]] = $data;
        }

        if (null === $key) {
            return $this->options;
        }

        return $this->options[$key];
    }

    /**
     * Update meta data.
     *
     * @param string $key
     * @param mixed  $value
     * @return mixed
     */
    public function update($key, $value)
    {
        return $this->setByKey($key, $value);
    }

    /**
     * Delete value by key.
     *
     * @param string $key
     * @return bool
     */
    public function delete($key)
    {
        $query = SQLQuery::create()
            ->from($this->tableName)
            ->where([$this->columnKey => $key]);

        return $this->pdo->prepare($query->delete())->execute();
    }

    // -- ADDITIONAL ---------------------------------------------------------------------------------------------------

    /**
     * Check if a key exists.
     *
     * @param string $key
     * @return bool
     */
    public function has($key)
    {
        $query = SQLQuery::create()
            //->setEscapeFunction([$this->getDbProvider(), 'escapeString'])
            ->from($this->tableName)
            ->where([$this->columnKey => $key]);
        $result = $this->pdo->query($query->countRows('rows'))->fetchAll();

        return (isset($result[0]['rows']) && $result[0]['rows'] >= 1);
    }

    // -- PROTECTED ----------------------------------------------------------------------------------------------------

    /**
     * Store the meta value by key.
     *
     * @param string $key
     * @param mixed  $value
     * @return mixed
     */
    protected function setByKey($key, $value)
    {
        /*
        // Muss die Variable zum Schlüssel besonders behandelt werden?
        if (isset($this->fieldsTypes[$key])) {
            switch ($this->fieldsTypes[$key]) {
                case self::DATA_TYPE_SERIALIZED:
                    //$valueData = @serialize($value);
                    $valueData = WPSerializationHelper::serialize($value);
                    break;
                case self::DATA_TYPE_BOOLEAN:
                    $valueData = BoolHelper::toString($value);
                    break;
                default:
                    $valueData = $value;
            }
        } elseif (is_bool($value)) {
            $valueData = BoolHelper::toString($value);
        } else {
            $valueData = WPSerializationHelper::serialize($value);
        }
        $result = $this->query(
            SQLQuery::create()
                ->countRows()
                ->from($this->getOptionsTableName())
                ->where(['option_name' => $key])
        );
        $count = (int)$result[0]['_count'];
        */
        $hasKey = $this->has($key);

        if (!is_scalar($value)) {
            $valueData = SerializeHelper::serialize($value);
        } else {
            if (is_bool($value)) {
                $valueData = BoolHelper::toString($value);
            } else {
                $valueData = $value;
            }
        }

        // Some options are not autoloaded! For that reason we ask the Database...
        // If this option exists it stay empty but will be initialized...
        if ($hasKey && !isset($this->options[$key])) {
            $this->options[$key] = '';
        }

        //$valueActual = $this->getBlogOptions($key, null, true);
        $query = SQLQuery::create()
            //->setEscapeFunction([$this->getDbProvider(), 'escapeString']);
            ->into($this->tableName);

        // If the key does not exists, than create...
        if (!$hasKey) {
            $query->insert([$this->columnKey => $key, $this->columnValue => $valueData]);
        }

        // or update...
        else {
            $query->update([$this->columnValue => $valueData]);
            $query->where([$this->columnKey => $key]);
        }

        $result = $this->pdo->prepare($query)->execute();

        // Save the new option to the local option storage...
        $this->options[$key] = $value;

        return $result;
    }
}