<?php include_once $_SERVER['DOCUMENT_ROOT'] . "/includes/common.php";
/**
 * Description of Database
 * connection const values coming from includes/config.php
 * @author Aashish Raj
 * @email aashishraj97@gmail.com
 * @website tictik.org
 */
include $_SERVER['DOCUMENT_ROOT'] . '/vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class ExportUtil {
    //put your code here
    public function ExportToExcel(){

        $spreadsheet = new Spreadsheet();
        $spreadsheet->getProperties()
            ->setCreator("Maarten Balliauw")
            ->setLastModifiedBy("Maarten Balliauw")
            ->setTitle("Office 2007 XLSX Test Document")
            ->setSubject("Office 2007 XLSX Test Document")
            ->setDescription(
                "Test document for Office 2007 XLSX, generated using PHP classes."
            )
            ->setKeywords("office 2007 openxml php")
            ->setCategory("Test result file");

        $sheet = $spreadsheet->getActiveSheet(0);
        $sheet->setCellValue('A1', 'Hello World !');

        $writer = new Xlsx($spreadsheet);
//        $writer->save('hello world.xlsx');
        $writer->save(APP::TEMP . '/hello world-'.time().'.xlsx');
        /*************exmple end***********/
    }
}

$ExportUtilObj = new ExportUtil();
$ExportUtilObj->ExportToExcel();