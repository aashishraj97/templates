<?php
/**
 * Description of Database
 * in order to user tables use static DBTable::TABLE_NAME
 * @author Aashish Raj
 * @email aashishraj97@gmail.com
 * @website tictik.org
 */
class AppUtil {
    
    
    public function _get_type($var) {
        /*
        if (is_string($var))
            return 's';
        if (is_float($var))
            return 'd';
        if (is_int($var))
            return 'i';
        return 'b';
         */
        
        /*
        inp: $var = [1, 1., NULL, new stdClass, 'aashish'];
        out: integer, double, NULL, object, string
        */
        return gettype($var);    
    }
    
    public function _set_cookie(string $key, string $value, int $expires) {
        return setcookie($key, $value, $expires);
        /*
        if(!isset($_COOKIE[$key])) {
            echo "Cookie named '" . $key . "' is not set!";
        } else {
            echo "Cookie '" . $key . "' is set!<br>";
            echo "Value is: " . $_COOKIE[$key];
        }*/
    }
    
    public function _remove_cookie(string $key, $expires=3600) {
        /*unset($_COOKIE[$key]);*/
        setcookie($key, '', time()-$expires);
    }
    
    public function _feature_enabled(string $feature) {
        return true;
    }
    
    public function _str_replace($search, $replace, $string) {
        return str_replace($search, $replace, $string);
        /*
        If you want to remove all dashes but one from the string '-aaa----b-c-----d--e---f' 
        resulting in '-aaa-b-c-d-e-f', you cannot use str_replace. Instead, use preg_replace:
        
        $challenge = '-aaa----b-c-----d--e---f';
        echo str_replace('--', '-', $challenge).'<br>';
        echo preg_replace('/--+/', '-', $challenge).'<br>';
         
         This outputs the following:
        -aaa--b-c---d-e--f
        -aaa-b-c-d-e-f
         */
    }
    
    function _partially_hide_email_address($email)
    {
        $em   = explode("@",$email);
        $name = implode('@', array_slice($em, 0, count($em)-1));
        $len  = floor(strlen($name)/2);

        return substr($name,0, $len) . str_repeat('*', $len) . "@" . end($em);   
    }
}
