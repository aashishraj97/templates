<?php

///////////////////////////////////////////////////////////////////////
//								     //									 //
//      Below all that Style Methods which help us to design         //
//								     //									 //
///////////////////////////////////////////////////////////////////////
include_once $_SERVER['DOCUMENT_ROOT'] . "/includes/common.php";
require_once $_SERVER['DOCUMENT_ROOT'] . "/vendor/autoload.php";

//Import the PHPMailer class into the global namespace
use PhpOffice\PhpSpreadsheet\Spreadsheet;

use PhpOffice\PhpSpreadsheet\Worksheet\PageSetup;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Font;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
/**
 * Description of Database
 * in order to user tables use static DBTable::TABLE_NAME
 * @author Aashish Raj
 * @email aashishraj97@gmail.com
 * @website tictik.org
 */
class SpreadsheetUtil extends Spreadsheet {

    /* calling to perent class constructor */    
    public function __construct() {
        parent::__construct();
    }

    /* 4.6.21. Setting the default style of a workbook */
    function getDefaultSetting() {
        $this->getDefaultStyle()->getFont()->setName('arial');
        $this->getDefaultStyle()->getFont()->setSize(11);
        $this->getActiveSheet()->getDefaultColumnDimension()->setWidth(12);
        $this->getActiveSheet()->getDefaultRowDimension()->setRowHeight(16);
    }

    /* 4.6.9. Setting a worksheet’s page orientation and size */
    function setPageOrientation($orientations) {
        switch ($orientations) {
            case 'default': $orientation = PageSetup::ORIENTATION_DEFAULT;
                break;
            case 'landscape': $orientation = PageSetup::ORIENTATION_LANDSCAPE;
                break;
            case 'portrait': $orientation = PageSetup::ORIENTATION_PORTRAIT;
                break;
        }
        $this->getActiveSheet()->getPageSetup()->setOrientation($orientation);
        return $this;
    }

    /* */
    function setPaperSize($paperSize) {
        switch ($paperSize) {
            case 'default': $paper_size = PageSetup::ORIENTATION_DEFAULT;
                break;
            case 'landscape': $paper_size = PageSetup::ORIENTATION_LANDSCAPE;
                break;
            case 'portrait': $paper_size = PageSetup::ORIENTATION_PORTRAIT;
                break;
            case '634_envelope': $paper_size = PageSetup::PAPERSIZE_6_3_4_ENVELOPE;
                break;
            case 'a2_paper': $paper_size = PageSetup::PAPERSIZE_A2_PAPER;
                break;
            case 'a3': $paper_size = PageSetup::PAPERSIZE_A3;
                break;
            case 'a3_extra_paper': $paper_size = PageSetup::PAPERSIZE_A3_EXTRA_PAPER;
                break;
            case 'a3_extra': $paper_size = PageSetup::PAPERSIZE_A3_EXTRA_TRANSVERSE_PAPER;
                break;
            case 'a3_transverse_paper':$paper_size = PageSetup::PAPERSIZE_A3_TRANSVERSE_PAPER;
                break;
            case 'a4': $paper_size = PageSetup::PAPERSIZE_A4;
                break;
            case 'a4_extra_paper': $paper_size = PageSetup::PAPERSIZE_A4_EXTRA_PAPER;
                break;
            case 'a4_plus_paper': $paper_size = PageSetup::PAPERSIZE_A4_PLUS_PAPER;
                break;
            case 'a4_small': $paper_size = PageSetup::PAPERSIZE_A4_SMALL;
                break;
            case 'a4_transverse_paper':$paper_size = PageSetup::PAPERSIZE_A4_TRANSVERSE_PAPER;
                break;
            case 'a5': $paper_size = PageSetup::PAPERSIZE_A5;
                break;
            case 'a5_extra_paper': $paper_size = PageSetup::PAPERSIZE_A5_EXTRA_PAPER;
                break;
            case 'a5_transverse_paper':$paper_size = PageSetup::PAPERSIZE_A5_TRANSVERSE_PAPER;
                break;
            case 'b4': $paper_size = PageSetup::PAPERSIZE_B4;
                break;
            case 'b4_envelope': $paper_size = PageSetup::PAPERSIZE_B4_ENVELOPE;
                break;
            case 'b5': $paper_size = PageSetup::PAPERSIZE_B5;
                break;
            case 'b5_envelope': $paper_size = PageSetup::PAPERSIZE_B5_ENVELOPE;
                break;
            case 'b6_envelope': $paper_size = PageSetup::PAPERSIZE_B6_ENVELOPE;
                break;
            case 'c': $paper_size = PageSetup::PAPERSIZE_C;
                break;
            case 'c3_envelope': $paper_size = PageSetup::PAPERSIZE_C3_ENVELOPE;
                break;
            case 'c4_envelope': $paper_size = PageSetup::PAPERSIZE_C4_ENVELOPE;
                break;
            case 'c5_envelope': $paper_size = PageSetup::PAPERSIZE_C5_ENVELOPE;
                break;
            case 'c6_envelope': $paper_size = PageSetup::PAPERSIZE_C6_ENVELOPE;
                break;
            case 'c65_envelope': $paper_size = PageSetup::PAPERSIZE_C65_ENVELOPE;
                break;
            case 'd': $paper_size = PageSetup::PAPERSIZE_D;
                break;
            case 'dl': $paper_size = PageSetup::PAPERSIZE_DL_ENVELOPE;
                break;
            case 'e': $paper_size = PageSetup::PAPERSIZE_E;
                break;
            case 'executive': $paper_size = PageSetup::PAPERSIZE_EXECUTIVE;
                break;
            case 'folio': $paper_size = PageSetup::PAPERSIZE_FOLIO;
                break;
            case 'legal_fanfold': $paper_size = PageSetup::PAPERSIZE_GERMAN_LEGAL_FANFOLD;
                break;
            case 'german_standard_fanfold': $paper_size = PageSetup::PAPERSIZE_GERMAN_STANDARD_FANFOLD;
                break;
            case 'invite_envelope': $paper_size = PageSetup::PAPERSIZE_INVITE_ENVELOPE;
                break;
            case 'iso_b4': $paper_size = PageSetup::PAPERSIZE_ISO_B4;
                break;
            case 'iso_b5_extra_paper':$paper_size = PageSetup::PAPERSIZE_ISO_B5_EXTRA_PAPER;
                break;
            case 'italy_envelope': $paper_size = PageSetup::PAPERSIZE_ITALY_ENVELOPE;
                break;
            case 'japanese_double_postcard': $paper_size = PageSetup::PAPERSIZE_JAPANESE_DOUBLE_POSTCARD;
                break;
            case 'jis_b5_transverse_paper': $paper_size = PageSetup::PAPERSIZE_JIS_B5_TRANSVERSE_PAPER;
                break;
            case 'ledger': $paper_size = PageSetup::PAPERSIZE_LEDGER;
                break;
            case 'legal': $paper_size = PageSetup::PAPERSIZE_LEGAL;
                break;
            case 'legal_extra_paper': $paper_size = PageSetup::PAPERSIZE_LEGAL_EXTRA_PAPER;
                break;
            case 'letter': $paper_size = PageSetup::PAPERSIZE_LETTER;
                break;
            case 'letter_extra_paper':$paper_size = PageSetup::PAPERSIZE_LETTER_EXTRA_PAPER;
                break;
            case 'letter_extra_transverse_paper': $paper_size = PageSetup::PAPERSIZE_LETTER_EXTRA_TRANSVERSE_PAPER;
                break;
            case 'letter_plus_paper': $paper_size = PageSetup::PAPERSIZE_LETTER_PLUS_PAPER;
                break;
            case 'letter_small': $paper_size = PageSetup::PAPERSIZE_LETTER_SMALL;
                break;
            case 'letter_transverse_paper': $paper_size = PageSetup::PAPERSIZE_LETTER_TRANSVERSE_PAPER;
                break;
            case 'monarch_envelope': $paper_size = PageSetup::PAPERSIZE_MONARCH_ENVELOPE;
                break;
            case 'no9_envelope': $paper_size = PageSetup::PAPERSIZE_NO9_ENVELOPE;
                break;
            case 'no10_envelope': $paper_size = PageSetup::PAPERSIZE_NO10_ENVELOPE;
                break;
            case 'no11_envelope': $paper_size = PageSetup::PAPERSIZE_NO11_ENVELOPE;
                break;
            case 'no12_envelope': $paper_size = PageSetup::PAPERSIZE_NO12_ENVELOPE;
                break;
            case 'no14_envelope': $paper_size = PageSetup::PAPERSIZE_NO14_ENVELOPE;
                break;
            case 'note': $paper_size = PageSetup::PAPERSIZE_NOTE;
                break;
            case 'quarto': $paper_size = PageSetup::PAPERSIZE_QUARTO;
                break;
            case 'standard_1': $paper_size = PageSetup::PAPERSIZE_STANDARD_1;
                break;
            case 'standard_2': $paper_size = PageSetup::PAPERSIZE_STANDARD_2;
                break;
            case 'standard_paper_1': $paper_size = PageSetup::PAPERSIZE_STANDARD_PAPER_1;
                break;
            case 'standard_paper_2': $paper_size = PageSetup::PAPERSIZE_STANDARD_PAPER_2;
                break;
            case 'standard_paper_3': $paper_size = PageSetup::PAPERSIZE_STANDARD_PAPER_3;
                break;
            case 'statement': $paper_size = PageSetup::PAPERSIZE_STATEMENT;
                break;
            case 'supera_supera_a4_paper': $paper_size = PageSetup::PAPERSIZE_SUPERA_SUPERA_A4_PAPER;
                break;
            case 'supera_supera_a3_paper': $paper_size = PageSetup::PAPERSIZE_SUPERB_SUPERB_A3_PAPER;
                break;
            case 'tabloid': $paper_size = PageSetup::PAPERSIZE_TABLOID;
                break;
            case 'tabloid_extra_paper': $paper_size = PageSetup::PAPERSIZE_TABLOID_EXTRA_PAPER;
                break;
            case 'us_standard_fanfold': $paper_size = PageSetup::PAPERSIZE_US_STANDARD_FANFOLD;
                break;
            default : $paper_size = $paperSize;
                break;
        }
        $this->getActiveSheet()->getPageSetup()->setPaperSize($paper_size);
        return $this;
    }

    /* Show Grid line or hide */
    function setShowGridlines($bool) {
        $this->getActiveSheet()->setShowGridlines($bool);
    }

    /* 4.6.44. Setting worksheet zoom level */
    function setZoomScale($scale) {
        $this->getActiveSheet()->getSheetView()->setZoomScale($scale);
    }

    /* 4.6.31. Setting a row’s height */
    function setRowHeight($rowDimension, $rowHeight) {
        $this->getActiveSheet()->getRowDimension($rowDimension)->setRowHeight($rowHeight);
        return $this;
    }

    /* 4.6.17. Specify printing area */
    function setPrintArea($cells) {
        $this->getActiveSheet()->getPageSetup()->setPrintArea($cells);
    }

    /* 4.6.28. Setting a column’s width */
    function setColumnWidth($column, $colWidth) {
        $this->getActiveSheet()->getColumnDimension($column)->setWidth($colWidth);
        return $this;
    }
    
    /* set column width auto */
    function setColumnWidthAuto($column) {
        $this->getActiveSheet()->getColumnDimension($column)->setAutoSize(true);
        return $this;
    }

    /* 4.6.11. Page margins in inches default is ($top=1, $right=0.75, $bottom=1, $left=0.75) */
    function setPageMargins($margin) {
        $this->getActiveSheet()->getPageMargins()->setTop($margin[0]);
        $this->getActiveSheet()->getPageMargins()->setRight($margin[1]);
        $this->getActiveSheet()->getPageMargins()->setBottom($margin[2]);
        $this->getActiveSheet()->getPageMargins()->setLeft($margin[3]);
    }

    /* Get Linux Date */
    function getDate($cellValue, $dateTime) {
        $this->getActiveSheet()
                ->setCellValue($cellValue, PHPExcel_Shared_Date::PHPToExcel($dateTime));
        $this->getActiveSheet()
                ->getStyle($cellValue)
                ->getNumberFormat()
                ->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_DATE_DDMMYYYY);
        return $this;
    }

    /* Cell Coloring */
    function cellsColor($cells, $t, $color) {
        switch ($t) {
            case 'none': $type = Fill::FILL_NONE;
                break;
            case 'solid': $type = Fill::FILL_SOLID;
                break;
            case 'linear': $type = Fill::FILL_GRADIENT_LINEAR;
                break;
            case 'path': $type = Fill::FILL_GRADIENT_PATH;
                break;
            case 'dark_down': $type = Fill::FILL_PATTERN_DARKDOWN;
                break;
            case 'dark_gray': $type = Fill::FILL_PATTERN_DARKGRAY;
                break;
            case 'dark_grid': $type = Fill::FILL_PATTERN_DARKGRID;
                break;
            case 'dark_horizontal':$type = Fill::FILL_PATTERN_DARKHORIZONTAL;
                break;
            case 'dark_trellis': $type = Fill::FILL_PATTERN_DARKTRELLIS;
                break;
            case 'dark_up': $type = Fill::FILL_PATTERN_DARKUP;
                break;
            case 'dark_vertical':$type = Fill::FILL_PATTERN_DARKVERTICAL;
                break;
            case 'gray0625': $type = Fill::FILL_PATTERN_GRAY0625;
                break;
            case 'gray125': $type = Fill::FILL_PATTERN_GRAY125;
                break;
            case 'light_down': $type = Fill::FILL_PATTERN_LIGHTDOWN;
                break;
            case 'light_gray': $type = Fill::FILL_PATTERN_LIGHTGRAY;
                break;
            case 'light_grid': $type = Fill::FILL_PATTERN_LIGHTGRID;
                break;
            case 'light_horizontal':$type = Fill::FILL_PATTERN_LIGHTHORIZONTAL;
                break;
            case 'light_trellis':$type = Fill::FILL_PATTERN_LIGHTTRELLIS;
                break;
            case 'light_up': $type = Fill::FILL_PATTERN_LIGHTUP;
                break;
            case 'light_vertical':$type = Fill::FILL_PATTERN_LIGHTVERTICAL;
                break;
            case 'medium_gray': $type = Fill::FILL_PATTERN_MEDIUMGRAY;
                break;
        }
        $cell_style = array(
            'type' => $type,
            'startcolor' => array(
                'rgb' => $color
            )
        );
        $this->getActiveSheet()->getStyle($cells)->getFill()->applyFromArray($cell_style);
        return $this;
    }

    /* Text Styling */
    function setTextStyle($cells, $name, $size, $bold, $italic, $underlines, $color) {
        switch ($underlines) {
            case 'double': $underline = Font::UNDERLINE_DOUBLE;
                break;
            case 'double_accounting':$underline = Font::UNDERLINE_DOUBLEACCOUNTING;
                break;
            case 'none': $underline = Font::UNDERLINE_NONE;
                break;
            case 'single': $underline = Font::UNDERLINE_SINGLE;
                break;
            case 'single_accounting':$underline = Font::UNDERLINE_SINGLEACCOUNTING;
                break;
        }
        $this->getActiveSheet()->getStyle($cells)->getFont()
                ->setName($name)    // font name
                ->setSize($size)    // font size
                ->setBold($bold)    // font bold
                ->setItalic($italic)   // italick
                ->setUnderline($underline)  // underline
                //->setStriketrough($this->strick)		
                ->getColor()->setRGB($color); //text color

        return $this;
        /* $text_style = array(
          'name'      => $name,
          'size'      => $size,
          'bold'      => $bold,
          'italic'    => $italic,
          'underline' => $underline,
          //'striketrough'=> $strike,
          'color'     => array('rgb' => $color)
          );
          $this->getActiveSheet()->getStyle($cells)->getFill()->applyFromArray($text_style); */
    }

    /* Text  Alignment */
    function getAlignment($cells, $aligns) {
        // Text Horizontal Alignment
        if ($aligns == 'center' || $aligns == 'right' || $aligns == 'left' || $aligns == 'justify') {
            switch ($aligns) {
                case 'center': $align = Alignment::HORIZONTAL_CENTER;
                    break;
                case 'right': $align = Alignment::HORIZONTAL_RIGHT;
                    break;
                case 'left': $align = Alignment::HORIZONTAL_LEFT;
                    break;
                case 'justify': $align = Alignment::HORIZONTAL_JUSTIFY;
                    break;
            }
            $this->getActiveSheet()->getStyle($cells)->getAlignment()->setHorizontal($align);
        }
        if ($aligns == 'vcenter' || $aligns == 'top' || $aligns == 'bottom' || $aligns == 'vjustify') {
            switch ($aligns) {
                case 'vcenter': $Valign = Alignment::VERTICAL_CENTER;
                    break;
                case 'top': $Valign = Alignment::VERTICAL_TOP;
                    break;
                case 'bottom': $Valign = Alignment::VERTICAL_BOTTOM;
                    break;
                case 'vjustify':$Valign = Alignment::VERTICAL_JUSTIFY;
                    break;
            }
            $this->getActiveSheet()->getStyle($cells)->getAlignment()->setVertical($Valign);
        }
        return $this;
    }

    /* 4.6.22. Styling cell borders */
    function cellBorder($cells, $styles, $type, $color) {
        switch ($styles) {
            case 'none': $style = Border::BORDER_NONE;
                break;
            case 'dash_dot': $style = Border::BORDER_DASHDOT;
                break;
            case 'dash_dot_dot': $style = Border::BORDER_DASHDOTDOT;
                break;
            case 'dashed': $style = Border::BORDER_DASHED;
                break;
            case 'dotted': $style = Border::BORDER_DOTTED;
                break;
            case 'double': $style = Border::BORDER_DOUBLE;
                break;
            case 'hair': $style = Border::BORDER_HAIR;
                break;
            case 'medium': $style = Border::BORDER_MEDIUM;
                break;
            case 'medium_dash_dot':$style = Border::BORDER_MEDIUMDASHDOT;
                break;
            case 'medium_dash_dot_dot': $style = Border::BORDER_MEDIUMDASHDOTDOT;
                break;
            case 'medium_dashed':$style = Border::BORDER_MEDIUMDASHED;
                break;
            case 'slant_dash_dot':$style = Border::BORDER_SLANTDASHDOT;
                break;
            case 'thick': $style = Border::BORDER_THICK;
                break;
            case 'thin': $style = Border::BORDER_THIN;
                break;
        }

        $BStyle = array(
            'borders' => array(
                $type => array(
                    'style' => $style,
                    'color' => array('rgb' => $color),
                ),),);
        $this->getActiveSheet()->getStyle($cells)->applyFromArray($BStyle);
        return $this;
    }

//$objPHPExcel->getActiveSheet()->getStyle('G4')->getAlignment()->setWrapText(true);
//$objPHPExcel->getActiveSheet()->getRowDimension('8:13')->setOutlineLevel(1);
//Get Text Color
//$objPHPExcel->getActiveSheet()->insertNewRowBefore(7, 2);
//4.6.34. Merge/unmerge cells
//objPHPExcel->getActiveSheet()->mergeCells('A6:A7');
//$objPHPExcel->getActiveSheet()->unmergeCells('A18:E22');
}
