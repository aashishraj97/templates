<?php

// include $_SERVER['DOCUMENT_ROOT']."/includes/common.php";
require_once $_SERVER['DOCUMENT_ROOT'] . "/vendor/autoload.php";
include 'SpreadsheetUtil.php';

use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Cell\DataType;

class ExportUtil extends SpreadsheetUtil {

    // Declaring Global Variables 
    private $properties = [];
    private $excel;
    private $sheet;
    private $active_sheet_idx;
    private $idx_row;
    private $idx_col;
    private $col;
    private $file_name;
    private $url;
    private $download;
    private $paper_size = 'a4';
    private $grid_line = true;
    private $page_margin = array(0.5, 0.75, 0.5, 0.75);
    private $page_orient = 'landscape';
    private $zoom_scale = 100;
    // Receiving Data from Data Base 
    private $title;
    private $sub_title;
    private $col_data;
    private $row_data;
    private $multi_row_data;
    // Set Sizes for cell height and width
    private $row_height = 16;
    private $col_width = 40;
    private $auto_col_width = false;
    // Text Style
    private $font_name = 'Arial';
    private $font_size = 12;
    private $bold = false;
    private $italic = false;
    private $underline = 'none';
    private $strike = false;
    private $t_color = '000000';
    // Text Aligment
    private $align = 'left';
    // Border Styles 
    private $b_style = 'none';
    private $b_type = 'outline';
    private $b_color = '000000';
    // Cell Styles
    private $cell_type = 'none';
    private $cell_color = 'ffffff';
    // Even Row Cells Color and Background Color
    private $text_color_for_even_row;
    private $cell_color_for_even_row; //DCDCDC

    // calling to perent class constructor    
    public function __construct() {
        parent::__construct();
    }

    // Set Style 
    public function SetFormatAttributes(array $style) {
        // Text Style
        $this->font_name = isset($style['text']['name']) ? $style['text']['name'] : $this->font_name;
        $this->font_size = isset($style['text']['size']) ? $style['text']['size'] : $this->font_size;
        $this->bold = isset($style['text']['bold']) ? $style['text']['bold'] : $this->bold;
        $this->italic = isset($style['text']['italic']) ? $style['text']['italic'] : $this->italic;
        $this->underline = isset($style['text']['underline']) ? $style['text']['underline'] : $this->underline;
        $this->strike = isset($style['text']['strike']) ? $style['text']['strike'] : $this->strike;
        $this->t_color = isset($style['text']['color']) ? $style['text']['color'] : $this->t_color;
        // Text Alignment
        $this->align = isset($style['align']) ? $style['align'] : $this->align;
        // Set Size for cell height and width
        $this->row_height = isset($style['row_height']) ? $style['row_height'] : $this->row_height;
        $this->col_width = isset($style['col_width']) ? $style['col_width'] : $this->col_width;
        $this->auto_col_width = isset($style['auto_col_width']) ? $style['auto_col_width'] : $this->auto_col_width;
        // Border Styles
        $this->b_style = isset($style['border']['style']) ? $style['border']['style'] : $this->b_style;
        $this->b_type = isset($style['border']['type']) ? $style['border']['type'] : $this->b_type;
        $this->b_color = isset($style['border']['color']) ? $style['border']['color'] : $this->b_color;
        // Cell Styles
        $this->cell_type = isset($style['cell']['type']) ? $style['cell']['type'] : $this->cell_type;
        $this->cell_color = isset($style['cell']['color']) ? $style['cell']['color'] : $this->cell_color;
        // Even Row Cells Color and Background Color
        $this->text_color_for_even_row = isset($style['text_color_for_even_row']) ? $style['text_color_for_even_row'] : $this->text_color_for_even_row;
        $this->cell_color_for_even_row = isset($style['cell_color_for_even_row']) ? $style['cell_color_for_even_row'] : $this->cell_color_for_even_row;
        return $this;
    }

    // set Format
    private function SetFormat() {
        $this->setTextStyle($this->col . $this->idx_row . ":" . $this->col . $this->idx_row, $this->font_name, $this->font_size, $this->bold, $this->italic, $this->underline, $this->t_color);
        $this->cellsColor($this->col . $this->idx_row . ":" . $this->col . $this->idx_row, $this->cell_type, $this->cell_color);
        $this->getAlignment($this->col . $this->idx_row . ":" . $this->col . $this->idx_row, $this->align);
        $this->setRowHeight($this->idx_row, $this->row_height);
        if ($this->b_color) {
            $this->cellBorder($this->col . $this->idx_row, $this->b_style, $this->b_type, $this->b_color);
        }
        if ($this->auto_col_width == true) {
            $this->setColumnWidthAuto($this->col);
        }
        $this->setPaperSize($this->paper_size);
        $this->setShowGridlines($this->grid_line);
        return $this;
    }

    // Default Page Setting
    public function DefaultPageSetting($config) {
        $this->paper_size = isset($config['paper_size']) ? $config['paper_size'] : $this->paper_size;
        $this->grid_line = isset($config['grid_line']) ? $config['grid_line'] : $this->grid_line;
        $this->page_margin = isset($config['page_margin']) ? $config['page_margin'] : $this->page_margin;
        $this->page_orient = isset($config['orientation']) ? $config['orientation'] : $this->page_orient;
        $this->zoom_scale = isset($config['zoom']) ? $config['zoom'] : $this->zoom_scale;

        //4.6.9. Setting a worksheet’s page orientation and size
        $this->setPageOrientation($this->page_orient);
        $this->setPaperSize($this->paper_size); //A4 ledger legal
        // 4.6.21. Setting the default style of a workbook , 
        $this->getDefaultSetting();

        // 4.6.44. Setting worksheet zoom level
        $this->setZoomScale($this->zoom_scale);

        //4.6.11. Page margins in inches default is (top=1, right=0.75, bottom=1, left=0.75)
        $this->setPageMargins($this->page_margin); //0.5,0.75,0.5,0.75
        //4.6.17. Specify printing area
        //$this->setPrintArea('A1:H33');
        // Show Grid line or hide
        $this->setShowGridlines($this->grid_line);
        return $this;
    }

    // Auto Set Properties
    public function SetProperty(array $properties) {
        $this->properties = $properties;

        if (!empty($this->properties) && is_array($this->properties)) {
            $prop_mngr = $this->getProperties();
            foreach ($this->properties as $prop => $val) {
                $method = 'set' . ucfirst($prop);
                if (method_exists($prop_mngr, $method))
                    $prop_mngr->{$method}($val);
            }
        }
        return $this;
    }

    // Creating Active Index
    public function SetActiveSheetIdx($idx = 0) {
        $this->sheet = $this->setActiveSheetIndex($idx);
        $this->idx_row = 1;
        $this->idx_col = 0;
        $this->col = 'A';
        return $this;
    }

    // Set Page Title 
    public function SetTitle($title) {
        $this->title = isset($title) ? $title : [];
        if (is_array($this->title) && !empty($this->title)) {
            $this->idx_col = 0;
            foreach ($this->title as $col_data) {
                $this->SetFormat();
                $this->sheet->setCellValueExplicitByColumnAndRow($this->idx_col++, $this->idx_row, ucfirst($col_data), DataType::TYPE_STRING);
                $this->getActiveSheet()->mergeCells("A" . $this->idx_row . ":C" . $this->idx_row);
            }
            $this->idx_row++;
            $this->col = 'A';
        } return $this;
    }

    // Set Page Sub_Title
    public function SetSubTitle($sub_title) {
        $this->sub_title = isset($sub_title) ? $sub_title : [];
        if (is_array($this->sub_title) && !empty($this->sub_title)) {
            $this->idx_col = 0;
            foreach ($this->sub_title as $col_data) {
                $this->SetFormat();
                $this->sheet->setCellValueExplicitByColumnAndRow($this->idx_col, $this->idx_row, ucfirst($col_data), DataType::TYPE_STRING);
                $this->getActiveSheet()->mergeCells("A" . $this->idx_row . ":C" . $this->idx_row);
                $this->idx_row++;
            }

            $this->col = 'A';
        } return $this;
    }

    // Set Table header
    public function TableHeader($col_data) {
        $this->col_data = isset($col_data) ? $col_data : [];

        if ($this->col_data) {
            $this->idx_col = 0;
            foreach ($this->col_data as $col_data) {
                $this->SetFormat();
                $this->sheet->setCellValueExplicitByColumnAndRow($this->idx_col++, $this->idx_row, ucfirst($col_data),DataType::TYPE_STRING);
                $this->getActiveSheet()->setAutoFilter('A' . $this->idx_row . ":" . $this->col . $this->idx_row);   // Set Auto Filter
                //$this->getActiveSheet()->mergeCells('A1:'.$this->col.'1');//auto merge title
                $this->col++;
            }
            $this->idx_row++;
            $this->getActiveSheet()->freezePane($this->col . $this->idx_row);
            $this->col = 'A';
        }
        return $this;
    }

    // SetMultiRow Data
    /*
      foreach($result as $eachrow)
      foreach ($field_db_name as $key => $value) {
      if($value=="date"){
      if($key=='last_modified'){
      $dates = explode(' ', $eachrow[$key]);
      $date=$MapleUtilObj->getDateIndianFormat($dates[0])."   ".$dates[1];
      }else{
      $result=$MapleUtilObj->getDateIndianFormat($eachrow[$key]);
      }
      }else{
      $result=$eachrow[$key]);
      } }} */
    public function SetMultiRow($multi_row_data) {
        $this->multi_row_data = isset($multi_row_data) ? $multi_row_data : [];
        foreach ($this->multi_row_data as $row) {
            $this->idx_col = 0;
            foreach ($row as $col => $val) {
                $this->SetFormat();
                if ($this->idx_row % 2 == 1) {
                    $this->cellsColor($this->col . $this->idx_row . ":" . $this->col . $this->idx_row, $this->cell_type, !empty($this->cell_color_for_even_row) ? $this->cell_color_for_even_row : $this->cell_color);
                    $this->setTextStyle($this->col . $this->idx_row . ":" . $this->col . $this->idx_row, $this->font_name, $this->font_size, $this->bold, $this->italic, $this->underline, !empty($this->t_color_for_even_row) ? $this->text_color_for_even_row : $this->t_color);
                }
                $this->sheet->setCellValueExplicitByColumnAndRow($this->idx_col++, $this->idx_row, $val, DataType::TYPE_STRING);
                $this->col++;
            }$this->col = 'A';
            $this->idx_row++;
        }
        return $this;
    }

    public function SetRow() {
        $this->idx_col = 0;
        foreach ($this->row_data as $row) {
            $this->SetFormat();
            $this->sheet->setCellValueExplicitByColumnAndRow($this->idx_col++, $this->idx_row, $row);
            $this->col++;
        }$this->col = 'A';
        $this->idx_row++;
        return $this;
    }

    // Increment Row
    public function IncrementRow($no_of_rows) {
        $this->idx_col = 0;
        for ($i = 0; $i < $no_of_rows; $i++) {
            $this->sheet->setCellValueExplicitByColumnAndRow($this->idx_col++, $this->idx_row,'',DataType::TYPE_STRING);
            $this->idx_row++;
        }
        return $this;
    }

    // Export The Excel File
    public function Save($file_name, $extension) {
        // Redirect output to a client’s web browser (Excel2007/Excel5/PDF)
        //require_once dirname(__FILE__).'/../../../../PHPExcel-1.8/Classes/PHPExcel/IOFactory.php';
        switch ($extension) {
            case 'pdf' : header('Content-type:Application/pdf');
                break;
            case 'csv' || 'xls' : header('Content-Type: application/vnd.ms-excel');
                break;
            case 'xlsx':header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                break;
        }

        header('Content-Disposition: attachment;filename="' . $file_name . '.' . $extension . '"'); // for download the pdf file

        header('Cache-Control: max-age=0');
        // If you're serving to IE 9, then the following may be needed
        header('Cache-Control: max-age=1');
        // If you're serving to IE over SSL, then the following may be needed
        header('Expires: Mon, 26 Jul 1997 05:00:00 IST'); // Date in the past
        header('Last-Modified: ' . gmdate('D, d M Y H:i:s', time() + 19800) . ' IST'); // always modified
        header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header('Pragma: public'); // HTTP/1.0
        
        switch ($extension) {
            case 'pdf': $objWriter = IOFactory::createWriter($this, 'Dompdf');
                //You need to include and print to PDF the entire worksheets contained in the workbook
                $objWriter->setExcelCompatibility(true);
                $objWriter->writeAllSheets();
                break;
            case 'csv': 
                $objWriter = new PhpOffice\PhpSpreadsheet\Writer\Csv($this);
                //$objWriter = IOFactory::createWriter($this, 'csv');
                break;
            case 'xls': 
                $objWriter = new PhpOffice\PhpSpreadsheet\Writer\Xls($this);
                //$objWriter = IOFactory::createWriter($this, 'Xls');
                break;
            case 'xlsx':
                $objWriter = new PhpOffice\PhpSpreadsheet\Writer\Xlsx($this);
        //$objWriter = IOFactory::createWriter($this, 'Xlsx');
                break;
        }
        $objWriter->save('php://output');
        exit;
    }

    public function Export(array $options) {
        $this->options = $options;
        $this->title = isset($options['title']) ? $options['title'] : false;
        $this->sub_title = isset($options['sub_title']) ? $options['sub_title'] : false;
        $this->col_data = isset($options['col_data']) ? $options['col_data'] : false;
        $this->row_data = isset($options['row_data']) ? $options['row_data'] : [];
        $this->multi_row_data = isset($options['multi_row_data']) ? $options['multi_row_data'] : [];
        $this->file_name = isset($options['save']['file_name']) ? $options['save']['file_name'] : false;

        if (is_array($this->row_data) && !empty($this->row_data)) {
            $this->DefaultPageSetting()
                    ->SetProperty()
                    ->SetActiveSheetIdx()
                    ->SetTitle()
                    ->SetSubTitle()->IncrementRow(1)
                    ->TableHeader()
                    ->SetMultiRow()
                    ->SetRow()
                    ->Save($this->file_name);
        } else
            return false; // message file does not contain any row_data
    }
}
