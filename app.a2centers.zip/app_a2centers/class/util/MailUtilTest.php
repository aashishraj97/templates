<?php  
/**
 * This example shows making an SMTP connection with authentication.
 */
require_once dirname( dirname(__DIR__) ) . "/vendor/autoload.php";

//Import the PHPMailer class into the global namespace
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;

/**
 * Description of Database
 * in order to user tables use static DBTable::TABLE_NAME
 * @author Aashish Raj
 * @email aashishraj97@gmail.com
 * @website tictik.org
 */

class MailUtil extends PHPMailer {
    /* to hold the phpmailer instance */
    private $mail;
    
    /* calling parent constructor to make database */
    public function __construct() {
        
        /* Create a new PHPMailer instance */
        //$this->mail = new PHPMailer;
        
        /* Tell PHPMailer to use SMTP */
        $this->isSMTP();
        /**Enable SMTP debugging
         * SMTP::DEBUG_OFF = off (for production use)
         * SMTP::DEBUG_CLIENT = client messages
         * SMTP::DEBUG_SERVER = client and server messages */
        $this->SMTPDebug = SMTP::DEBUG_SERVER;
        /* Set the encryption mechanism to use - STARTTLS or SMTPS */
        $this->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        /* Custom connection options Note that these settings are INSECURE */
        $this->SMTPOptions =    [
                                    'ssl' => [
                                        'verify_peer' => false,
                                        'verify_peer_name' => false,
                                        'allow_self_signed' => true
                                    ]
                                ];
 
        /* Whether to use SMTP authentication */
        $this->SMTPAuth = true;
        /* Username to use for SMTP authentication */
//        $this->Username = 'web_admin@d1ftetracker.com';
        /* Password to use for SMTP authentication */
//        $this->Password = 'KSCulC348ca';
 
        /* Set the hostname of the mail server */
//        $this->Host = 'smtp.d1ftetracker.com';
        
        $this->Username = 'AKIA444S2HKTK52DQE6P';
        $this->Password = 'BMPzsmf/OEo8jjOoM1QBMaxcfEn9f7SUOp+YDXA+scrn';
        $this->Host = 'email-smtp.us-east-2.amazonaws.com';
        $this->Port = 587;     
        $this->setFrom('web_admin@d1ftetracker.com', 'D1FTE - Tracker');
        
//        $this->Username = 'imap.csscorp@gmail.com';
//        $this->Password = 'welcome@123';
//        $this->Host = 'smtp.gmail.com';
//        $this->setFrom('imap.csscorp@gmail.com', 'D1FTE - Tracker');
        /* Set the SMTP port number - likely to be 25, 465 or 587 */
           
 
        /* Set who the message is to be sent from */
        $this->setFrom('web_admin@d1ftetracker.com', 'D1FTE - Tracker');
        /* Set an alternative reply-to address */
        $this->addReplyTo('web_admin@d1ftetracker.com', '');
    }
    
    
    /**
     * 
     * @param type $params associative array
     * @return type associative array
     */
    public function _send_mail($params = []) {
        
        $to_list    = isset($params['to'])?$params['to']:[];
        $cc_list    = isset($params['cc'])?$params['cc']:[];
        $bcc_list   = isset($params['bcc'])?$params['bcc']:[];
        $subject    = isset($params['subject'])?$params['subject']:'';
        $message    = isset($params['message'])?$params['message']:'';
        $attachments= isset($params['attachments'])?$params['attachments']:[];
        
        /* Set who the message is to be sent to */
        foreach ($to_list as $email => $name) {
            $this->addAddress($email, $name);
        }
        foreach ($cc_list as $email => $name) {
            $this->addCc($email, $name);
        }
        foreach ($bcc_list as $email => $name) {
            $this->addBCC($email, $name);
        }
        
        /* Set the subject line */
        $this->Subject = $subject;
        
        /** $this->msgHTML(file_get_contents('contents.html'), __DIR__);
         * Read an HTML message body from an external file, convert referenced images to embedded,
         * convert HTML into a basic plain-text alternative body 
         */
        $this->msgHTML($message);
        
        /* Replace the plain text body with one created manually */
        $this->AltBody = 'This is a plain-text message body';
        
        /* Attach docs file here */
        foreach ($attachments as $key => $src) {
            $this->addAttachment($src);
        }

        /* send the message, check for errors */
        if (!$this->send()) {
            $response['RESPONSE'] = 'ERROR';
            $response['MESSAGE'] = 'Mailer Error: ' . $this->ErrorInfo;
        } else {
            $response['RESPONSE'] = 'SUCCESS';
            $response['MESSAGE'] = 'Message sent!';
        }
        
        return $response;
    }
    
    /**
     * 
     * @param type $name string
     * @return type associative array
     */
    public function _get_template($name = null) {
        
        //include_once $_SERVER['DOCUMENT_ROOT'] . "/includes/common.php";
        $DBUtilObj = new DBUtil();
        if(empty($name)) {
            $object = $DBUtilObj->_select(DBTable::EMAIL_TEMPLATES);
            $response['data'] = $object->_fetch_all();
        }
        else {
            $data['where'] = "type='" . $name ."'";
            $object = $DBUtilObj->_select(DBTable::EMAIL_TEMPLATES,$data);
            $response['data'] = $object->_fetch_array();
        }
        
        $response['num_rows'] = $object->_num_rows();
        $response['object'] = $object;
        return $response;
    }
    
}

$MailUtilObj = new MailUtil();
//$content = $MailUtilObj->_get_template('temporary-password');
//$content = $content['data']['content'];
$content = 'Body Content';//file_get_contents(dirname( dirname(__DIR__) ).'/pages/mail-templates/temporary-password.php');
$params = ['narayanamoorthy.srinivasan@csscorp.com'=>'Moorthy','to'=>['ashish.raj@ind.csscorp.com'=>'Raj'],
            'subject'=>'SES Mail Test',
            'message'=>$content,
            'attachments'=>[]];
$res = $MailUtilObj->_send_mail($params);
var_dump($res);
?>
<!--<html>
    <body>
        <div>
            <input type="text" name="email">
        </div>
    </body>
</html>-->
