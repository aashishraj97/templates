<?php

namespace SUPR\Component\QueryBuilder;

/**
 * Class SQLQuery
 *
 * @package SUPR\Component\QueryBuilder
 */
class SQLQuery
{
    /**
     * Sort Order Ascending
     */
    const ORDER_ASC = 'ASC';

    /**
     * Sort Order Descending
     */
    const ORDER_DESC = 'DESC';

    /**
     * @var array table
     */
    private $table = [];

    /**
     * @var array fieldList
     */
    private $fieldList = [];

    /**
     * @var array joins
     */
    private $joins = [];

    /**
     * @var array order
     */
    private $order = [];

    /**
     * @var array limits
     */
    private $limits = array(0, 100);

    /**
     * @var array wheres
     */
    private $wheres = [];

    /**
     * @var string baseCommand
     */
    private $baseCommand = '';

    /**
     * @var array payload
     */
    private $payload = [];

    /**
     * @var callable escapeFunction
     */
    private $escapeFunction = null;

    /**
     * Reserved words that will not be escaped
     *
     * @var array reservedWords
     */
    protected $reservedWords = array('NOW', 'TIMESTAMP', 'NULL');

    /**
     * Creates a new SQLQuery-Instance
     *
     * @return SQLQuery
     */
    public static function create()
    {
        return new self();
    }

    /**
     * @return callable
     */
    public function getEscapeFunction()
    {
        return $this->escapeFunction;
    }

    /**
     * @param $escapeFunction
     * @return $this
     */
    public function setEscapeFunction($escapeFunction)
    {
        $this->escapeFunction = $escapeFunction;

        return $this;
    }

    /**
     * Parse a nested array of conditions.
     * When building your condition array, you can use '_or' and '_and' to concantenate
     * queries. The default operator is 'AND' For example:
     *
     * ```php
     * array(
     *  'name' => 'Bob'
     *  'job_title' => 'Developer',
     *  '_or' => array(
     *   'name' => 'Sally',
     *   'job' => 'Producer'
     *   ),
     *  '_like' => array(
     *   'name',
     *   'Sal%'
     *   )
     * )
     * ```
     *
     * ** Options**
     * keysAreLikelyTableRef:   If this is set, the conditionParse will assume, that
     *                          values matching FOO.BAR represent a table reference and thus need to be
     *                          escaped as field names.
     *                          This option is used e.g. when solving ON-Conditions in joins
     *
     * This method will return the final SQL string
     *
     * @param array  $conditions The Conditions Array to parse
     * @param string $concat     The concatenation operator (SQL)
     * @param array  $options
     * @return string
     * @throws \Exception
     */
    private function parseConditions(array $conditions, $concat = 'AND', $options = [])
    {
        // normalize options
        $options = array_merge(['keysAreLikelyTableRef' => false], $options);
        $parsedConditions = [];

        foreach ($conditions as $field => $val) {
            if (strtolower($field) == '_or') {
                $subC = $this->parseConditions($val, 'OR');
                $parsedConditions[] = $subC;
            } elseif (strtolower($field) == '_and') {
                $subC = $this->parseConditions($val, 'AND');
                $parsedConditions[] = $subC;
            } elseif (strtolower($field) == '_like' && is_array($val) && sizeof($val) == 2) {
                 $parsedConditions[] = "lower(" . $this->escapeField($val[0]) . ") like " . "lower('" . $val[1] . "')";
            } else {
                $containsOperator = preg_match(
                    '/(?P<field>[A-z ]*)\W* (?P<operator>\>=|\<=|!=|is not|is|=|\>|\<)/i',
                    $field,
                    $matches
                );
                $parsedValue = '';

                if (is_array($val)) {
                    foreach ($val as $k => $v) {
                        $val[$k] = $this->sanitizeValue($v);
                    }

                    $parsedValue = '(' . implode(',', $val) . ')';
                } else {
                    if (preg_match('/^\w+$/', $val) || preg_match('/^\w+\.\w+$/', $val)) {
                        if (true === $options['keysAreLikelyTableRef']) {
                            $parsedValue = $this->escapeField($val);
                        } else {
                            $parsedValue = $this->sanitizeValue($val);
                        }
                    } else {
                        $parsedValue = $this->sanitizeValue($val);
                    }
                }

                if (!$containsOperator) {
                    if (is_array($val)) {
                        $parsedConditions[] = $this->escapeField($field) . " IN $parsedValue";
                    } else {
                        $parsedConditions[] = $this->escapeField($field) . " = $parsedValue";
                    }
                } else {
                    if (empty($matches['field']) || empty($matches['operator'])) {
                        throw new \Exception('Could not parse query');
                    }

                    $matches['field'] = trim($matches['field']);
                    $parsedConditions[] = $this->escapeField($matches['field']) . " $matches[operator] $parsedValue";
                }
            }
        }

        return '(' . implode(') ' . $concat . ' (', $parsedConditions) . ')';
    }

    /**
     * Normalizes objects and arrays to strings
     *
     * @param mixed $val
     * @return string
     */
    protected function normalizeValue($val)
    {
        if ($val instanceof \DateTime) {
            $val = $val->format('Y-m-d H:i:s');
        } else if (is_array($val) || is_object($val)) {
            $val = json_encode($val);
        }

        return $val;
    }

    /**
     * Sanitizes a value depending on it's type.
     *
     * @param $val
     * @return string
     */
    protected function sanitizeValue($val)
    {
        $val = $this->normalizeValue($val);

        if (in_array(strtoupper($val), $this->reservedWords)) {
            return $val;
        }

        if ($val === '') {
            return '\'\'';
        } else if (is_int($val) || is_float($val)) {
            return $val;
        } else if (null === $val) {
            return 'NULL';
        }

        if (is_callable($this->getEscapeFunction())) {
            $val = call_user_func($this->getEscapeFunction(), $val);

            // check if the escape functions put quotes around the string
            if (substr($val, 0, 1) !== '\'' || substr($val, -1, 1) !== '\'') {
                $val = "'{$val}'";
            }
        } else {
            $val = "'{$val}'";
        }

        return $val;
    }

    /**
     * @return string
     */
    protected function buildSetList()
    {
        $sets = [];

        foreach ($this->payload as $key => $value) {
            $sets [] = $this->escapeField($key) . ' = ' . $this->sanitizeValue($value);
        }

        return implode(', ', $sets);
    }

    /**
     * @return string
     */
    protected function buildInsertList()
    {
        $values = [];
        $fields = [];

        foreach ($this->payload as $key => $value) {
            $fields [] = $this->escapeField($key);
            $values [] = $this->sanitizeValue($value);
        }

        return '(' . implode(', ', $fields) . ') VALUES (' . implode(', ', $values) . ')';
    }

    /**
     * This method builds the final sql query
     *
     * @return string
     * @throws \Exception
     */
    protected function generateSQL()
    {
        $sql = '';

        switch ($this->baseCommand) {
            case 'INSERT':
                $sql .= "INSERT INTO `{$this->table[0]}` {$this->buildInsertList()}";

                break;
            case 'UPDATE':
                $sql .= "UPDATE `{$this->table[0]}` SET {$this->buildSetList()}";

                if (!empty($this->wheres)) {
                    $sql .= " WHERE {$this->parseConditions($this->wheres)}";
                }

                break;
            default:
                $sql .= $this->baseCommand;

                if (
                    strpos($this->baseCommand, 'COUNT(*) AS ') === false
                    &&
                    strpos($this->baseCommand, 'DELETE') === false
                ) {
                    if (!empty($this->fieldList)) {
                        $sql .= ' ' . $this->escapeFieldlist($this->fieldList);
                    } else {
                        $sql .= ' *';
                    }
                }

                $sql .= " FROM `{$this->table[0]}`";

                if ($this->table[1] != '') {
                    $sql .= " `{$this->table[1]}`";
                }

                foreach ($this->joins as $join) {
                    $sql .= " {$join['type']} JOIN `{$join['table']}`";

                    if ($join['alias'] != '') {
                        $sql .= " `{$join['alias']}`";
                    }

                    $sql .= " ON (" . $this->parseConditions($join['conditions'], 'AND', ['keysAreLikelyTableRef' => true]) . ")";
                }

                if (!empty($this->wheres)) {
                    $sql .= " WHERE {$this->parseConditions($this->wheres)}";
                }

                if (!empty($this->order)) {
                    $sql .= " ORDER BY {$this->escapeField($this->order[0])} {$this->order[1]}";
                }

                if (
                    1 <= $this->limits[1]
                    &&
                    !in_array($this->baseCommand, ['DELETE', 'UPDATE', 'INSERT'])
                ) {
                    $sql .= " LIMIT {$this->limits[0]},{$this->limits[1]}";
                }

                break;
        }

        return $sql;
    }

    /**
     * This method escapes a list of field names
     *
     * @param array $fields
     * @return string
     */
    protected function escapeFieldlist(array $fields)
    {
        foreach ($fields as $k => $v) {
            $v = trim($v);
            $fields[$k] = $this->escapeField($v);
        }

        return implode(", ", $fields);
    }

    /**
     * This method escapes a field name, paying attention to 'TABLE.FIELD' syntax
     *
     * @param $v
     * @return string
     */
    protected function escapeField($v)
    {
        if (strpos($v, '.') !== false) {
            if (strpos($v, '*') !== false) {
                $v = "`" . str_replace(".", "`.", $v);
            } else {
                $v = "`" . str_replace(".", "`.`", $v) . "`";
            }
        } else {
            if (strpos($v, '*') === false) {
                $v = "`" . $v . "`";
            }
        }

        return $v;
    }

    /**
     * SELECTs rows from a table
     *
     * @param array|string $fieldList
     * @return $this
     */
    public function select($fieldList = '*')
    {
        if (!is_array($fieldList)) {
            $fieldList = [$fieldList];
        }

        $this->baseCommand = 'SELECT';
        $this->fieldList = $fieldList;

        return $this;
    }

    /**
     * DELETEs rows from a table
     *
     * @param array $fieldList
     * @return $this
     */
    public function delete($fieldList = [])
    {
        $this->baseCommand = 'DELETE';
        $this->fieldList = $fieldList;

        return $this;
    }

    /**
     * COUNTs the rows in a table.
     *
     * @param string $countFieldName The name of the field in the resultset that holds the row count.
     *                               Defaults to '_count'
     * @return $this
     */
    public function countRows($countFieldName = '_count')
    {
        $this->baseCommand = "SELECT COUNT(*) AS {$countFieldName}";

        return $this;
    }

    /**
     * Sets the target table
     *
     * @param string $table
     * @param string $alias
     * @return $this
     */
    public function from($table, $alias = '')
    {
        $this->table = [$table, $alias];

        return $this;
    }

    /**
     * Sets the target table
     *
     * @param string $table
     * @param string $alias
     * @return $this
     */
    public function into($table, $alias = '')
    {
        $this->table = [$table, $alias];

        return $this;
    }

    /**
     * LEFT JOINs a table
     *
     * @param string $table
     * @param array  $conditions
     * @param string $alias
     * @return $this
     */
    public function leftJoin($table, $conditions, $alias)
    {
        $this->joins[] = [
            'table' => $table,
            'conditions' => $conditions,
            'alias' => $alias,
            'type' => 'LEFT'
        ];

        return $this;
    }

    /**
     * RIGHT JOINs a table
     *
     * @param string $table
     * @param array  $conditions
     * @param string $alias
     * @return $this
     */
    public function rightJoin($table, $conditions, $alias)
    {
        $this->joins[] = [
            'table' => $table,
            'conditions' => $conditions,
            'alias' => $alias,
            'type' => 'RIGHT'
        ];

        return $this;
    }

    /**
     * INNER JOINs a table
     *
     * @param string $table
     * @param array  $conditions
     * @param string $alias
     * @return $this
     */
    public function innerJoin($table, $conditions, $alias)
    {
        $this->joins[] = [
            'table' => $table,
            'conditions' => $conditions,
            'alias' => $alias,
            'type' => 'INNER'
        ];

        return $this;
    }

    /**
     * FULL OUTER JOINs a table.
     *
     * @param string $table
     * @param array  $conditions
     * @param string $alias
     * @return $this
     */
    public function fullOuterJoin($table, $conditions, $alias)
    {
        $this->joins[] = [
            'table' => $table,
            'conditions' => $conditions,
            'alias' => $alias,
            'type' => 'FULL OUTER'
        ];

        return $this;
    }

    /**
     * Defines a a number of conditions in a WHERE clause.
     *
     * @param array $conditions
     * @return $this
     */
    public function where($conditions)
    {
        $this->wheres = $conditions;

        return $this;
    }

    /**
     * ORDERs the result set.
     *
     * @param string $field
     * @param string $dir
     * @return $this
     */
    public function orderBy($field, $dir = self::ORDER_ASC)
    {
        $this->order = [$field, $dir];

        return $this;
    }

    /**
     * LIMITs the number of returned rows
     *
     * @param string|int $start
     * @param string|int $offset
     * @return $this
     */
    public function limit($start, $offset)
    {
        $this->limits = [$start, $offset];

        return $this;
    }

    /**
     * Insert Data.
     *
     * @param array $data
     * @param bool  $multipleRows
     * @return $this
     */
    public function insert($data, $multipleRows = false)
    {
        $this->baseCommand = 'MULTI_INSERT';

        if (false === $multipleRows) {
            $this->baseCommand = 'INSERT';
        }

        $this->payload = $data;

        return $this;
    }

    /**
     * Update.
     *
     * @param array $data
     * @return $this
     */
    public function update($data)
    {
        $this->baseCommand = 'UPDATE';
        $this->payload = $data;

        return $this;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return (string)$this->generateSQL();
    }
}