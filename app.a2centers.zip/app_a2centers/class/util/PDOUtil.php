<?php include_once $_SERVER['DOCUMENT_ROOT'] . "/includes/config.php";
/**
 * Description of DBUtil
 * by using PDO connection which provide flexibility to connect with any database
 * @author Aashish Raj
 * @email aashishraj97@gmail.com
 * @website http://tictik.org
 */
class PDOUtil extends PDO {
    protected $show_errors = TRUE;
    protected $query_closed = TRUE;
    //protected $connection;

    public function __construct() {
        try {
            parent::__construct(DB::BASE.":dbname=".DB::NAME.";host=".DB::HOST, DB::USER, DB::PASS);
            //$this->connection = new PDO($this->database.":dbname=".DB::NAME.";host=".DB::HOST, DB::USER, DB::PASS);
        } catch (PDOException $e) {
            $this->_error('Failed to connect to PDO - ' . $e->getMessage());
        }
    }

    public function _query($query) {
        $this->prepare("UPDATE `users` SET user=:var");
        $this->bindParam(":var",$var);
        $this->execute();
        return $this;
    }

    public function _fetch_all($callback = null) {
        // insert each value by prepared statement
        for( $i = 0; $i < $num_values; $i++ )
            $db->prepare( 'INSERT INTO data VALUES (?);' )->execute( array($binary[$i]) );

        // fetch the entire row
        $data = $db->query( 'SELECT binary FROM data;' )->fetchAll( PDO::FETCH_COLUMN );
        return $result;
    }

    public function _fetch_array() {
        /* Execute a prepared statement by passing an array of values */
        $sth = $dbh->prepare('SELECT name, colour, calories
            FROM fruit
            WHERE calories < ? AND colour = ?');
        $sth->execute(array(150, 'red'));
        $red = $sth->fetchAll();
        $sth->execute(array(175, 'yellow'));
        $yellow = $sth->fetchAll();
        return $result;
    }

    public function _close() {
        //return $this->close();
    }

    public function _num_rows() {
        //$this->query->store_result();
        //return $this->query->num_rows;
    }

    public function _affected_rows() {
        //return $this->query->affected_rows;
    }

    public function _insert_id() {
        return $this->lastInsertId();
    }

    public function _error($error = '') {
        if ($this->show_errors) {
            exit($error . ":" . $this->errorCode() . ":" . $this->errorInfo());
        }
    }

    private function _gettype($var) {
        if (is_string($var))
            return 's';
        if (is_float($var))
            return 'd';
        if (is_int($var))
            return 'i';
        return 'b';
    }
}