<?php
# date_default_timezone_set('Etc/UTC');
/**
 * Description of DateTime
 * in order to user tables use static DBTable::TABLE_NAME
 * 
 * conclusion : 
 * @php all the server-site programing language (php) function such : time(), date() & DateTime() are giving server time
 * @javascript in order to get device time use client-side programing language (javascript) function such as : new Date()
 * @sql do not use any sql date time functions such as NOW(), CURDATE() and so on
 * 
 * @author Aashish Raj
 * @email aashishraj97@gmail.com
 * @website tictik.org
 */
class DateTimeUtil {
    
    
    /** default IST Asia/Kolkata offset value 19800
     * get timezone info such as code, name, location
     * @param type $offset value must be in seconds
     * @return type associative array
     */
    function _get_timezone_info_by_offset($offset='19800')
    {
        $response = [];
        /*
        if(abs($offset)===0){
//            $name = 'Greenwich Mean Time';
//            $response['code'] = 'GMT';
//            $name = 'Europe/London';
//            $response['code'] = 'GB'; //'country_code'=>'UK'
            $name = 'Coordinated Universal Time';
            $response['code'] = 'UTC';
            $response['name'] = $name;
            $response['offset'] = $offset;
            $response['location'] = json_encode(['country_code'=>'GL','latitude'=>'51.4848','longitude'=>'0.0030']);
            return $response;
        }
        */
        
        $abb_list = timezone_abbreviations_list();
        foreach ($abb_list as $abb_key => $abb_val) {
            foreach ($abb_val as $key => $value) {
                if(intval($value['offset']) === intval($offset)){
                    $name = $value['timezone_id'];
                    if($name == null){continue;}
                    $location = timezone_location_get(timezone_open($name));
                    if(isset($location['country_code']) && (($location['country_code']=== "??"))){continue;}
                    $response['code'] = strtoupper($abb_key);
                    $response['name'] = $name;
                    $response['offset'] = $offset;
                    $response['location'] = json_encode($location);
                    break;
                }
            }
        }
        
        return $response;
        
        /* to get offset value in js use
        function _get_device_timezone_info(){
            /* creating date object 
            let obj = {},
                now = new Date();
            /* getTimezoneOffset return in minutes and Ones' complement/invert value, 
             * The ones' complement of the number then behaves like the negative of 
             * the original number in some arithmetic operations  
             * to convert in offset = minuts*60*-1  (here 60 times make in second and -1 times invert the value
             
            obj.offset = now.getTimezoneOffset()*60*-1;
            obj.datetime = now.toISOString().slice(0, 19).replace('T', ' ');
            /* return object 
            return obj;
        }
        */
    }
    
    public function _get_timezone_offset_by_utc($utc = '+05:30') {
        
        // Calculate seconds from offset
        list($hours, $minutes) = explode(':', $utc);
        $offset = $hours * 60 * 60 + $minutes * 60;
        return $offset;
        
        /*
        // Get timezone name from seconds
        $tz = timezone_name_from_abbr('', $offset, 1);
        // Workaround for bug #44780
        if($tz === false) $tz = timezone_name_from_abbr('', $offset, 0);
        
        return $tz;
        //to change the server timezone
        date_default_timezone_set($tz);
        */
    }
    
    public function _date(string $format, $strtotime = null) {
        
        if($strtotime){
            return date($format, $strtotime);
        }
        
        return date($format);
    }
    
    public function _offset_date(string $format, $offfset) {
        return date($format,time()+$offfset);
    }
    
    public function _datetime_diff(string $from_datetime, string $to_datetime) {
        $start_date = new DateTime($from_datetime);
        $object = $start_date->diff(new DateTime($to_datetime));
        
        return $object;
        /*  echo $object->days.' days total<br>';
            echo $object->y.' years<br>';
            echo $object->m.' months<br>';
            echo $object->d.' days<br>';
            echo $object->h.' hours<br>';
            echo $object->i.' minutes<br>';
            echo $object->s.' seconds<br>';
         */
    }
    
    /**
     * to convert a database date input to indian date return 
     * @param type $date string
     * @return type string
     */
    public function _convert_database_to_indian_date_format(string $date) {
        /*date_format(date_create($date),"Y/m/d H:i:s");*/
        return date_format(date_create($date),"d-m-Y");
    }
    
    public function _convert_indian_to_database_date_format(string $date) {
        /*refer crud date field search logic calling one fun _build_mysql_format something*/
        return date_format(date_create($date),"Y-m-d");
    }
}
//date_default_timezone_set('UTC');  // set in php.ini file or here for temporary use
//echo strtotime("07/23/2020"); //it will return epoch time
//echo '<br/>';
//echo date("jS F, Y h:i:i a", time());
//echo '<br/>';
//echo date('Y-m-d H:i:s');
//echo '<br/>';
//$DateObj = new DateTime();
//echo $DateObj->format( 'Y-m-d H:i:s' ), "lksjfdaksj\n";
//echo '<br/>';
//var_dump($DateObj->getTimezone());