<?php include_once $_SERVER['DOCUMENT_ROOT'] . "/includes/common.php";
/**
 * Description of Database
 * in order to user tables use static DBTable::TABLE_NAME
 * @author Aashish Raj
 * @email aashishraj97@gmail.com
 * @website tictik.org
 */
class LogUtil extends DBUtil {
    private $fields = [];
    
    /* calling parent constructor to make database */
    public function __construct() {
        parent::__construct();
    }
    
    /**
     * $where = null, $order_by = 'id desc', $limit=10
     * @param type $where string
     * @return type associative array
     */
    public function _get($data = []) {
        $object = $this->_select(DBTable::LOGS,$data);
        $response['num_rows'] = $object->_num_rows();
        $response['data'] = $object->_fetch_all();
        $response['object'] = $object;
        return $response;
    }
}