<?php include_once $_SERVER['DOCUMENT_ROOT'] . "/includes/config.php";
/**
 * Description of DBUtil
 * @refer https://codeshack.io/super-fast-php-mysql-database-class/
 * @author Aashish Raj
 * @email aashishraj97@gmail.com
 * @website http://tictik.org
 */
class MySQLiUtil {

    protected $connection;
    protected $query;
    protected $show_errors = TRUE;
    protected $query_closed = TRUE;
    public $query_count = 0;

    public function __construct() {
        
        $this->connection = new mysqli(DB::HOST, DB::USER, DB::PASS, DB::NAME);
        if ($this->connection->connect_error) {
            $this->_error('Failed to connect to MySQL - ' . $this->connection->connect_error);
        }
        $this->connection->set_charset(DB::CHAR);
    }

    public function _query($query) {
        if (!$this->query_closed) {
            $this->query->close();
        }
        if ($this->query = $this->connection->prepare($query)) {
            if (func_num_args() > 1) {
                $x = func_get_args();
                $args = array_slice($x, 1);
                $types = '';
                $args_ref = array();
                foreach ($args as $k => &$arg) {
                    if (is_array($args[$k])) {
                        foreach ($args[$k] as $j => &$a) {
                            $types .= $this->_gettype($args[$k][$j]);
                            $args_ref[] = &$a;
                        }
                    } else {
                        $types .= $this->_gettype($args[$k]);
                        $args_ref[] = &$arg;
                    }
                }
                array_unshift($args_ref, $types);
                call_user_func_array(array($this->query, 'bind_param'), $args_ref);
            }
            $this->query->execute();
            if ($this->query->errno) {
                $this->_error('Unable to process MySQL query (check your params) - ' . $this->query->error);
            }
            $this->query_closed = FALSE;
            $this->query_count++;
        } else {
            $this->_error('Unable to prepare MySQL statement (check your syntax) - ' . $this->connection->error);
        }
        return $this;
    }

    public function _fetch_all($callback = null) {
        $params = array();
        $row = array();
        $meta = $this->query->result_metadata();
        while ($field = $meta->fetch_field()) {
            $params[] = &$row[$field->name];
        }
        call_user_func_array(array($this->query, 'bind_result'), $params);
        $result = array();
        while ($this->query->fetch()) {
            $r = array();
            foreach ($row as $key => $val) {
                $r[$key] = $val;
            }
            if ($callback != null && is_callable($callback)) {
                $value = call_user_func($callback, $r);
                if ($value == 'break')
                    break;
            } else {
                $result[] = $r;
            }
        }
        $this->query->close();
        $this->query_closed = TRUE;
        return $result;
    }

    public function _fetch_array() {
        $params = array();
        $row = array();
        $meta = $this->query->result_metadata();
        while ($field = $meta->fetch_field()) {
            $params[] = &$row[$field->name];
        }
        call_user_func_array(array($this->query, 'bind_result'), $params);
        $result = array();
        while ($this->query->fetch()) {
            foreach ($row as $key => $val) {
                $result[$key] = $val;
            }
        }
        $this->query->close();
        $this->query_closed = TRUE;
        return $result;
    }

    public function _close() {
        return $this->connection->close();
    }

    public function _num_rows() {
        $this->query->store_result();
        return $this->query->num_rows;
    }

    public function _affected_rows() {
        return $this->query->affected_rows;
    }

    public function _insert_id() {
        return $this->connection->insert_id;
    }

    public function _error($error) {
        if ($this->show_errors) {
            exit($error);
        }
    }

    private function _gettype($var) {
        if (is_string($var))
            return 's';
        if (is_float($var))
            return 'd';
        if (is_int($var))
            return 'i';
        return 'b';
    }

}

/**
  
  $db = new db($dbhost, $dbuser, $dbpass, $dbname);

  Fetch a record from a database:
  $account = $db->_query('SELECT * FROM accounts WHERE username = ? AND password = ?', 'test', 'test')->_fetch_array();
  echo $account['name'];

  Or you could do:
  $account = $db->_query('SELECT * FROM accounts WHERE username = ? AND password = ?', array('test', 'test'))->_fetch_array();
  echo $account['name'];

  Fetch multiple records from a database:
  $accounts = $db->_query('SELECT * FROM accounts')->_fetch_all();
  foreach ($accounts as $account) {
    echo $account['name'] . '<br>';
  }

  You can specify a callback if you do not want the results being stored in an array (useful for large amounts of data):
  $db->_query('SELECT * FROM accounts')->_fetch_all(function($account) {
    echo $account['name'];
  });

  If you need to break the loop you can add:
  return 'break';

  Get the number of rows:
  $accounts = $db->_query('SELECT * FROM accounts');
  echo $accounts->_num_rows();

  Get the affected number of rows:
  $insert = $db->_query('INSERT INTO accounts (username,password,email,name) VALUES (?,?,?,?)', 'test', 'test', 'test@gmail.com', 'Test');
  echo $insert->_affected_rows();

  Get the total number of queries:
  echo $db->query_count;

  Get the last insert ID:
  echo $db->_insert_id();

  Close the database:
  $db->_close();
 */