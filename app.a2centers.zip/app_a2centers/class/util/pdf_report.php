<?php include $_SERVER['DOCUMENT_ROOT']."/includes/common.php";
error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);



$ReportObj = new Report();

 if(isset($_REQUEST['template_id']))
    {
        $templateid = $_REQUEST['template_id'];

    }
 $templateid=39;

$report_templates_info = $ReportObj->GetReportTemplateInfo($templateid);




if($report_templates_info[0]['for_time_period']!=" "){
     $time_filter_array= json_decode($report_templates_info[0]['for_time_period'], TRUE);
     
     if($time_filter_array['time_filter_cond']=='This_Month'){
   
         $timeFilterCond=  "YEAR(".$time_filter_array['time_filter_field'].") = YEAR(CURDATE()) AND "
                 . " MONTH(".$time_filter_array['time_filter_field'].") = MONTH(CURDATE())";
         
     }else if($time_filter_array['time_filter_cond']=='Last_Month'){
         
         $timeFilterCond= "YEAR(".$time_filter_array['time_filter_field'].") =YEAR( DATE_SUB(CURDATE(), INTERVAL 1 MONTH)) AND "
                 . "MONTH(".$time_filter_array['time_filter_field'].") =MONTH( DATE_SUB( CURDATE(), INTERVAL 1 MONTH ))";
     
     }else if($time_filter_array['time_filter_cond']=='Last_90_Days'){
         
          
         $timeFilterCond="DATE_SUB(CURDATE(),INTERVAL 90 DAY)<=".$time_filter_array['time_filter_field'];
         
     
     }else if($time_filter_array['time_filter_cond']=='Last_Year'){
        
         $timeFilterCond="YEAR(".$time_filter_array['time_filter_field'].") =YEAR( DATE_SUB(CURDATE(), INTERVAL 1 YEAR)) ";
     
     }else if($time_filter_array['time_filter_cond']=='This_Year'){
         
         $timeFilterCond= "YEAR(".$time_filter_array['time_filter_field'].") = YEAR(CURDATE())";
     
     }else if($time_filter_array['time_filter_cond']=='This_Week'){
        //" YEARWEEK(".$time_filter_array['time_filter_field'].", 1) = YEARWEEK(CURDATE(), 1)";
         
       //  $timeFilterCond= $time_filter_array['time_filter_field']." > DATE_SUB(NOW(), INTERVAL 1 WEEK)";
         
         $timeFilterCond= " YEARWEEK(".$time_filter_array['time_filter_field'].", 1) = YEARWEEK(CURDATE(), 1)";
     
     }else if($time_filter_array['time_filter_cond']=='Last_Week'){
         
         $timeFilterCond=" YEARWEEK(".$time_filter_array['time_filter_field'].") = YEARWEEK(DATE_SUB(CURDATE(), INTERVAL 1 WEEK))";
     
     }else if($time_filter_array['time_filter_cond']=='Between'){
         
         $timeFilterCond=$time_filter_array['time_filter_field'].">='".$time_filter_array['strt_date_val']."'  AND  ".$time_filter_array['time_filter_field']."<='".$time_filter_array['end_date_val']."'";
     
     }else if($time_filter_array['time_filter_cond']=='Today'){
         
         $timeFilterCond=" DATE(".$time_filter_array['time_filter_field'].")= CURDATE()";
     
     }
}



$fields= $report_templates_info[0]['template_field'];

$arr_data = json_decode($report_templates_info[0]['condition_as_json'], TRUE);
$can_access_cond="";
if($report_templates_info[0]['template_type']=='account' || $report_templates_info[0]['template_type']=='quotation')
{
    
    
    if( $_SESSION['GlobalPerm'] == 'no' && $_SESSION['GroupPerm'] == 'no')
    {
            //array_push($condition_list,"account.assigned='".$_SESSION['utopia']."'");
            $can_access_cond="account.assigned='".$_SESSION['utopia']."'";
    }
    else if($_SESSION['GlobalPerm'] == 'no' && $_SESSION['GroupPerm'] == 'yes')
    {
            $can_access_cond="account.assigned in ( select username from user where user.group_name IN ('".implode("','",$_SESSION['multiGroupAccess'])."'))";

    }
    
}else if($report_templates_info[0]['template_type']=='lead'){
    
    
    if( $_SESSION['GlobalPerm'] == 'no' && $_SESSION['GroupPerm'] == 'no')
    {
            //array_push($condition_list,"account.assigned='".$_SESSION['utopia']."'");
            $can_access_cond="lead.assigned='".$_SESSION['utopia']."'";
    }
    else if($_SESSION['GlobalPerm'] == 'no' && $_SESSION['GroupPerm'] == 'yes')
    {
        
            $can_access_cond="lead.assigned in ( select username from user where user.group_name IN ('".implode("','",$_SESSION['multiGroupAccess'])."'))";

    }
    
    
}else if($report_templates_info[0]['template_type']=='quotation'){
     
    
    
}

if( $can_access_cond=="")
{
    $filter="";
    $comma="";
}else if( $can_access_cond!="")
{
     $filter=$can_access_cond;
    $comma="  AND  ";
}


foreach ($arr_data as $key => $value) {

    $filter=$filter.$comma.$value['field_dbname']." ".$value['condition']." ".$value['value1'];

   $comma="  AND  ";

}


if( $timeFilterCond!=""){
    $filter=$filter."  AND  ".$timeFilterCond;
}



if($report_templates_info[0]['group_by']!="" && $report_templates_info[0]['order_by']!=""){

$query = " SELECT ".$fields." FROM ".$report_templates_info[0]['query_table']." WHERE ".$filter." GROUP BY ".$report_templates_info[0]['group_by']." ORDER BY ".$report_templates_info[0]['order_by'];


}else if($report_templates_info[0]['order_by']!=""  && $report_templates_info[0]['group_by']=="")
{

$query = " SELECT ".$fields." FROM ".$report_templates_info[0]['query_table']." WHERE ".$filter." ORDER BY ".$report_templates_info[0]['order_by'];


}else if($report_templates_info[0]['order_by']==""  && $report_templates_info[0]['group_by']!="")
{

    $query = " SELECT ".$fields." FROM ".$report_templates_info[0]['query_table']." WHERE ".$filter." GROUP BY ".$report_templates_info[0]['group_by'];

 }else if($report_templates_info[0]['order_by']==""  && $report_templates_info[0]['group_by']=="")
{

    $query = " SELECT ".$fields." FROM ".$report_templates_info[0]['query_table']." WHERE ".$filter;

 }


    $result = $ReportObj->FetchToArray($query);

/** Include Wrapper */
require_once dirname(__FILE__) . '/ExportExcel.php';
// Create new Wrapper Class object
$objWrapper = new ExportExcel();
$rendererName = PHPExcel_Settings::PDF_RENDERER_TCPDF;
$rendererLibrary = 'tcPDF';// 'tcPDF5.9';
$rendererLibraryPath = dirname(__FILE__).'/../Classes/PHPExcel/Writer/PDF/' . $rendererLibrary;

if (!PHPExcel_Settings::setPdfRenderer(
		$rendererName,
		$rendererLibraryPath
	)) {
	die(
		'Please set the $rendererName and $rendererLibraryPath values' .
		PHP_EOL .
		' as appropriate for your directory structure'
	);
}
// Generate Date
$generate_date = gmdate('D, d M Y  H:i:s',time()+19800);
// Setting the Page Properties
$properties  =[ 'creator'       =>$_SESSION['utopia'],
				'lastModifiedBy'=>$generate_date,
				'title'         =>'MAPLE CRM Repots',
				'subject'       =>$report_templates_info[0]['template_name'],
				'description'   =>$report_templates_info[0]['template_descr'],
				'keywords'      =>$report_templates_info[0]['template_name']];
// Sub Title
$sub_title  =[ 'Generation On : '.$generate_date." IST", 'Report Name    : '.$report_templates_info[0]['template_name'], 'Total Records   : '.count($result)];

// Column Data Section
$col_data=explode(",",$report_templates_info[0]['template_fieldnames']);

$objWrapper->DefaultPageSetting(array('grid_line' =>false, 'paper_size' =>'ledger','page_margin' =>array(0.5,0.5,0.5,0.5)))
            ->SetProperty($properties)
            ->SetActiveSheetIdx()

            ->SetFormatAttributes(array(     
                'text'      =>array('name'=>'Palatino Linotype','size'=>17,'bold'=>true,'color'=>'f4ad49'),
                'row_height'=>30))
            ->SetTitle(array('MAPLE CRM Reports'))

            ->SetFormatAttributes(array(   
                 'text'      =>array('size'=>12,'color'=>'000000'),
                 'row_height'=>16))
            ->SetSubTitle($sub_title)->IncrementRow(1)
           
            ->SetFormatAttributes(array(   
                'text'      =>array('name'=>'Arial','color'=>'3399CC'),
                'auto_col_width'=>false))
            ->TableHeader($col_data)

            ->SetFormatAttributes(array(   
                'text'      =>array('bold'=>false,'color'=>'000000'),
                'align'     =>'left',
                'auto_col_width' =>true))
            ->SetMultiRow($result);


$objWrapper->Save(ucfirst($report_templates_info[0]['template_name'])." - ".$generate_date,'pdf');

// properties
// 'text'      =>['name'=>'font name','size'=>font size,'bold'=>true/false,'italic'=>true/false,'underline'=>'none/double/doubleAccounting/single/singleAccounting','strike'=>true/false,'color'=>'hexa code']
//                                                                                                                                                                   strike is not implemented

// 'border'    =>['type'=>'outline/top/left/bottom/right /allborders/vertical/horizontal/diagonal/inside','style'=>'thin/medium/thick/dashed/dotted/double/dashdot','color'=>'hexa code']
//                 type not implemented => /allborders/vertical/horizontal/diagonal/inside

// 'cell'      =>['type'=>'none/solid/darkDown/darkGray/darkGrid/darkHorizontal/darkTrellis/darkUp/darkVertical/gray0625/gray125/lightDown/lightGray/lightGrid/lightHorizontal/lightTrellis/lightUp/lightVertical/mediumGray/linear/path', 'color'=>'hexa code']
//                 type not implemented  none=linear/path/

// 'align'     =>'left/right/center/justify/vjustify/vcenter/top/bottom/' 
// Save('file name', 'extension pdf/csv/xls/xlsx');
// 'size/height/width' =>digit
//'text_color_for_even_row'=>'000000',
//'cell_color_for_even_row'=>'DCDCDC'
// 'page_margin' =>array(top,right,bottom,left)
/*
page_size all in small letter
634_ENVELOPE
A2_PAPER
A3
A3_EXTRA_PAPER
A3_EXTRA_TRANSVERSE_PAPER
A3_TRANSVERSE_PAPER
A4
A4_EXTRA_PAPER
A4_PLUS_PAPER
A4_SMALL
A4_TRANSVERSE_PAPER
A5
A5_EXTRA_PAPER
A5_TRANSVERSE_PAPER
B4
B4_ENVELOPE
B5
B5_ENVELOPE
B6_ENVELOPE
C
C3_ENVELOPE
C4_ENVELOPE
C5_ENVELOPE
C6_ENVELOPE
C65_ENVELOPE
D
DL_ENVELOPE
E
EXECUTIVE
FOLIO
GERMAN_LEGAL_FANFOLD
GERMAN_STANDARD_FANFOLD
INVITE_ENVELOPE
ISO_B4
ISO_B5_EXTRA_PAPER
ITALY_ENVELOPE
JAPANESE_DOUBLE_POSTCARD
JIS_B5_TRANSVERSE_PAPER
LEDGER
LEGAL
LEGAL_EXTRA_PAPER
LETTER
LETTER_EXTRA_PAPER
LETTER_EXTRA_TRANSVERSE_PAPER
LETTER_PLUS_PAPER
LETTER_SMALL
LETTER_TRANSVERSE_PAPER
MONARCH_ENVELOPE
NO9_ENVELOPE
NO10_ENVELOPE
NO11_ENVELOPE
NO12_ENVELOPE
NO14_ENVELOPE
NOTE
QUARTO
STANDARD_1
STANDARD_2
STANDARD_PAPER_1
STANDARD_PAPER_2
STANDARD_PAPER_3
STATEMENT
SUPERA_SUPERA_A4_PAPER
SUPERB_SUPERB_A3_PAPER
TABLOID
TABLOID_EXTRA_PAPER
US_STANDARD_FANFOLD
?>
