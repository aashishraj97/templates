<?php
/**
 * Description of DBTable
 * all database tables name declaration
 * @author Aashish Raj
 * @email aashishraj97@gmail.com
 * @website http://tictik.org
 **/

class DBTable {
    /** SYSTEM TABLES **/
    const LOGS = 'app_logs';
    const USERS = 'app_users';
    const COUNTRY = 'app_country';
    const ORGANIZATION = 'app_organization';
    const LOGIN_RECORDS = 'app_login_records';
    const EMAIL_TEMPLATES = 'app_email_templates';
    
    /** APPLICATION TABLES **/
    const TBL_VENDORS   = 'tbl_vendors';
    const TBL_TICKETS   = 'tbl_tickets';
    const TBL_TICKETS_MAPPING = 'tbl_tickets_mapping';
    
}
