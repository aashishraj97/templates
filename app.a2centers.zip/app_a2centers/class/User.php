<?php include_once $_SERVER['DOCUMENT_ROOT'] . "/includes/common.php";
/**
 * Description of Database
 * in order to user tables use static DBTable::TABLE_NAME
 * @author Aashish Raj
 * @email aashishraj97@gmail.com
 * @website tictik.org
 */
class User extends DBUtil {
    private $db_fields = [];
    public $config;


    /* calling parent constructor to make database */
    public function __construct($username = null) {
        parent::__construct();
        $this->db_fields = $this->_get_db_fields(DBTable::USERS); 
        if(isset($this->db_fields['id'])){ unset($this->db_fields['id']); }
        
        if($username!=null) {
            $data['where'] = "username='". $this->_html_special_chars($username)."'";
            $this->config = $this->_select(DBTable::USERS,$data)->_fetch_object();
        }
    }
    
    public function _get($data = []) {
        $object = $this->_select(DBTable::USERS,$data);
        $response['num_rows'] = $object->_num_rows();
        $response['data'] = $object->_fetch_all();
        $response['object'] = $object;
        return $response;
    }
    
    public function _add($form_data = []) {
        $response['RESPONSE'] = '';
        if(count($form_data)>0){
            /*to convert original value into some encrypted format*/
            $form_data['password'] = sha1($form_data['password']);
            /*unset those fields which in not existing on table*/
            $insert_fields_values = [];
            foreach ($form_data as $key => $value) {
                if(in_array($key, $this->db_fields)){
                    $insert_fields_values[$key] = trim($value);
                }
            }
            
            /*add required fields which in existing on table*/
            $DateTimeUtilObj = new DateTimeUtil();
            $insert_fields_values['chng_pwd_date'] = $DateTimeUtilObj->_date('Y-m-d H:i:s');
            $insert_fields_values['expire_date'] = $DateTimeUtilObj->_date("Y-m-d H:i:s", strtotime("+3 month"));
            
            $fields = array_keys($insert_fields_values);
            $values = array_values($insert_fields_values);
            $response = $this->_insert(DBTable::USERS, $fields, $values);
            if($response['RESPONSE']=='SUCCESS') {
                $response['INSERT_ID'] = $this->_insert_id();
                $this->_add_info_log('User::_add() - Successfully Inserted... id ('.$this->_insert_id().')');
            }
        }
        return $response;
    }
    
    public function _edit($form_data = []) {
        $response['RESPONSE'] = '';
        if(count($form_data)>0){
            $id = isset($form_data['id'])?$form_data['id']:0;
            $where = "id=".$id;
            
             /*unset those fields which in not existing on insert table*/
            $update_fields = [];
            foreach ($form_data as $key => $value) {
                if(in_array($key, $this->db_fields)){
                    $update_fields[$key] = trim($value);
                }
            }
            
            $object = $this->_select(DBTable::USERS,['where'=>$where])->_fetch_object();
            if($object->role != $form_data['role']){
                $this->_add_admin_log('Assigned '. $form_data['role']. ' rights to '.$object->username.' by '.$_SESSION['USERNAME']);
            }
            
            
            $response = $this->_update(DBTable::USERS,$update_fields,$where);
            if($response['RESPONSE']=='SUCCESS') {
                $this->_add_info_log('User::_edit() - Successfully Updated... condition ('.$where.')');
                
                include_once $_SERVER['DOCUMENT_ROOT'] . '/class/util/DateTimeUtil.php';
                $DateTimeUtilObj = new DateTimeUtil();
                $expire_date = strtotime($DateTimeUtilObj->_date('Y-m-d', strtotime($object->expire_date)));
                $current_date= strtotime($DateTimeUtilObj->_date('Y-m-d'));

                if(($object->is_active == '0') && ($form_data['is_active'] == '1') && ($expire_date <= $current_date)){
                    include_once  $_SERVER['DOCUMENT_ROOT'].'/class/util/AppUtil.php';
                    $AppUtilObj = new AppUtil();
                    $new_password = $this->_generate_random_password();
                    $tdata = $this->_get_template('temporary-password');
                    $content = $tdata['data']['content'];
                    
                    /** here you can change the password */
                    $data['id'] = $id;
                    $data['check_login'] = '0';
                    $data['confirm_password'] = $new_password;
                    $this->_change_password($data);
                    /* REPLACE THE MICROS DEFINED IN TEMPLATE */
                    $app_url = APP::URL;
                    $app_logo_src = $app_url.APP::LOGO_SRC;
                    $search_array = ['::NAME::','::USERNAME::','::PASSWORD::','::APP_NAME::','::APP_URL::','::APP_LOGO_SRC::'];
                    $replace_array= [$form_data['name'], $object->username,$new_password, APP::NAME,    $app_url,   $app_logo_src];
                    $final_message = $AppUtilObj->_str_replace($search_array, $replace_array, $content);

                    $params = [ 'to'=>[$object->email=>$object->name],
                                'subject'=>'Temporary Password for your '.APP::NAME.' account.',
                                'message'=>$final_message];

                    include_once  $_SERVER['DOCUMENT_ROOT'].'/class/util/MailUtil.php';   
                    $MailUtilObj = new MailUtil();
                    $res = $MailUtilObj->_send_mail($params);
                }
            }
        }
        
        return $response;
    }
    
    public function _remove($id = null) {  
        $response['RESPONSE'] = '';
        if(!empty($id)){
            $where = "id=" . $id; 
            $response = $this->_delete(DBTable::USERS,$where);
            if($response['RESPONSE']=='SUCCESS') {
                $this->_add_info_log('User::_remove() - Successfully Deleted... condition ('.$where.')');
            }
        }
        return $response;
    }
    
    public function _is_exist($form_data = []) {
        $response['RESPONSE'] = '';
        if(count($form_data)>0) {
            $where = $form_data['field'] . "='" . trim($form_data['value']) . "'" ;
            $data['fields'] = ['id'];
            $data['where'] = $where;
            if($this->_select(DBTable::USERS, $data)->_num_rows()>0) {
                $response['RESPONSE'] = 'SUCCESS';
                $this->_add_info_log('User::_is_exist() - value already exist!.. condition ('.$where.')');
            }
        }
        return $response;
    }
    
    public function _is_valid_user() {
        if(isset($this->config)){
            return true;
        }
        return false;
    }
    
    /**
     * to check whether the password is correct or not
     * @param type $password
     * @return boolean
     */
    public function _is_valid_password($password = null) {
        if(isset($this->config) && ($this->config->password == $this->_html_special_chars((sha1($password))))){
            return true;
        }
        return false;
    }
    /**
     * 
     * @return type string
     */
    function _generate_random_password() {
        $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
        $pass = array(); //remember to declare $pass as an array
        $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
        for ($i = 0; $i < 8; $i++) {
            $n = rand(0, $alphaLength);
            $pass[] = $alphabet[$n];
        }
        return implode($pass); //turn the array into a string
    }
    
    /**
     * get the user config and set in session
     * @return boolean/object
     */
    public function _set_session() {
        if(isset($this->config)){
            $_SESSION['ID'] = $this->config->id;
            $_SESSION['ROLE'] = $this->config->role;
            $_SESSION['NAME'] = $this->config->name;
            $_SESSION['USERNAME'] = $this->config->username;
            //$_SESSION['USERTYPE'] = $this->config->type;
            $_SESSION['VENDORNAME'] = $this->config->vendorname;
            $_SESSION['CHECKLOGIN']= $this->config->check_login;
            
        }
        return false;
    }
    
    public function _change_password($data = []) {
        
        //$password = sha1($data['new_password']);
        $confirm_password = sha1($data['confirm_password']);
        include_once  $_SERVER['DOCUMENT_ROOT'].'/class/util/DateTimeUtil.php';
                    
        $DateTimeUtilObj = new DateTimeUtil();
	$date = $DateTimeUtilObj->_date('Y-m-d H:i:s');
        $expiry_date = $DateTimeUtilObj->_date("Y-m-d H:i:s", strtotime("+3 month"));
        
        $id = isset($data['id'])?$data['id']:$_SESSION['ID'];
        $check_login = isset($data['check_login'])?$data['check_login']:1;
        $where = 'id='.$id;
        $fields = [ 'password'=>$confirm_password,
                    'check_login'=>$check_login,
                    'chng_pwd_date'=>$date,
                    'expire_date'=>$expiry_date];
        
        $response = $this->_update(DBTable::USERS,$fields,$where);
        if($response['RESPONSE']=='SUCCESS') {
            $_SESSION['CHECKLOGIN'] = 1;
            $this->_add_info_log('Report::_change_password() - Successfully Updated... condition ('.$where.')');
        }
        return $response;
    }
    
    /**
     * 
     * @param type $name string
     * @return type associative array
     */
    public function _get_template($name = null) {
        if(empty($name)) {
            $object = $this->_select(DBTable::EMAIL_TEMPLATES);
            $response['data'] = $this->_fetch_all();
        }
        else {
            $data['where'] = "type='" . $name ."'";
            $object = $this->_select(DBTable::EMAIL_TEMPLATES,$data);
            $response['data'] = $this->_fetch_array();
        }
        //$content = file_get_contents(APP::URL.'/pages/templates/temporary-password.php');
        $response['num_rows'] = $this->_num_rows();
        $response['object'] = $object;
        return $response;
    }
    /**
     * 
     * @param type $name string
     * @return type associative array
     */
    public function _get_login_history($user='') {
        //$query = "SELECT u.name, lr.by_user, login_at, logout_at, timezone_code FROM  ".DBTable::LOGIN_RECORDS." lr LEFT JOIN ".DBTable::USERS." u ON (u.username = lr.by_user) ORDER BY login_at desc LIMIT 0,10";
        $where = '';
        if($user!=''){
            $where = " WHERE by_user='".$user."' ";
        }
        $query = "SELECT by_user, login_at, logout_at, timezone_code FROM  ".DBTable::LOGIN_RECORDS." ".$where." ORDER BY login_at desc LIMIT 0,10";
        $object = $this->_run_query($query);
        $response['data'] = $this->_fetch_all();
        $response['num_rows'] = $this->_num_rows();
        $response['object'] = $object;
        return $response;
    }
    
    public function _add_login_record() {
        $response['RESPONSE'] = '';
        $form_data = [];
        
        $form_data['by_user'] = isset($_SESSION['USERNAME'])?$_SESSION['USERNAME']:'';
        $form_data['session_id'] = session_id();
        include_once $_SERVER['DOCUMENT_ROOT'] . '/class/util/DateTimeUtil.php';
        $DateTimeUtilObj = new DateTimeUtil();
        $form_data['login_at'] = $DateTimeUtilObj->_offset_date('Y-m-d H:i:s',$_SESSION['OFFSET']);
        $offset = $DateTimeUtilObj->_get_timezone_info_by_offset($_SESSION['OFFSET']);
        $form_data['timezone_code'] = isset($offset['code'])?$offset['code']:'';

        $fields = array_keys($form_data);
        $values = array_values($form_data);
        
        $response = $this->_insert(DBTable::LOGIN_RECORDS, $fields, $values);
        if($response['RESPONSE']=='SUCCESS') {
            $response['INSERT_ID'] = $this->_insert_id();
            $this->_add_info_log('User::_add_login_record() - Successfully Inserted... id ('.$this->_insert_id().')');
        }
        
        $this->_add_login_log('Logged In.');
        return $response;
    }
    
    public function _add_logout_record() {
        $response['RESPONSE'] = '';
        $where = "session_id='".session_id()."'";
        $DateTimeUtilObj = new DateTimeUtil();        
        $form_data['logout_at'] = $DateTimeUtilObj->_offset_date('Y-m-d H:i:s',$_SESSION['OFFSET']);
        $form_data['timezone_code'] = $DateTimeUtilObj->_get_timezone_info_by_offset($_SESSION['OFFSET'])['code'];
        
        $response = $this->_update(DBTable::LOGIN_RECORDS,$form_data,$where);
        if($response['RESPONSE']=='SUCCESS') {
            $this->_add_info_log('User::_edit() - Successfully Updated... condition ('.$where.')');
        }
        
        $this->_add_login_log('Logged out.');
        
        return $response;
    }
    
    public function _update_on_login(string $username = null) {
        $response['RESPONSE'] = '';
        if(!empty($username)){
            include_once $_SERVER['DOCUMENT_ROOT'] . '/class/util/DateTimeUtil.php';
            $DateTimeUtilObj = new DateTimeUtil();
            $fields['last_modified'] = $DateTimeUtilObj->_date('Y-m-d H:i:s');
            $where = "username='".$username."'";
            
            $response = $this->_update(DBTable::USERS,$fields,$where);
            if($response['RESPONSE']=='SUCCESS') {
                $this->_add_info_log('User::_update_on_login() - Successfully Updated... condition ('.$where.')');
            }
        }
        return $response;
    }
}

                     
//$obj = new User('user');
//echo $obj->_is_valid_password('Admin@123');
//var_dump($obj->_get_config());