<?php include_once $_SERVER['DOCUMENT_ROOT'] . "/includes/common.php";
/**
 * Description of Clients
 * in order to user tables use static DBTable::TABLE_NAME
 * @author Aashish Raj
 * @email aashishraj97@gmail.com
 * @website tictik.org
 */
class Ticket extends DBUtil {
    /* private variable declaration, to use with-in this class only */
    private $db_fields = [];
    
    /* calling parent constructor to make database */
    public function __construct() {
        parent::__construct();
        $this->db_fields = $this->_get_db_fields(DBTable::TBL_TICKETS); 
        if(isset($this->db_fields['id'])){ unset($this->db_fields['id']); }
    }
    
    /**
     * 
     * @param type $where string
     * @return type associative array
     */
    public function _get($data = []) {
        $object = $this->_select(DBTable::TBL_TICKETS,$data);
        $response['num_rows'] = $object->_num_rows();
        $response['data'] = $object->_fetch_all();
        $response['object'] = $object;
        return $response;
    }
    
    /**
     * 
     * @param type $where string
     * @return type integer
     */
    public function _get_count($where = null) {
        $data['fields'] = ['count(id) as count'];
        $data['where'] = $where;
        $object = $this->_select(DBTable::TBL_TICKETS,$data)->_fetch_object();
        return $object->count;
    }
    
    public function _add($form_data = []) {
        $response['RESPONSE'] = '';
        if(count($form_data)>0){
            
            /*unset those fields which in not existing on table*/
            $insert_fields_values = [];
            foreach ($form_data as $key => $value) {
                if(in_array($key, $this->db_fields)){
                    $insert_fields_values[$key] = trim($value);
                }
            }
            
            /*add required fields which in existing on table*/
            $DateTimeUtilObj = new DateTimeUtil();
            $insert_fields_values['created_at'] = $DateTimeUtilObj->_date('Y-m-d H:i:s');
            
            $fields = array_keys($insert_fields_values);
            $values = array_values($insert_fields_values);
            $response = $this->_insert(DBTable::TBL_TICKETS, $fields, $values);
            if($response['RESPONSE']=='SUCCESS') {
                $response['INSERT_ID'] = $this->_insert_id();
                $this->_add_info_log('Ticket::_add() - Successfully Inserted... id ('.$this->_insert_id().')');
            }
        }
        return $response;
    }
    
    public function _edit($form_data = []) {
        $response['RESPONSE'] = '';
        if(count($form_data)>0){
            $id = isset($form_data['id'])?$form_data['id']:0;
            $where = "id=".$id;
            
             /*unset those fields which in not existing on insert table*/
            $update_fields = [];
            foreach ($form_data as $key => $value) {
                if(in_array($key, $this->db_fields)){
                    $update_fields[$key] = trim($value);
                }
            }
            
            $DateTimeUtilObj = new DateTimeUtil();
            $offset = $DateTimeUtilObj->_get_timezone_info_by_offset($_SESSION['OFFSET']);
            $update_fields['timezone_code'] = isset($offset['code'])?$offset['code']:'';
            
            $response = $this->_update(DBTable::TBL_TICKETS,$update_fields,$where);
            if($response['RESPONSE']=='SUCCESS') {
                $response['TIMEZONECODE'] = $update_fields['timezone_code'];
                $this->_add_info_log('Ticket::_edit() - Successfully Updated... condition ('.$where.')'.json_encode($form_data));
            }
        }
        return $response;
    }
    
    public function _remove($id = null) {  
        $response['RESPONSE'] = '';
        if(!empty($id)){
            $where = "id=" . $id; 
            $response = $this->_delete(DBTable::TBL_TICKETS,$where);
            if($response['RESPONSE']=='SUCCESS') {
                $mwhere = "ticket_id=" . $id; 
                $this->_delete(DBTable::TBL_TICKETS_MAPPING,$mwhere);
                $this->_add_info_log('Ticket::_remove() - Successfully Deleted... condition ('.$where.')');
            }
        }
        return $response;
    }
    
    public function _is_exist($form_data = []) {
        $response['RESPONSE'] = '';
        if(count($form_data)>0) {
            $where = $form_data['field'] . "='" . trim($form_data['value']) . "'" ;
            $data['fields'] = ['id'];
            $data['where'] = $where;
            if($this->_select(DBTable::TBL_TICKETS, $data)->_num_rows()>0) {
                $response['RESPONSE'] = 'SUCCESS';
                $this->_add_info_log('Ticket::_is_exist() - value already exist!.. condition ('.$where.')');
            }
        }
        return $response;
    }
    
    public function _mapping_entry($data = []) {
        $DateTimeUtilObj = new DateTimeUtil();
        $offset = $DateTimeUtilObj->_get_timezone_info_by_offset($_SESSION['OFFSET']);
        $name = isset($offset['name'])?$offset['name']:'';
        $code = isset($offset['code'])?$offset['code']:'';
        $by_user = isset($_SESSION['USER_USERNAME'])?$_SESSION['USER_USERNAME']:$_SESSION['USERNAME'];
        $fields = ['ticket_id','checkin','timezone','timezone_code','comment','by_user'];
        $values = [$data['id'],$data['checkin'],$name,$code,$data['comment'],$by_user];
        if(!empty($data['checkout'])){
            array_push($fields,'checkout');
            array_push($values,$data['checkout']);
        }
        
        $response = $this->_insert(DBTable::TBL_TICKETS_MAPPING, $fields, $values);
        if($response['RESPONSE']=='SUCCESS') {
            $this->_add_info_log('Report::_mapping_entry() - Successfully Inserted...');
        }
        return $response;
    }
}
//$TicketObj = new Client();
//var_dump($TicketObj->_get_count('closed="No"'));