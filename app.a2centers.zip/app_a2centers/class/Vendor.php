<?php include_once $_SERVER['DOCUMENT_ROOT'] . "/includes/common.php";
/**
 * Description of Database
 * in order to user tables use static DBTable::TABLE_NAME
 * @author Aashish Raj
 * @email aashishraj97@gmail.com
 * @website tictik.org
 */
class Vendor extends DBUtil {
    private $fields = ['id','email','vendorname'];
    public $config;


    /* calling parent constructor to make database */
    public function __construct($vendorname = null) {
        parent::__construct();
        
        if($vendorname!=null) {
            $data['where'] = "vendorname='". $this->_html_special_chars($vendorname)."'";
            $this->config = $this->_select(DBTable::TBL_VENDORS,$data)->_fetch_object();
        }
    }
    
    public function _get($data = []) {
        $object = $this->_select(DBTable::TBL_VENDORS,$data);
        $response['num_rows'] = $object->_num_rows();
        $response['data'] = $object->_fetch_all();
        $response['object'] = $object;
        return $response;
    }
    
    public function _add($form_data = []) {
        $response['RESPONSE'] = '';
        if(count($form_data)>0){
            if(isset($form_data['action'])){ unset($form_data['action']); }
                        
            $fields = array_keys($form_data);
            $values = array_values($form_data);
            $response = $this->_insert(DBTable::TBL_VENDORS, $fields, $values);
            if($response['RESPONSE']=='SUCCESS') {
                $response['INSERT_ID'] = $this->_insert_id();
                $this->_add_info_log('Vendor::_add() - Successfully Inserted... id ('.$this->_insert_id().')');
            }
        }
        return $response;
    }
    
    public function _edit($form_data = []) {
        $response['RESPONSE'] = '';
        if(count($form_data)>0){
            $id = isset($form_data['id'])?$form_data['id']:0;
            $where = "id=".$id;
            if(isset($form_data['action'])){ unset($form_data['action']); }
            if(isset($form_data['id'])){ unset($form_data['id']); }
            
            $response = $this->_update(DBTable::TBL_VENDORS,$form_data,$where);
            if($response['RESPONSE']=='SUCCESS') {
                $this->_add_info_log('Vendor::_edit() - Successfully Updated... condition ('.$where.')');
            }
        }
        return $response;
    }
    
    public function _remove($id = null) {  
        if(!empty($id)){
            $where = "id=" . $id; 
            $response = $this->_delete(DBTable::TBL_VENDORS,$where);
            if($response['RESPONSE']=='SUCCESS') {
                $this->_add_info_log('Vendor::_remove() - Successfully Deleted... condition ('.$where.')');
            }
        }
        
        return $response;
    }
    
    public function _is_exist($form_data = []) {
        $response['RESPONSE'] = '';
        if(count($form_data)>0) {
            $where = $form_data['field'] . "='" . trim($form_data['value']) . "'" ;
            $data['fields'] = ['id'];
            $data['where'] = $where;
            if($this->_select(DBTable::TBL_VENDORS, $data)->_num_rows()>0) {
                $response['RESPONSE'] = 'SUCCESS';
                $this->_add_info_log('Vendor::_is_exist() - value already exist!.. condition ('.$where.')');
            }
        }
        return $response;
    }
}

                     
//$obj = new Vendor('user');
//echo $obj->_is_valid_password('Admin@123');
//var_dump($obj->_get_config());