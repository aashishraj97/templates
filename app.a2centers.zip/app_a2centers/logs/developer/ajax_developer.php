<?php
include $_SERVER['DOCUMENT_ROOT']."/includes/common.php"; 
$DBUtilObj = new Maple_DBUtil();

if(isset($_POST['developer_qry']) && $_POST['developer_qry'] != '') 
{
	$query_type ="";
	if(isset($_POST['query_type'])) { $query_type = $_POST['query_type']; }
	$developer_qry =$_POST['developer_qry'];//$DBUtilObj->escape(trim($_POST['developer_qry']));

	if($query_type=="Other") {
		$qryresp=$DBUtilObj->query($developer_qry);

		if($DBUtilObj->last_error) { }
		else { echo "SUCCESS:"; }

	}	//query type other end
	else {
		$ResultList = $DBUtilObj->FetchToArray($developer_qry);
		if($DBUtilObj->last_error) { }
		else {
			if(count($ResultList)>0) {
				echo "SUCCESS:";
				echo '<TABLE id="result_table"  name="result_table" border="1" width="100%">
				   <TR style="background-color:#2C7DC0;color:white;height:25px;">';
					$HeaderList = array_keys((array) $ResultList[0]); // GET FIELD NAMES
					foreach($HeaderList as $HeaderName) {
						echo '<TH >'.$HeaderName.'</TH>';
					}
				echo '</TR>';
				foreach($ResultList as $Result) {
					echo '<TR>';

					foreach($HeaderList as $HeaderName) {
						echo '<TD>'.$Result[$HeaderName].'</TD>';
					}

					echo '</TR>';
					//$resArray1 = array_keys($Result);
				}
				echo '</TABLE>';
			} //ResultList count >0
			else {
				echo "SUCCESS:";
				echo '<span class="error" style="padding-left:290px;">Your Select Query has fetched 0 results  </span>';
			}
		} // NO ERROR
	}  // select query execution
}
?>