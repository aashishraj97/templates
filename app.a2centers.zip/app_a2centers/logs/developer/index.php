<?php include $_SERVER['DOCUMENT_ROOT'] . "/includes/common.php"; ?>
<!DOCTYPE html>
<html lang="en">
    <head>

        <title><?= APP::TITLE ?></title>
        <!-- start: Meta -->
        <meta charset="utf-8">
        <meta name="description" content="Developer Screen">
        <meta name="viewport" content="width=device-width, initial-scale=1"> 
        <!-- end: Meta -->
        <style>
            .error {color:red;}

            table#result_table {
                border: 1px solid #DDDDDD;
                border-collapse: collapse;
            }

            table#result_table th, td {
                padding-left: 5px;
                text-align: left;
            }

            table#result_table tr:nth-child(even) {
                background-color: #eee;
            }
            table#result_table tr:nth-child(odd) {
                background-color:#fff;
            }
        </style>	
        <script src="http://code.jquery.com/jquery-2.1.1.min.js"></script>
        <script>
            window.jQuery || document.write('<script src="/js/libs/jquery-2.1.1.min.js">\x3C/script>')
        </script>
        <script>
            function ValidateDeveloperForm() {
                $(".error").hide();
                $('#developer_post_error_msg').html('');
                $('#developer_postresponse_success_msg').html('');
                $('#query_result').html('');


                var valid = true;
                var dev_qry = $.trim($("#developer_qry").val());
                if (dev_qry == '') {
                    $("#developer_qry").after('<span class="error"><BR>Query is mandatory</span>');
                    valid = false;
                }

                if (dev_qry != '') {
                    var qry_type = $("#query_type").val();
                    var qry = dev_qry.toUpperCase();

                    if (qry_type == 'Select') {
                        if (qry.indexOf("SELECT") == 0) {
                            if (dev_qry.indexOf("*") > -1) {
                                $("#developer_qry").after('<span class="error"><BR>Select should use explicit Field Names</span>');
                                valid = false;
                            }
                        } else {
                            $("#query_type").after('<span class="error"><BR>Choose Other option from Query Type</span>');
                            valid = false;
                        }
                    } else if (qry_type == 'Other') {
                        if (qry.indexOf("SELECT") == 0) {
                            $("#query_type").after('<span class="error"><BR>Choose Select option from Query Type </span>');
                            valid = false;
                        }
                    }
                }

                if (valid) {
                    ExecuteDeveloperQuery();
                    return false;
                }

                return valid;
            }


            function ExecuteDeveloperQuery() {
                $("#execute_developer_action").attr("disabled", true);
                var formdata = $('#developer_form').serialize();

                $.ajax({
                    type: "POST",
                    url: "ajax_developer.php",
                    data: formdata
                }).done(function (msg) {

                    if (msg.indexOf("SUCCESS:") > -1) {
                        var qry_type = $("#query_type").val();

                        if (qry_type == 'Select') {
                            var result_msg = msg.split('SUCCESS:');
                            $('#query_result').html(result_msg);
                        } else {
                            msg = "Query is executed successfully";
                            $('#developer_postresponse_success_msg').html(msg);

                            $("#developer_form")[0].reset();
                        }
                        $("#execute_developer_action").attr("disabled", false);
                    } else {
                        message = '<span><BR><B>ERROR:</B></span>' + msg;
                        $('#developer_post_error_msg').html(message);
                        $("#execute_developer_action").attr("disabled", false);
                    }
                });

            }
        </script>

    </head>
    <body>
        <div align="center">

            <div align="left"> <BR><BR><!-- page-header -->
                <span style="padding-left:300px;color:#2C7DC0; FONT-SIZE: 22px;">Developer Screen</span>
            </div><!-- /.page-header -->


            <form  method="post" name="developer_form" id="developer_form">

                <div align="left"> 
                    <div id="developer_post_error_msg" style="padding-left:300px;color:red;"></div><BR>	
                    <div id="developer_postresponse_success_msg" style="padding-left:300px;color:green;" name="developer_postresponse_success_msg"></div>
                </div>

                <table width="80%" border=0>
                    <tr>
                        <td width="10%">
                            <label  >Query: </label>
                        </td>
                        <td width="90%">
                            <textarea  id="developer_qry" name="developer_qry"  rows="8"  cols="100"></textarea><BR>
                        </td>
                    </tr>

                    <tr >
                        <td width="10%"><BR>
                            <label  >Query Type: </label>
                        </td>
                        <td width="90%"><BR>
                            <select name="query_type" id="query_type">
                                <option value="Other">Other</option>
                                <option value="Select">Select</option>
                            </select>					
                        </td>
                    </tr>

                    <tr><td colspan="2"><BR></td></tr>

                    <tr>
                        <td></td>
                        <td >
                            <input type="submit" id="execute_developer_action"  name="execute_developer_action"  onclick="javascript: return ValidateDeveloperForm()" value="Execute"    />
                        </td>
                    </tr>
                </table>

                <table width="95%" border=0> 
                    <tr>
                        <td><!-- SELECT QUERY RESULT LIST -->
                            <div id="query_result" name="query_result"></div>
                        </td>
                    </tr>
                </table>

            </form>
        </div>
    </body>
</html>