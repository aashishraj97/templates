<?php include_once $_SERVER['DOCUMENT_ROOT'] . "/includes/common.php"; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title><?= APP::TITLE ?> : Logs</title>
        <link href="/css/bootstrap.css" rel="stylesheet" />
        <link href="./../css/plugins.css" rel="stylesheet" />
        <link href="/css/main.css" rel="stylesheet" />
        <link href="/css/custom.css" rel="stylesheet" />
        <script src="http://code.jquery.com/jquery-2.1.1.min.js"></script>
        <script>
            window.jQuery || document.write('<script src="/js/libs/jquery-2.1.1.min.js">\x3C/script>')
        </script>
        <script src="http://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
        <script>
            window.jQuery || document.write('<script src="/js/libs/jquery-ui-1.10.4.min.js">\x3C/script>')
        </script>
        <script src="/plugins/forms/bootstrap-datepicker/bootstrap-datepicker.js"></script>

        <style> @media(max-width: 600px) {.form-control { width:50% !important;}} .error {color:red;} </style>
        
    </head>

    <body>
        <div class="container">
            <form id="filter-log-form" action="#">
                <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                    <input type="hidden"  name="type" id="type" value="<?php echo $type; ?>"/>
                        Log Type: 
                        <select class="form-control input-medium" name="log-type" id="log-type">
                            <option value="">All Logs</option>
                            <option value="error">Error</option>
                            <option value="info">Info</option>
                            <option value="debug">Debug</option>
                            <option value="alert">Alert</option>
                            <option value="login">Login</option>
                        </select>
                </div>
                <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                    From Date: 
                    <input class="form-control input-medium datepicker" type="text" name="from_date" id="from-date" placeholder="dd-mm-yyyy"/>
                </div>
                <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                    To Date: 
                    <input class="form-control input-medium datepicker" type="text" name="to_date" id="to-date" placeholder="dd-mm-yyyy"/>
                </div>
                <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                    Search Text: 
                    <input class="form-control input-medium" type="text" name="search" id="search" placeholder="Search Text" />
                </div>
                <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                    Limit: 
                    <input class="form-control input-medium" type="text" name="row_limit" id="row-limit" placeholder="No of rows"/>
                </div>
                <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6"><br/>	
                    <input type="button" id="log-filter-btn" class="btn btn-success" value="Search"/>
                </div>								
            </form><br/>
            <div id="log-listing-div"></div>
        </div>
        <script src="./../plugins/tables/datatables/datatables.min.js"></script>
        <script src="./../scripts/log-viewer.js" type="text/javascript"></script>
        <script>
            $(".datepicker").datepicker({format: 'dd-mm-yyyy', endDate: 'today'});
            $('.datepicker').bind('.datepicker', function () {
                var c = this.selectionStart,
                        r = /[^]/,
                        v = $(this).val();
                if (r.test(v)) {
                    $(this).val(v.replace(r, ''));
                    c--;
                }
                this.setSelectionRange(c, c);
            });
        </script>
    </body>
</html>