

document.write('<table cellpadding="2" cellspacing="0" border="0" style="border: #996600 1px solid; background-color: #F0F0F0;COLOR: #996600; FONT: 13px arial, sans-serif; font-weight: bold;"><tr><td align="center">');
document.write('JS Sample<br>');
document.write('</td></tr><tr><td>');
document.write('<iframe id="NewsWindow" src="news_win.htm" marginwidth="0" marginheight="0" frameborder="0" scrolling="no"></iframe>');
document.write('</td></tr></table>');
document.write('<br><br>');











document.write('<div id="IframeScroller" style="position:absolute; visibility:show; right: 100px; top: 100px; z-index:3">');
document.write('<table cellpadding="2" cellspacing="0" border="0" style="border: #000000 1px solid; background-color: #996666;COLOR: #FFFFFF; FONT: 13px arial, sans-serif; font-weight: bold;"><tr><td align="center">');
document.write('Floating JS Sample<br>');
document.write('</td></tr><tr><td>');
document.write('<iframe id="NewsWindow" src="news_win.htm" marginwidth="0" marginheight="0" frameborder="0" scrolling="no" style="border: #000000 1px solid;" width="150"></iframe><br>');
document.write('</td></tr></table>');
document.write('</DIV>');














// -- END FILE -->