

var progressbar_steps = 50;	
	
	
	var dhtmlgoodies_progressPane = false;
	var dhtmlgoodies_progressBar_bg = false;
	var dhtmlgoodies_progressBar_outer = false;
	var dhtmlgoodies_progressBar_txt = false;
	var progressbarWidth;
	var currentStep = 0;
	function moveProgressBar(steps){
		if(!dhtmlgoodies_progressBar_bg){
			dhtmlgoodies_progressPane = document.getElementById('dhtmlgoodies_progressPane');
			dhtmlgoodies_progressBar_bg = document.getElementById('dhtmlgoodies_progressBar_bg');
			dhtmlgoodies_progressBar_outer = document.getElementById('dhtmlgoodies_progressBar_outer');
			dhtmlgoodies_progressBar_txt = document.getElementById('dhtmlgoodies_progressBar_txt');
			progressbarWidth = dhtmlgoodies_progressBar_bg.clientWidth;
		}
		if(!steps){
			dhtmlgoodies_progressBar_outer.style.width = progressbarWidth + 'px';
			dhtmlgoodies_progressBar_txt.innerHTML = '100%';
			setTimeout('document.getElementById("dhtmlgoodies_progressPane").style.display="none"',50);
		}else{
			currentStep+=steps;
			if(currentStep>progressbar_steps)currentStep = progressbar_steps;
			var width = Math.ceil(progressbarWidth * (currentStep / progressbar_steps));
			dhtmlgoodies_progressBar_outer.style.width = width + 'px';
			var percent = Math.ceil((currentStep / progressbar_steps)*100);
			dhtmlgoodies_progressBar_txt.innerHTML = percent + '%';
			if(currentStep==progressbar_steps){
				setTimeout('document.getElementById("dhtmlgoodies_progressPane").style.display="none"',50);
			}
		}
		
	}
	
	
	function demoProgressBar()
	{
		if(currentStep<progressbar_steps){
			moveProgressBar(1);
			setTimeout('demoProgressBar()',50);
		}
	}
