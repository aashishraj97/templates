<?php include_once $_SERVER['DOCUMENT_ROOT']."/includes/session-start.php";
/**
*@author  Aashish Raj
*@email   aashishraj97@gmail.com
*@website http://tictik.org
 */ 
if(isset($_SESSION['USERNAME']) && $_SESSION['USERNAME'] != '')
{
    include_once $_SERVER['DOCUMENT_ROOT']."/includes/config.php";
    function _autoload_util_class($class_name) 
    {
        if(file_exists($_SERVER['DOCUMENT_ROOT']."/class/util/".$class_name.'.php')) 
        { 
            include_once $_SERVER['DOCUMENT_ROOT']."/class/util/".$class_name.'.php';
        }
        else {
            //echo "Unable to load Class /class/util/".$class_name."<br>";
        } 
    }
    
    function _autoload_class($class_name) 
    {
        if(file_exists($_SERVER['DOCUMENT_ROOT']."/class/".$class_name.'.php')) 
        { 
            include_once $_SERVER['DOCUMENT_ROOT']."/class/".$class_name.'.php';
        }
        else {
            //echo "Unable to load Class /class/".$class_name."<br>";
        } 
    }
    spl_autoload_register('_autoload_util_class');
    spl_autoload_register('_autoload_class');
}
else 
{
//    echo '<script>
//            windows.location.target = "_blank";
//            windows.location.href = "login-expire.php";
//        </script>';
//    header("Location: /login-expire.php",true); /* Redirect browser */
//    exit;	/* Make sure that code below does not get executed when we redirect. */    
}

/*
 * spl_autoload_register allows several autoloaders to be registered which will be run through in turn until a matching class/interface/trait is found and loaded, or until all autoloading options have been exhausted. This means that if you're using framework code or other third party libraries that implement their own autoloaders you don't have to worry about yours causing conflicts.
UPDATE:
__autoload is now officially deprecated as of PHP 7.2.0, which means it's now on the chopping block. If you want your code to be compatible with future versions of PHP you definitely should not use __autoload
*/
?>