<?php $AppUtilObj = new AppUtil(); ?> 
<div id="sidebar" class="page-sidebar hidden-lg hidden-md hidden-sm hidden-xs">
    <div class="shortcuts mt5">
        <ul>
            <!--Sidebar collapse button-->
            <li><a href="javascript:_content_loader('dashboard');" title="Home" class="tip"><i class="s24 icomoon-icon-home"></i></a>
            </li>
            <li><a href="javascript:_admin_content_loader('total-ticket');" menu-id="total-ticket" title="Total Tickets" class="tip"><i class="s24 icomoon-icon-tag"></i></a>
            </li>
            <li><a href="javascript:_admin_content_loader('report');" menu-id="report" title="Report" class="tip"><i class="s24 icomoon-icon-pie-2"></i></a>
            </li>
        </ul>
    </div>
    <!-- End search -->
    <!-- Start .sidebar-inner -->
    <div class="sidebar-inner">
        <!-- Start .sidebar-scrollarea -->
        <div class="sidebar-scrollarea">
            <div class="sidenav">
                <!-- End .sidenav-widget -->
                <div class="mainnav">
                    <ul>
                        
                        <li>
                            <a onclick="javascript:_admin_content_loader('vendor');" menu-id="vendor"  role="button"><i class="s16 icomoon-icon-user-2 m0 pr5"></i><span class="txt">Vendor</span> </a>
<!--                            <ul class="sub hide">
                                <?php if($AppUtilObj->_feature_enabled('VENDOR')): ?>
                                <li>
                                    <a href="javascript:_admin_content_loader('add-edit-vendor');" menu-id="add-edit-vendor"><i class="s16 icomoon-icon-arrow-right-3 m0 pr5"></i><span class="txt">Add New</span></a>
                                </li>
                                <li>
                                    <a href="javascript:_admin_content_loader('vendor');" menu-id="vendor"><i class="s16 icomoon-icon-arrow-right-3 m0 pr5"></i><span class="txt">View</span></a>
                                </li>
                                <?php endif; ?>
                            </ul>-->
                        </li>
                        <li>
                            <a onclick="javascript:_admin_content_loader('user');" menu-id="user"  role="button"><i class="s16 icomoon-icon-user m0 pr5"></i><span class="txt">User</span> </a>
<!--                            <ul class="sub hide">
                                <?php if($AppUtilObj->_feature_enabled('USER')): ?>
                                <li>
                                    <a href="javascript:_admin_content_loader('add-edit-user');" menu-id="add-edit-user"><i class="s16 icomoon-icon-arrow-right-3 m0 pr5"></i><span class="txt">Add New</span></a>
                                </li>
                                <li>
                                    <a href="javascript:_admin_content_loader('user');" menu-id="user"><i class="s16 icomoon-icon-arrow-right-3 m0 pr5"></i><span class="txt">View</span></a>
                                </li>
                                <?php endif; ?>
                            </ul>-->
                        </li>
                        <li>
                            <a onclick="javascript:_admin_content_loader('report');" menu-id="report"  role="button"><i class="s16 icomoon-icon-pie-2 m0 pr5"></i><span class="txt">Report</span> </a>
<!--                            <ul class="sub hide">
                                <?php if($AppUtilObj->_feature_enabled('REPORT')): ?>
                                <li>
                                    <a href="javascript:_admin_content_loader('report');" menu-id="report"><i class="s16 icomoon-icon-arrow-right-3 m0 pr5"></i><span class="txt">Generate</span></a>
                                </li>
                                <?php endif; ?>
                            </ul>-->
                        </li>
                        <li>
                            <a href="javascript:_admin_content_loader('total-ticket');" menu-id="total-ticket"><i class="s16 icomoon-icon-tag m0 pr5"></i><span class="txt">Ticket</span> </a>
                        </li>
                        <li class="hide">
                            <a href="#"><i class="s16 icomoon-icon-tag m0 pr5"></i><span class="txt">Ticket</span> </a>
                            <ul class="sub">
                                <?php if($AppUtilObj->_feature_enabled('TICKET')): ?>
<!--                                <li hidden="">
                                    <a href="javascript:_admin_content_loader('add-ticket');" menu-id="add-ticket"><i class="s16 icomoon-icon-arrow-right-3 m0 pr5"></i><span class="txt">Add New</span></a>
                                </li>-->
                                <li>
                                    <a href="javascript:_admin_content_loader('total-ticket');" menu-id="total-ticket"><i class="s16 icomoon-icon-arrow-right-3 m0 pr5"></i><span class="txt">Total</span></a>
                                </li>
                                <li>
                                    <a href="javascript:_admin_content_loader('open-ticket');" menu-id="open-ticket"><i class="s16 icomoon-icon-arrow-right-3 m0 pr5"></i><span class="txt">Open</span></a>
                                </li>
                                <li>
                                    <a href="javascript:_admin_content_loader('closed-ticket');" menu-id="closed-ticket"><i class="s16 icomoon-icon-arrow-right-3 m0 pr5"></i><span class="txt">Closed</span></a>
                                </li>
                                <?php endif; ?>
                            </ul>
                        </li>
                        <li>
                            <a href="javascript:_admin_content_loader('bulk-upload');" menu-id="bulk-upload"><i class="s16 icomoon-icon-upload m0 pr5"></i><span class="txt">Bulk Upload</span> </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- End .sidebar-scrollarea -->
    </div>
    <!-- End .sidebar-inner -->
</div>