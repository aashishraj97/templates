<div id="sidebar" class="page-sidebar hidden-lg hidden-md hidden-sm hidden-xs">
    <div class="shortcuts mt5">
        <ul>
            <!--Sidebar collapse button-->
            <li><a href="javascript:_content_loader('dashboard');" title="Home" class="tip"><i class="s24 icomoon-icon-home"></i></a>
            </li>
            
            <li><a href="javascript:_content_loader('check-in-out');" menu-id="check-in-out" title="Check In/Out" class="tip"><i class="s24 icomoon-icon-screen"></i></a>
            </li>
        </ul>
    </div>
    <!-- End search -->
    <!-- Start .sidebar-inner -->
    <div class="sidebar-inner">
        <!-- Start .sidebar-scrollarea -->
        <div class="sidebar-scrollarea">
            <div class="sidenav">
                <!-- End .sidenav-widget -->
                <div class="mainnav">
                    <ul>
                        <li>
                            <a onclick="javascript:_content_loader('check-in-out');" menu-id="check-in-out" role="button"><i class="icomoon-icon-enter s16 m0 pr5"></i><span class="txt"> Check In/Out</span> </a>
                        </li>
                        <li>
                            <a href="#"><i class="s16 icomoon-icon-tag m0 pr5"></i><span class="txt">Ticket</span> </a>
                            <ul class="sub">
                                <li>
                                    <a href="javascript:_admin_content_loader('total-ticket');" menu-id="total-ticket"><i class="s16 icomoon-icon-arrow-right-3 m0 pr5"></i><span class="txt">Add</span></a>
                                </li>
                                <li>
                                    <a href="javascript:_admin_content_loader('open-ticket');" menu-id="open-ticket"><i class="s16 icomoon-icon-arrow-right-3 m0 pr5"></i><span class="txt">View</span></a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
             End sidenav 
            <div class="sidebar-widget">
                <h6 class="title">Monthly Bandwidth Transfer</h6>
                <div class="content clearfix">
                    <i class="s16 icomoon-icon-loop pull-left mr10"></i>
                    <div class="progress progress-bar-xs pull-left mt5 tip" title="87%">
                        <div class="progress-bar progress-bar-danger" style="width: 87%;"></div>
                    </div>
                    <span class="percent pull-right">87%</span>
                    <div class="stat">19419.94 / 12000 MB</div>
                </div>
            </div>
             End .sidenav-widget 
            <div class="sidebar-widget">
                <h6 class="title">Disk Space Usage</h6>
                <div class="content clearfix">
                    <i class="s16  icomoon-icon-storage-2 pull-left mr10"></i>
                    <div class="progress progress-bar-xs pull-left mt5 tip" title="16%">
                        <div class="progress-bar progress-bar-success" style="width: 16%;"></div>
                    </div>
                    <span class="percent pull-right">16%</span>
                    <div class="stat">304.44 / 8000 MB</div>
                </div>
            </div>
             End .sidenav-widget 
            <div class="sidebar-widget">
                <h6 class="title">Ad sense stats</h6>
                <div class="content">
                    <div class="stats">
                        <div class="item">
                            <div class="head clearfix">
                                <div class="txt">Advert View</div>
                            </div>
                            <i class="s16 icomoon-icon-eye pull-left"></i>
                            <div class="number">21,501</div>
                            <div class="change">
                                <i class="s24 icomoon-icon-arrow-up-2 color-green"></i>
                                5%
                            </div>
                            <span id="stat1" class="spark"></span>
                        </div>
                        <div class="item">
                            <div class="head clearfix">
                                <div class="txt">Clicks</div>
                            </div>
                            <i class="s16 icomoon-icon-thumbs-up pull-left"></i>
                            <div class="number">308</div>
                            <div class="change">
                                <i class="s24 icomoon-icon-arrow-down-2 color-red"></i>
                                8%
                            </div>
                            <span id="stat2" class="spark"></span>
                        </div>
                        <div class="item">
                            <div class="head clearfix">
                                <div class="txt">Page CTR</div>
                            </div>
                            <i class="s16 icomoon-icon-heart pull-left"></i>
                            <div class="number">4%</div>
                            <div class="change">
                                <i class="s24 icomoon-icon-arrow-down-2 color-red"></i>
                                1%
                            </div>
                            <span id="stat3" class="spark"></span>
                        </div>
                        <div class="item">
                            <div class="head clearfix">
                                <div class="txt">Earn money</div>
                            </div>
                            <i class="s16 icomoon-icon-coin pull-left"></i>
                            <div class="number">$376</div>
                            <div class="change">
                                <i class="s24 icomoon-icon-arrow-up-2 color-green"></i>
                                26%
                            </div>
                            <span id="stat4" class="spark"></span>
                        </div>
                    </div>
                </div>
            </div>
             End .sidenav-widget 
            <div class="sidebar-widget">
                <h6 class="title">Right now</h6>
                <div class="content">
                    <div class="rightnow">
                        <ul class="list-unstyled">
                            <li><span class="number">34</span><i class="s16 icomoon-icon-new"></i>Posts</li>
                            <li><span class="number">7</span><i class="s16 icomoon-icon-file"></i>Pages</li>
                            <li><span class="number">14</span><i class="s16 icomoon-icon-list-2"></i>Categories</li>
                            <li><span class="number">201</span><i class="s16 icomoon-icon-tag"></i>Tags</li>
                        </ul>
                    </div>
                </div>
            </div>
             End .sidenav-widget 
        </div>
        <!-- End .sidebar-scrollarea -->
    </div>
    <!-- End .sidebar-inner -->
</div>