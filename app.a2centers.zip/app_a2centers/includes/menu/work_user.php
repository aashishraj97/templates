<?php $AppUtilObj = new AppUtil(); ?> 
<div id="sidebar" class="page-sidebar hidden-lg hidden-md hidden-sm hidden-xs">
    <div class="shortcuts mt5">
        <ul>
            <!--Sidebar collapse button-->
            <li><a href="javascript:_content_loader('dashboard');" title="Home" class="tip"><i class="s24 icomoon-icon-home"></i></a>
            </li>
            
            <li><a href="javascript:_content_loader('check-in-out');" menu-id="check-in-out" title="Check In/Out" class="tip"><i class="s24 icomoon-icon-screen"></i></a>
            </li>
        </ul>
    </div>
    <!-- End search -->
    <!-- Start .sidebar-inner -->
    <div class="sidebar-inner">
        <!-- Start .sidebar-scrollarea -->
        <div class="sidebar-scrollarea">
            <div class="sidenav">
                <!-- End .sidenav-widget -->
                <div class="mainnav">
                    <ul>
                        <li>
                            <a onclick="javascript:_content_loader('check-in-out');" menu-id="check-in-out" role="button"><i class="icomoon-icon-enter s16 m0 pr5"></i><span class="txt"> Check In/Out</span> </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- End .sidebar-inner -->
</div>