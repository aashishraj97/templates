<!-- #footer Start -->
<div id="footer" class="clearfix sidebar-page right-sidebar-page">
    <p class="pull-left">
        Copyrights &copy; 2021 <a href="<?=APP::OWNER_URL?>" class="color-blue strong" target="_blank"><?=APP::OWNER_NAME?></a>. All rights reserved.
    </p>
    <p class="pull-right">
        <a href="#" class="mr5" target="_blank">Terms of use</a>
        |
        <a href="#" class="ml5 mr25" target="_blank">Privacy policy</a>
    </p>
</div>
<!-- #footer End -->
