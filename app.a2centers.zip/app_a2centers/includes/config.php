<?php 
/**
*@author  Aashish Raj
*@email   aashishraj97@gmail.com
*@website https://tictik.org
**/
/** find the way to use $_SERVER inside class*/
define('DOCUMENT_ROOT',$_SERVER['DOCUMENT_ROOT']);
define('ROOT_URL','http://'.$_SERVER['SERVER_NAME']);
//define('ROOT_URL','https://'.$_SERVER['SERVER_NAME']);
define('HOST_NAME',$_SERVER['SERVER_NAME']);

/**
*  class to declare the constant
*  and use as static APP::NAME
*/
class APP
{
    
    const AVATAR_SRC    = ROOT_URL . '/img/avatars/avatar17.png';       /** Avatar SRC */
    const LOGO_SRC      = ROOT_URL . '/img/logo/app-logo.png';      /** App Logo SRC */
    const OWNER_LOGO_SRC= ROOT_URL . '/img/logo/app-owner-logo.png';/** App Owner Logo SRC */
    
    const OWNER_NAME    = 'Tic Tik';                               /** App Owner Name */
    const OWNER_URL     = 'https://tictik.org/';               /** App Owner URL */
    
    const NAME          = 'A2';                                  /** App Location */
    const TITLE         = 'A2 Centers';                        /** App Title */
    const URL           = ROOT_URL;                                 /** App URL */
    const HOME_URL      = ROOT_URL . '/app.php';                      /** App Home URL */
    const ROOT          = DOCUMENT_ROOT;                            /** App Location */
    const DOCS          = DOCUMENT_ROOT . '/storage/docs/';           /** App Docs Location */
    const IMGS          = DOCUMENT_ROOT . '/storage/imgs/';           /** App Images Location */  
    const TEMP          = DOCUMENT_ROOT . '/storage/temp/';           /** App Temporary Location */  
    const CRUD          = DOCUMENT_ROOT . '/crud/';                   /** App Crud Location */
}

/**
*  credential to connect database:
*  class to declare the constant
*  and use as static DB::HOST
*/
class DB
{
    const BASE = 'mysql';       /*mysql/mongo/mongodb/postgres and so on*/
    const HOST = 'localhost';
    const NAME = 'app_a2centers';  /*app*/
    const USER = 'root';        /*root*/
    const PASS = 'dbmanager';            /*root*/
    const CHAR = 'utf8';
}
?>