<?php include_once $_SERVER['DOCUMENT_ROOT'] . "/includes/common.php"; ?>
<aside id="right-sidebar" class="right-sidebar hidden-lg hidden-md hidden-sm hidden-xs">
    <!-- Start .sidebar-inner -->
    <div class="sidebar-inner">
        <!-- Start .sidebar-scrollarea -->
        <div class="sidebar-scrollarea">
            <div class="pl10 pt10 pr5">
                <ul class="timeline timeline-icons">
                    <?php
                    $UserObj = new User();
                    $login_history_data = $UserObj->_get_login_history();
                    foreach($login_history_data['data'] as $row) {
                        $tz_code = isset($row['timezone_code'])?' '.$row['timezone_code']:'';
                             echo '<li>
                                     <p>
                                         <span class="color-blue">'.$row['by_user'].'</span> ';
                                         echo 'logged in at  <span class="color-blue">'.$row['login_at'].$tz_code.'</span>';
                                         if(trim($row['logout_at']) != '') {
                                                 echo ' and logged out at  <span class="color-blue">'.$row['logout_at'].$tz_code.'</span>';
                                         }
                                         echo '<span class="timeline-icon"><i class="fa fa-file-text-o"></i></span>
                                     </p>
                             </li>';
                     }
                    ?>
                </ul>
                <!--<a href="#" class="btn btn-default timeline-load-more-btn"><i class="fa fa-refresh"></i> Load more </a>-->
            </div>
        </div>
        <!-- End .sidebar-scrollarea -->
    </div>
    <!-- End .sidebar-inner -->
</aside>